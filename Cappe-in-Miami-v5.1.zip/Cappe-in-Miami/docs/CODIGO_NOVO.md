# Código novo desta atualização (completo, por arquivo)

Cada bloco abaixo já está injetado no arquivo indicado dentro do ZIP. Nada foi resumido.

Pequenos ganchos em outros pontos: `exp-modes.js` (`applyS` chama `applyChar(r)`; `allClear` bloqueado em fases de tiles; `startMode` define `mapSel='tiles'`), `exp-world.js` (`worldTick` chama `EXP.aiExtTick(dt)`; `fireOk` bloqueia arma de fogo do Tony) e `exp-fx.js` (`fxRoom` usa o clima da fase; `drawWorld` chama `EXP.glassDraw`; `fxTick` chama `EXP.glassTick`).

## `js/maps.js` — Matrizes de tiles, patrulhas (waypoints), tile 2 = vidro e árvore de progressão

```js
/* =====================================================================================
   MAPAS EM MATRIZ DE TILES (Grid-Tiles) - Campanha de 3 fases
   Código de tile (apenas para TILE_LEVELS; as GRIDS antigas do index.html mantêm o seu):
     0 = chão          1 = parede         2 = VIDRO / JANELA (quebrável)
     3 = porta         4 = início do jogador
     5 = inimigo corpo a corpo           6 = inimigo armado
   Tile 2 (vidro): bloqueia movimento do jogador e da IA, NÃO bloqueia a linha de visão da IA.
   Um projétil que atravessa o tile muda o seu estado para 0 (chão) e gera 10 estilhaços.
   Cada fase traz: zones (pisos), patrols (waypoints em coordenadas de tile [coluna, linha]),
   theme (cores das paredes) e weather (clima). 'at' é o tile do inimigo que segue a rota.
   ===================================================================================== */
const TILE_GLASS = 2;
const TILE_CODE = { '#': 1, '.': 0, 'G': 2, 'D': 3, 'P': 4, 'm': 5, 'g': 6 };
const tileRows = rows => rows.map(r => Array.from(r, ch => TILE_CODE[ch]));

const TILE_LEVELS = [
  { id: 'hospital', nome: 'O Hospital', weather: 'poeira',
    briefing: 'Quartos pequenos: corpo a corpo.',
    theme: { wall: '#f4f7fa', trim: '#7fd3d6', floor: 'white' },
    zones: [ { c: 0, r: 0, w: 26, h: 15, floor: 'white' }, { c: 1, r: 6, w: 24, h: 3, floor: 'teal2' } ],
    patrols: [
      { at: [10, 7], route: [[10, 7], [4, 7], [10, 7], [22, 7]] },
      { at: [20, 7], route: [[20, 7], [12, 8], [20, 6], [23, 7]] },
    ],
    map: tileRows([
      "##########################",
      "#....#....#....#....#....#",
      "#.m..#....#.m..#....#.g..#",
      "#....#.m..#....#.m..#....#",
      "#....#....#....#....#....#",
      "###D####D####D####D####D##",
      "#........................#",
      "#P........m.........m....#",
      "#........................#",
      "###D####D####D####D####D##",
      "#....#....#....#....#....#",
      "#....#..m.#....#..m.#....#",
      "#..m.#....#..g.#....#..m.#",
      "#....#....#....#....#....#",
      "##########################"
    ]) },
  { id: 'club', nome: 'O Clube Synthwave', weather: 'neon',
    briefing: 'Vidros por toda parte. Quebre-os.',
    theme: { wall: '#2a1050', trim: '#19f0e6', floor: 'black' },
    zones: [ { c: 0, r: 0, w: 30, h: 19, floor: 'black' }, { c: 9, r: 5, w: 12, h: 9, floor: 'checker' },
             { c: 1, r: 5, w: 6, h: 9, floor: 'purple' }, { c: 23, r: 5, w: 6, h: 9, floor: 'purple' },
             { c: 1, r: 1, w: 28, h: 3, floor: 'darkT' }, { c: 1, r: 15, w: 28, h: 3, floor: 'darkT' } ],
    patrols: [
      { at: [14, 2], route: [[14, 2], [27, 2], [3, 2], [14, 2]] },
      { at: [8, 16], route: [[8, 16], [26, 16], [8, 16]] },
      { at: [26, 16], route: [[26, 16], [12, 16], [26, 16]] },
      { at: [11, 7], route: [[11, 7], [19, 7], [19, 12], [11, 12]] },
    ],
    map: tileRows([
      "##############################",
      "#............................#",
      "#....m........g.........m....#",
      "#............................#",
      "#########GGGDGGGGDGGG#########",
      "#......G..............G......#",
      "#......G..............G......#",
      "#..g...D...g..........D......#",
      "#......G..............G...g..#",
      "#......G..g....m......G......#",
      "#......G..............G......#",
      "#...m..D..........g...D......#",
      "#......G.....m........G..m...#",
      "#......G..............G......#",
      "#########GGGDGGGGDGGG#########",
      "#............................#",
      "#.P.....g............m....g..#",
      "#............................#",
      "##############################"
    ]) },
  { id: 'mafia', nome: 'A Sede da Máfia', weather: 'fumaca',
    briefing: 'Fase final. Patrulhas cruzadas.',
    theme: { wall: '#3a2418', trim: '#ffd23f', floor: 'brownT' },
    zones: [ { c: 0, r: 0, w: 34, h: 22, floor: 'brownT' }, { c: 1, r: 9, w: 32, h: 4, floor: 'darkT' }, { c: 15, r: 1, w: 4, h: 20, floor: 'darkT' },
             { c: 1, r: 1, w: 6, h: 6, floor: 'maroon' }, { c: 8, r: 1, w: 6, h: 6, floor: 'redD' }, { c: 20, r: 1, w: 6, h: 6, floor: 'redD' }, { c: 27, r: 1, w: 6, h: 6, floor: 'maroon' },
             { c: 1, r: 15, w: 6, h: 6, floor: 'redD' }, { c: 8, r: 15, w: 6, h: 6, floor: 'maroon' }, { c: 20, r: 15, w: 6, h: 6, floor: 'maroon' }, { c: 27, r: 15, w: 6, h: 6, floor: 'redD' } ],
    patrols: [
      { at: [8, 10], route: [[8, 10], [28, 10], [8, 10]] },
      { at: [21, 10], route: [[21, 10], [4, 11], [21, 10]] },
      { at: [13, 11], route: [[13, 11], [30, 11], [13, 11]] },
      { at: [25, 10], route: [[25, 10], [6, 12], [25, 10]] },
      { at: [16, 4], route: [[16, 4], [17, 19], [16, 4]] },
      { at: [17, 6], route: [[17, 6], [16, 18], [17, 6]] },
      { at: [17, 16], route: [[17, 16], [16, 2], [17, 16]] },
      { at: [16, 19], route: [[16, 19], [17, 3], [16, 19]] },
      { at: [31, 10], route: [[31, 10], [2, 11], [31, 10]] },
      { at: [27, 12], route: [[27, 12], [16, 9], [27, 12]] },
    ],
    map: tileRows([
      "##################################",
      "#......#......#....#......#......#",
      "#.g....#..g...#....#......#..g...#",
      "#...m..#......#....#..g...#...m..#",
      "#......#......#.g..#......#......#",
      "#....g.#....g.#....#....g.#....g.#",
      "#......#......#..g.#......#......#",
      "###D######D####....###D######D####",
      "###.######.####....###.######.####",
      "#................................#",
      "#.P.....g............g...g.....g.#",
      "#............g...................#",
      "#..........................g.....#",
      "###.######.####....###.######.####",
      "###D######D####....###D######D####",
      "#......#......#....#......#......#",
      "#......#......#..g.#......#......#",
      "#.g....#..g...#....#..g...#......#",
      "#...m..#......#....#......#..g...#",
      "#....g.#....g.#.g..#....g.#....g.#",
      "#......#......#....#......#......#",
      "##################################"
    ]) },
];

// Árvore de progressão: cada fase aponta para a próxima (null = fase final).
const LEVEL_TREE = {
  hospital: { next: 'club' },
  club:     { next: 'mafia' },
  mafia:    { next: null },
};
```

## `js/exp-core.js` — IA estendida: estados mentais (patrol/chase/investigate), navegação, patrulha, alerta de tiro a 450 px

```js
/* ==== BLOCO: IA ESTENDIDA (exp-core.js) ===========================================
   Estados mentais explícitos, expostos em enemy.mind:
     'patrol'      segue os waypoints definidos em maps.js (enemy.route, em pixels)
     'chase'       linha de visão limpa (raycast, que atravessa vidro) rastreia o jogador
     'investigate' tiro do jogador em qualquer lugar: inimigos a até 450 px (através de paredes)
                   caminham até a origem do ruído usando busca de caminho (BFS em grade)
   Os estados internos do jogo (IDLE, SUSPICIOUS, INVESTIGATE, SEARCH, ALERT, CHASE, STUNNED)
   continuam existindo; 'PATROL' é o estado interno novo. EXP.mind() traduz tudo em 4 nomes.
   =================================================================================== */
(function () {
  'use strict';
  const EXP = window.EXP;
  EXP.glass = { list: [], map: new Map() };       // tiles de vidro vivos (preenchido por exp-world.js, quebrado em exp-fx.js)
  const NAV = { cs: 20, cols: 0, rows: 0, ok: null, par: null, seen: null, q: null, stamp: 0, built: false, solids: [] };
  EXP.NAV = NAV;
  const DI = [1, -1, 0, 0, 1, 1, -1, -1], DJ = [0, 0, 1, -1, 1, -1, 1, -1];

  function circleHits(list, x, y, r) {
    for (let i = 0; i < list.length; i++) {
      const w = list[i], cx = Math.max(w[0], Math.min(x, w[0] + w[2])), cy = Math.max(w[1], Math.min(y, w[1] + w[3]));
      if ((x - cx) * (x - cx) + (y - cy) * (y - cy) < r * r) return true;
    }
    return false;
  }
  // grade de navegação: células de 20 px, caminháveis quando livres de parede/móvel/vidro (portas contam como passagem)
  EXP.navBuild = function () {
    const cs = NAV.cs, cols = Math.ceil(WW / cs), rows = Math.ceil(WH / cs), n = cols * rows;
    if (!NAV.ok || NAV.ok.length !== n) { NAV.ok = new Uint8Array(n); NAV.par = new Int32Array(n); NAV.seen = new Int32Array(n); NAV.q = new Int32Array(n); NAV.stamp = 0; }
    NAV.cols = cols; NAV.rows = rows;
    const boxes = new Set(doors.map(d => d.box)); NAV.solids = sol.filter(s => !boxes.has(s));
    for (let j = 0; j < rows; j++) for (let i = 0; i < cols; i++) NAV.ok[j * cols + i] = circleHits(NAV.solids, i * cs + cs / 2, j * cs + cs / 2, 9.5) ? 0 : 1;
    NAV.built = true;
  };
  function cellOf(x, y) { return Math.max(0, Math.min(NAV.rows - 1, (y / NAV.cs) | 0)) * NAV.cols + Math.max(0, Math.min(NAV.cols - 1, (x / NAV.cs) | 0)); }
  function nearestOk(idx) {
    if (NAV.ok[idx]) return idx;
    const cols = NAV.cols, ci = idx % cols, cj = (idx / cols) | 0;
    for (let d = 1; d <= 5; d++) for (let dj = -d; dj <= d; dj++) for (let di = -d; di <= d; di++) {
      if (Math.max(Math.abs(di), Math.abs(dj)) !== d) continue;
      const i = ci + di, j = cj + dj; if (i < 0 || j < 0 || i >= cols || j >= NAV.rows) continue;
      if (NAV.ok[j * cols + i]) return j * cols + i;
    }
    return -1;
  }
  EXP.navPath = function (sx, sy, gx, gy) {
    if (!NAV.built) return null;
    const s = nearestOk(cellOf(sx, sy)), g = nearestOk(cellOf(gx, gy)); if (s < 0 || g < 0) return null;
    const stamp = ++NAV.stamp, cols = NAV.cols, rows = NAV.rows, seen = NAV.seen, par = NAV.par, q = NAV.q, ok = NAV.ok;
    let h = 0, t = 0, found = s === g; q[t++] = s; seen[s] = stamp; par[s] = -1;
    while (h < t && !found) {
      const c = q[h++], ci = c % cols, cj = (c / cols) | 0;
      for (let k = 0; k < 8; k++) {
        const di = DI[k], dj = DJ[k], i = ci + di, j = cj + dj;
        if (i < 0 || j < 0 || i >= cols || j >= rows) continue;
        const n = j * cols + i; if (seen[n] === stamp || !ok[n]) continue;
        if (di && dj && (!ok[cj * cols + i] || !ok[j * cols + ci])) continue;      // sem cortar quinas
        seen[n] = stamp; par[n] = c; q[t++] = n; if (n === g) { found = true; break; }
      }
    }
    if (!found) return null;
    const path = []; for (let c = g; c !== -1; c = par[c]) path.push({ x: (c % cols) * NAV.cs + NAV.cs / 2, y: ((c / cols) | 0) * NAV.cs + NAV.cs / 2 });
    path.reverse(); return path;
  };
  function clearRay(x1, y1, x2, y2) {            // raio livre de sólidos (portas contam como livres: os inimigos as abrem)
    const d = Math.hypot(x2 - x1, y2 - y1), n = Math.max(1, Math.ceil(d / 10));
    for (let i = 1; i < n; i++) if (circleHits(NAV.solids, x1 + (x2 - x1) * i / n, y1 + (y2 - y1) * i / n, 9)) return false;
    return true;
  }
  // devolve o ponto intermediário a perseguir (puxa o caminho até o nó mais distante visível)
  function navTarget(e, gx, gy, dt) {
    e.pathT = (e.pathT || 0) - dt; const gk = ((gx / 16) | 0) * 4096 + ((gy / 16) | 0);
    if (!e.path || e.pathT <= 0 || e.pathK !== gk) { e.path = EXP.navPath(e.x, e.y, gx, gy); e.pi = 0; e.pathT = .9 + Math.random() * .4; e.pathK = gk; e.pk = 0; e.smT = 0; }
    const p = e.path; if (!p || !p.length) return null;
    while (e.pi < p.length - 1 && Math.hypot(p[e.pi].x - e.x, p[e.pi].y - e.y) < 26) e.pi++;
    e.smT -= dt; if (e.smT <= 0 || e.pk < e.pi) {
      e.smT = .15; let k = e.pi; for (let j = Math.min(p.length - 1, e.pi + 7); j > e.pi; j--) if (clearRay(e.x, e.y, p[j].x, p[j].y)) { k = j; break; } e.pk = k;
    }
    const out = e.navTmp || (e.navTmp = { x: 0, y: 0 });
    if (e.pk >= p.length - 1) { out.x = gx; out.y = gy; } else { out.x = p[e.pk].x; out.y = p[e.pk].y; }
    return out;
  }
  EXP.navTarget = navTarget;

  EXP.mind = function (e) {
    if (e.ko > 0 || e.stun > 0) return 'down';
    const s = e.state;
    if (s === 'PATROL') return 'patrol';
    if (s === 'CHASE' || s === 'ALERT') return 'chase';
    if (s === 'INVESTIGATE' || s === 'SEARCH' || s === 'SUSPICIOUS') return 'investigate';
    return 'idle';
  };

  // abre a porta que está na frente do inimigo (o jogo só deixava o jogador abrir portas)
  function enemyOpenDoor(e) {
    for (let i = 0; i < doors.length; i++) {
      const d = doors[i]; if (d.open || d.swing) continue;
      const cx = d.x + d.w / 2, cy = d.y + d.h / 2; if (Math.abs(cx - e.x) > 32 || Math.abs(cy - e.y) > 32) continue;
      let ax = cx - e.x, ay = cy - e.y; const L = Math.hypot(ax, ay) || 1; ax /= L; ay /= L;
      d.swing = true; d.fast = false; d.target = d.vert ? -(ax >= 0 ? 1 : -1) * Math.PI / 2 : (ay >= 0 ? 1 : -1) * Math.PI / 2; return;
    }
  }
  function patrol(e, dt) {
    const w = e.route[e.wp || 0];
    if (e.wait > 0) { e.wait -= dt; return; }
    const t = navTarget(e, w.x, w.y, dt) || w;
    e.a = Math.atan2(t.y - e.y, t.x - e.x); move(e, Math.cos(e.a) * 52 * dt, Math.sin(e.a) * 52 * dt);
    if (Math.hypot(w.x - e.x, w.y - e.y) < 20) { e.wp = ((e.wp || 0) + 1) % e.route.length; e.wait = .6; e.path = null; }
  }
  // chamado uma vez por quadro (por EXP.worldTick), antes do laço de IA do jogo
  EXP.aiExtTick = function (dt) {
    if (!NAV.built) return;
    for (let i = 0; i < enemies.length; i++) {
      const e = enemies[i];
      if (e.ko > 0 || e.stun > 0) { e.mind = 'down'; continue; }
      const s = e.state;
      if (doors.length && !historia && s !== 'IDLE' && s !== 'SUSPICIOUS') enemyOpenDoor(e);
      if (e.route && e.route.length && (s === 'IDLE' || s === 'PATROL')) { if (s === 'IDLE') e.state = 'PATROL'; e.goal = null; patrol(e, dt); }
      else if (s === 'PATROL') e.state = 'IDLE';
      if (s === 'INVESTIGATE' || s === 'SEARCH') {
        if (e.lkp && e.lkp !== e.navPt) e.goal = { x: e.lkp.x, y: e.lkp.y };          // alvo novo (ruído, última posição vista)
        e.invT = (e.invT || 0) + dt;
        if (e.invT > 14) { e.goal = null; e.lkp = null; e.heard = null; e.invT = 0; e.state = 'IDLE'; continue; }
        if (e.goal) {
          const n = navTarget(e, e.goal.x, e.goal.y, dt);
          if (n) { const np = e.navPt || (e.navPt = { x: 0, y: 0 }); np.x = n.x; np.y = n.y; e.lkp = np; }
        }
      } else if (s !== 'SUSPICIOUS') { e.goal = null; e.invT = 0; }
      e.mind = EXP.mind(e);
    }
  };
  // tiro do jogador: 450 px de raio, sem depender de paredes (máscaras silenciosas reduzem o raio)
  EXP.gunshotAlert = function (x, y) {
    const R = 450 * ((typeof S !== 'undefined' && S.quiet) || 1);
    for (let i = 0; i < enemies.length; i++) {
      const e = enemies[i];
      if (e.ko > 0 || e.stun > 0 || e.state === 'CHASE' || e.state === 'ALERT') continue;
      if (Math.hypot(e.x - x, e.y - y) > R) continue;
      e.heard = { x, y }; e.lkp = { x, y }; e.goal = { x, y }; e.invT = 0; e.path = null;
      setEnemyState(e, 'INVESTIGATE', 4);
    }
  };
  const _emit = emitNoise;
  emitNoise = function (x, y, r, kind) { if (kind === 'gunshot') EXP.gunshotAlert(x, y); _emit(x, y, r, kind); };
})();
```

## `js/exp-world.js` — Construtor de fases em matriz, spawn com waypoints e nextLevel()

```js
/* ==== BLOCO: FASES EM MATRIZ DE TILES + nextLevel() (exp-world.js) ==================
   Lê TILE_LEVELS / LEVEL_TREE de maps.js. Códigos: 0 chão, 1 parede, 2 vidro, 3 porta,
   4 início, 5 inimigo corpo a corpo, 6 inimigo armado. A matriz original nunca é alterada:
   EXP.tileMap é a cópia viva (o vidro quebrado vira 0 só nela), então reiniciar restaura tudo.
   =================================================================================== */
(function () {
  'use strict';
  const EXP = window.EXP;
  EXP.tileIdx = 0; EXP.tileMap = null;
  const isTile = G => !!G && TILE_LEVELS.indexOf(G) >= 0;
  EXP.curTile = () => (curGrid && isTile(curGrid)) ? curGrid : null;

  const _gridFor = gridFor;
  gridFor = function (n) { const r = EXP.run; if (r && r.tiles) return TILE_LEVELS[EXP.tileIdx]; return _gridFor(n); };

  function buildTileLevel(G) {
    const g = G.map, R = g.length, C = g[0].length;
    EXP.tileMap = g.map(row => row.slice());
    WW = C * TILE; WH = R * TILE; fixedMap = false; mapName = G.nome;
    walls = []; furn = []; decor = []; posts = []; keep = []; doors = [];
    EXP.glass.list.length = 0; EXP.glass.map.clear();
    EXP.glassPending = [];
    rooms = G.zones.map(z => ({ x: z.c * TILE, y: z.r * TILE, w: z.w * TILE, h: z.h * TILE, t: z.floor }));
    startPos = [WW / 2, WH / 2];
    for (let r = 0; r < R; r++) {
      let c = 0;
      while (c < C) {
        const v = EXP.tileMap[r][c];
        if (v === 1) {                                    // funde paredes contíguas da mesma linha
          let e = c; while (e + 1 < C && EXP.tileMap[r][e + 1] === 1) e++;
          walls.push([c * TILE, r * TILE, (e - c + 1) * TILE, TILE]); c = e + 1; continue;
        }
        const x = c * TILE, y = r * TILE;
        if (v === TILE_GLASS) EXP.glassPending.push({ x, y, w: TILE, h: TILE, c, r, key: r * C + c });   // entra nos sólidos só em tileSetup (evita a textura de parede/móvel por cima)
        else if (v === 3) {
          const wl = q => q === 1 || q === TILE_GLASS, vert = wl((EXP.tileMap[r - 1] || [])[c]) && wl((EXP.tileMap[r + 1] || [])[c]), cx = x + TILE / 2, cy = y + TILE / 2;
          doors.push({ x, y, w: TILE, h: TILE, vert, th: 0, target: 0, swing: false, open: false, fast: false, box: vert ? [cx - 4, y, 8, TILE] : [x, cy - 4, TILE, 8] });
        } else if (v === 4) startPos = [x + TILE / 2, y + TILE / 2];
        c++;
      }
    }
    EXP.glassCols = C;
    exitR = [0, 0, 0, 0];
    refreshSol(); rooms.hall = null; paintMap(lvl);
  }
  const _buildGrid = buildGrid;
  buildGrid = function (G) { if (isTile(G)) buildTileLevel(G); else _buildGrid(G); };

  const _spawnGrid = spawnGrid;
  spawnGrid = function (G) {
    if (!isTile(G)) { _spawnGrid(G); return; }
    G.map.forEach((row, r) => row.forEach((v, c) => {
      if (v !== 5 && v !== 6) return;
      const e = EXP.spawnEnemy(c * TILE + TILE / 2, r * TILE + TILE / 2, v === 5 ? 'bat' : 'gun');
      const pt = (G.patrols || []).find(p => p.at[0] === c && p.at[1] === r);
      if (pt) { e.route = pt.route.map(q => ({ x: q[0] * TILE + TILE / 2, y: q[1] * TILE + TILE / 2 })); e.wp = 1; e.state = 'PATROL'; }
    }));
  };

  // pós-montagem: vidro entra nos sólidos, tema das paredes, sem escadas, grade de navegação
  function tileSetup() {
    const G = EXP.curTile(); if (!G) return;
    EXP.glass.list.length = 0; EXP.glass.map.clear();
    for (const gl of EXP.glassPending) { EXP.glass.list.push(gl); EXP.glass.map.set(gl.key, gl); }
    refreshSol();
    transp.length = 0; for (const f of predio) if (f) f.transp = [];
    const tc = tp.getContext('2d'), th = G.theme;
    for (const w of walls) {
      tc.globalAlpha = .9; tc.fillStyle = th.wall; tc.fillRect(w[0], w[1], w[2], w[3]); tc.globalAlpha = 1;
      tc.fillStyle = th.trim; tc.fillRect(w[0], w[1], w[2], 3); tc.fillRect(w[0], w[1] + w[3] - 3, w[2], 3);
    }
  }
  const _ors = EXP.onRoomStart;
  EXP.onRoomStart = function () {
    tileSetup(); EXP.navBuild();
    const G = EXP.curTile(); if (G) EXP.waveLvl = Math.max(EXP.waveLvl || 0, 1 + EXP.tileIdx * 3);
    _ors();
  };

  // Limpa todas as entidades e carrega a próxima matriz da árvore de progressão.
  // Devolve false se a fase atual era a última.
  window.nextLevel = function () {
    const cur = TILE_LEVELS[EXP.tileIdx], nxt = cur && LEVEL_TREE[cur.id] && LEVEL_TREE[cur.id].next;
    if (!nxt) return false;
    enemies.length = 0; bullets.length = 0; pickups.length = 0; corpses.length = 0; blood.length = 0; liveBlood.length = 0;
    throws.length = 0; popups.length = 0; fx.length = 0; sparks.length = 0; soundEvents.length = 0;
    EXP.world.barrels.length = 0; EXP.world.cams.length = 0; EXP.world.boss = null;
    if (EXP.glassFxReset) EXP.glassFxReset();
    EXP.tileIdx = TILE_LEVELS.findIndex(l => l.id === nxt); lvl = EXP.tileIdx + 1;
    startLevel(); st = 'play';
    const G = TILE_LEVELS[EXP.tileIdx]; banner = { txt: G.nome.toUpperCase(), sub: G.briefing, t: 3 };
    return true;
  };
  EXP.levelIsLast = () => { const cur = TILE_LEVELS[EXP.tileIdx]; return !(cur && LEVEL_TREE[cur.id] && LEVEL_TREE[cur.id].next); };
})();
```

## `js/exp-fx.js` — Vidros quebráveis: física, raycast da IA que atravessa vidro, estilhaços

```js
/* ==== BLOCO: VIDROS QUEBRÁVEIS (exp-fx.js) ==========================================
   Tile 2 (TILE_GLASS, definido em maps.js) = vidro/janela.
   - Bloqueia movimento de jogador, inimigos e balas que ainda não o quebraram (entra em `sol`).
   - NÃO bloqueia a linha de visão da IA: los() é reescrita para ignorar o vidro (EXP.solNG).
   - Uma bala que cruza o tile muda o estado dele para 0 (chão), na matriz viva EXP.tileMap,
     e gera 10 estilhaços que voam na direção do vetor do tiro (pool fixo, sem alocação por quadro).
   =================================================================================== */
(function () {
  'use strict';
  const EXP = window.EXP, TAU = Math.PI * 2, rnd = Math.random;
  EXP.solNG = [];

  // sólidos = paredes + móveis + portas fechadas + vidro. solNG = tudo isso, sem o vidro.
  const _refreshSol = refreshSol;
  refreshSol = function () {
    _refreshSol();
    EXP.solNG = sol.slice();
    for (const gl of EXP.glass.list) { gl.rect = gl.rect || [gl.x, gl.y, gl.w, gl.h]; sol.push(gl.rect); }
  };
  function hitList(list, x, y, r) {
    for (let i = 0; i < list.length; i++) {
      const w = list[i], cx = Math.max(w[0], Math.min(x, w[0] + w[2])), cy = Math.max(w[1], Math.min(y, w[1] + w[3]));
      if ((x - cx) * (x - cx) + (y - cy) * (y - cy) < r * r) return true;
    }
    return false;
  }
  // raycast da IA: marcha em passos de 12 px e só para em sólidos que não são vidro
  const _los = los;
  los = function (a, b) {
    if (!EXP.glass.list.length) return _los(a, b);
    const d = Math.hypot(b.x - a.x, b.y - a.y), n = Math.ceil(d / 12);
    for (let i = 1; i < n; i++) if (hitList(EXP.solNG, a.x + (b.x - a.x) * i / n, a.y + (b.y - a.y) * i / n, 2)) return false;
    return true;
  };

  // ---- estilhaços ----
  const N = 160, SH = [];
  for (let i = 0; i < N; i++) SH.push({ on: false, x: 0, y: 0, vx: 0, vy: 0, rot: 0, vr: 0, life: 0, max: 1, s: 3, c: 0 });
  const SCOL = ['rgba(190,250,255,', 'rgba(120,230,255,', 'rgba(255,255,255,', 'rgba(255,170,230,'];
  let head = 0;
  EXP.glassBurst = function (x, y, dx, dy) {
    const base = Math.atan2(dy, dx);
    for (let k = 0; k < 10; k++) {
      const p = SH[head]; head = (head + 1) % N;
      const a = base + (rnd() - .5) * .9, sp = 160 + rnd() * 300;
      p.on = true; p.x = x + (rnd() - .5) * 14; p.y = y + (rnd() - .5) * 14; p.vx = Math.cos(a) * sp; p.vy = Math.sin(a) * sp;
      p.rot = rnd() * TAU; p.vr = (rnd() - .5) * 20; p.max = p.life = .55 + rnd() * .55; p.s = 3 + rnd() * 5; p.c = (rnd() * 4) | 0;
    }
  };
  EXP.glassFxReset = function () { for (const p of SH) p.on = false; };

  function breakGlass(gl, dx, dy) {
    EXP.glass.list.splice(EXP.glass.list.indexOf(gl), 1); EXP.glass.map.delete(gl.key);
    if (EXP.tileMap) EXP.tileMap[gl.r][gl.c] = 0;                       // estado do bloco: 2 -> 0 (chão)
    refreshSol(); EXP.navBuild();
    const cx = gl.x + gl.w / 2, cy = gl.y + gl.h / 2;
    EXP.glassBurst(cx, cy, dx, dy); EXP.sfx('glass'); triggerScreenShake(4, .1);
    emitNoise(cx, cy, 200, 'glass');
    try {                                                              // vestígio no chão onde havia o vidro
      const f = fl.getContext('2d'); f.fillStyle = 'rgba(160,230,255,.10)'; f.fillRect(gl.x, gl.y, gl.w, gl.h);
      for (let i = 0; i < 9; i++) { f.fillStyle = 'rgba(220,250,255,' + (.25 + rnd() * .35) + ')'; const sx = gl.x + rnd() * gl.w, sy = gl.y + rnd() * gl.h; f.beginPath(); f.moveTo(sx, sy); f.lineTo(sx + 2 + rnd() * 4, sy + rnd() * 3); f.lineTo(sx + rnd() * 3, sy + 2 + rnd() * 4); f.fill(); }
    } catch (e) {}
    if (EXP.run) addScore(25);
  }
  // varre o trecho que cada bala percorre neste quadro (e mais um passo à frente)
  EXP.glassTick = function (dt) {
    for (const p of SH) if (p.on) {
      p.life -= dt; if (p.life <= 0) { p.on = false; continue; }
      const k = Math.pow(.02, dt); p.vx *= k; p.vy *= k; p.x += p.vx * dt; p.y += p.vy * dt; p.rot += p.vr * dt;
    }
    if (!EXP.glass.list.length || !bullets.length) return;
    const C = EXP.glassCols, T = TILE;
    for (let i = 0; i < bullets.length; i++) {
      const b = bullets[i], sx = b.vx * dt * 2, sy = b.vy * dt * 2, n = Math.max(1, Math.ceil(Math.hypot(sx, sy) / 8));
      for (let s = 0; s <= n; s++) {
        const x = b.x + sx * s / n, y = b.y + sy * s / n, gl = EXP.glass.map.get(Math.floor(y / T) * C + Math.floor(x / T));
        if (gl) { breakGlass(gl, b.vx, b.vy); break; }
      }
    }
  };
  EXP.glassDraw = function (g) {
    const now = performance.now();
    for (const gl of EXP.glass.list) {
      g.fillStyle = 'rgba(110,225,255,.26)'; g.fillRect(gl.x, gl.y, gl.w, gl.h);
      g.strokeStyle = 'rgba(210,255,255,.8)'; g.lineWidth = 2; g.strokeRect(gl.x + 1, gl.y + 1, gl.w - 2, gl.h - 2);
      const sh = (now / 40 + gl.x) % 120; g.strokeStyle = 'rgba(255,255,255,.55)'; g.lineWidth = 3; g.beginPath();
      g.moveTo(gl.x + 6, gl.y + 30); g.lineTo(gl.x + 30, gl.y + 6); g.stroke();
      if (sh < 40) { g.strokeStyle = 'rgba(255,255,255,' + (.5 - sh / 80) + ')'; g.beginPath(); g.moveTo(gl.x + sh, gl.y); g.lineTo(gl.x + sh - 20, gl.y + gl.h); g.stroke(); }
    }
    for (const p of SH) if (p.on) {
      g.save(); g.translate(p.x, p.y); g.rotate(p.rot); g.fillStyle = SCOL[p.c] + Math.min(1, p.life / p.max * 1.5) + ')';
      g.beginPath(); g.moveTo(-p.s, p.s * .6); g.lineTo(p.s * 1.1, 0); g.lineTo(-p.s * .2, -p.s); g.closePath(); g.fill(); g.restore();
    }
  };
})();
```

## `js/exp-modes.js` — Modo Campanha, personagens (Richard, Tony, Dennis, Rasmus) e desenho do Rasmus

```js
  // ================= CAMPANHA (fases em matriz) =================
  function campaignTick(r, dt) {
    if (r.pending || r.done || st !== 'play') return;
    if (r.t - (r.roomT0 || 0) < 1.2 || !(EXP.enemyCount0 > 0) || enemies.length > 0) return;
    r.pending = true;                                            // último inimigo eliminado
    const rep = roomReport(r);
    banner = { txt: 'FASE COMPLETA', sub: TILE_LEVELS[EXP.tileIdx].nome, t: 1.4 };
    st = 'summary'; mouse.down = false; EXP.sfx('waveEnd');
    EXP.ui.summary(rep, () => {
      st = 'play'; r.pending = false;
      if (EXP.levelIsLast()) { EXP.save().flags.campWon = true; endRun(true, 'Sede da Máfia destruída!'); return; }
      nextLevel();
    });
  }
  EXP.ACH.push({ id: 'tres', nome: 'Três Andares', desc: 'Complete a Campanha de 3 Fases.', test: s => !!s.flags.campWon });

  // ================= PERSONAGENS =================
  // Cada personagem tem uma máscara-assinatura e modificadores reais de atributos.
  EXP.CHARS = [
    { id: 'richard', nome: 'Richard', mask: 'sapo', desc: 'Equilibrado. Atributos padrão, sem pontos fracos.', pros: 'Nenhum ponto fraco', cons: 'Nenhum destaque' },
    { id: 'tony', nome: 'Tony', mask: 'tigre', desc: '+20% de velocidade e todo golpe físico mata na hora. Não pega armas de fogo.', pros: 'Velocidade +20%, golpe letal', cons: 'Sem armas de fogo' },
    { id: 'dennis', nome: 'Dennis', mask: 'lobo', desc: 'Começa cada fase com uma faca. Alcance de coleta e de arremesso 50% maior.', pros: 'Faca inicial, alcance +50%', cons: 'Sem arma de fogo inicial' },
    { id: 'rasmus', nome: 'Rasmus', mask: 'coruja', desc: 'Contornos roxos em objetos escondidos e o caminho de fuga mais curto.', pros: 'Enxerga o que está escondido', cons: 'Atributos padrão' },
  ];
  EXP.curChar = () => EXP.CHARS.find(c => c.id === (EXP.save().settings.char || 'richard')) || EXP.CHARS[0];
  EXP.setChar = function (id) {
    const c = EXP.CHARS.find(x => x.id === id); if (!c) return; EXP.save().settings.char = id; EXP.touch();
    const mi = MASKS.findIndex(m => m.id === c.mask); if (mi >= 0) sel = mi;
  };
  function applyChar(r) {
    const c = EXP.curChar(); EXP.char = c.id; EXP.owl = false; S.pickR = 1; S.throwR = 1; S.noGuns = false;
    if (c.id === 'tony') { S.speed *= 1.2; S.punchKill = true; S.noGuns = true; cw = 'punho'; }
    else if (c.id === 'dennis') { cw = 'faca'; S.pickR = 1.5; S.throwR = 1.5; }
    else if (c.id === 'rasmus') EXP.owl = true;
  }
  EXP.applyChar = applyChar;
  // Tony: não coleta armas de fogo
  const _swap2 = swapW;
  swapW = function () {
    if (S.noGuns && st === 'play') { const p = nearPickup(); if (p && WP[p.w].gun) { popup(P.x, P.y - 26, 'TONY NÃO USA ARMA DE FOGO', '#ff9ac8'); return; } }
    _swap2();
  };
  // Dennis: alcance de coleta +50%
  nearPickup = function () { let b = null, bd = 38 * (S.pickR || 1); for (const p of pickups) { const d = Math.hypot(p.x - P.x, p.y - P.y); if (d < bd) { bd = d; b = p; } } return b; };
  // Dennis: arremesso (clique direito / F) alcança 50% mais longe
  const _throw = throwW;
  throwW = function () {
    const n = throws.length; _throw();
    if (throws.length > n && S.throwR > 1) { const t = throws[throws.length - 1]; t.vx *= S.throwR; t.vy *= S.throwR; }
  };

  // Rasmus (Coruja): contornos roxos em objetos escondidos e no caminho de fuga (desenho no canvas)
  let escT = 0, escPath = null;
  function owlDraw(g) {
    if (!EXP.owl || !P || st !== 'play') return;
    const now = performance.now(), pulse = .55 + .35 * Math.sin(now / 260);
    g.save(); g.strokeStyle = 'rgba(176,107,255,' + pulse + ')'; g.lineWidth = 2; g.shadowColor = '#b06bff'; g.shadowBlur = 10;
    const hidden = (x, y) => Math.hypot(x - P.x, y - P.y) < 420 && !los(P, { x, y });
    for (const p of pickups) if (hidden(p.x, p.y)) { g.strokeRect(p.x - 12, p.y - 12, 24, 24); }
    for (const b of EXP.world.barrels) if (hidden(b.x, b.y)) { g.beginPath(); g.arc(b.x, b.y, b.r + 4, 0, TAU); g.stroke(); }
    for (const c of EXP.world.cams) if (hidden(c.x, c.y)) { g.strokeRect(c.x - 10, c.y - 8, 20, 16); }
    for (const e of enemies) if (e.ko <= 0 || e.ko === undefined) { if (Math.hypot(e.x - P.x, e.y - P.y) < 300 && !los(P, e)) { g.beginPath(); g.arc(e.x, e.y, e.r + 5, 0, TAU); g.stroke(); } }
    // rota de fuga: até a saída (se aberta) ou até a porta mais próxima
    escT -= 1 / 60;
    if (escT <= 0) {
      escT = .5; let gx = null, gy = null;
      if (exitR[2] > 0 && (cleared || EXP.run && EXP.run.id !== 'classico')) { gx = exitR[0] + exitR[2] / 2; gy = exitR[1] + exitR[3] / 2; }
      else { let bd = 1e9; for (const d of doors) { const dd = Math.hypot(d.x + d.w / 2 - P.x, d.y + d.h / 2 - P.y); if (dd < bd && dd > 60) { bd = dd; gx = d.x + d.w / 2; gy = d.y + d.h / 2; } } }
      escPath = gx === null ? null : EXP.navPath(P.x, P.y, gx, gy);
    }
    if (escPath && escPath.length > 1) { g.setLineDash([10, 8]); g.lineDashOffset = -now / 40; g.beginPath(); g.moveTo(P.x, P.y); for (const q of escPath) g.lineTo(q.x, q.y); g.stroke(); }
    g.restore();
  }
  const _wd2 = EXP.drawWorld; EXP.drawWorld = function (g) { _wd2(g); owlDraw(g); };
```

## `js/exp-modes.js` — Definição do modo Campanha na tabela de modos

```js
  def({ id: 'campanha', nome: 'Campanha: 3 Fases', color: '#7dff9b', tiles: true, direct: false,
    desc: 'Hospital, Clube Synthwave e Sede da Máfia, em mapas de tiles com vidros quebráveis.',
    rules: ['Três fases em sequência; elimine o último inimigo para avançar.', 'Inimigos patrulham waypoints e investigam qualquer tiro a até 450 px.', 'Vidros bloqueiam o passo mas não a visão: atire para quebrá-los.', 'Uma vida.'],
    reward: 'XP por fase · conquista Três Andares.', rooms: 3,
    start(r) { r.tiles = true; EXP.tileIdx = 0; },
    tick(r, dt) { campaignTick(r, dt); } });
```

## `js/exp-ui.js` — Seleção de personagem na tela de máscaras

```js
  // ---------- PERSONAGENS (na tela de máscaras) ----------
  const charRow = document.createElement('div'); charRow.id = 'charRow'; charRow.className = 'menu-row';
  charRow.innerHTML = '<div class="tabs" id="charTabs"></div><p class="dica" id="charInfo" style="width:100%;margin:.1rem 0"></p>';
  grade.before(charRow);
  const ctabs = $('charTabs');
  EXP.CHARS.forEach(c => { const b = document.createElement('button'); b.type = 'button'; b.dataset.id = c.id; b.textContent = c.nome + ' (' + MASKS.find(m => m.id === c.mask).nome + ')'; b.onclick = () => { EXP.setChar(c.id); mark(); refreshChar(); }; ctabs.appendChild(b); });
  function refreshChar() { const cur = EXP.curChar(); [...ctabs.children].forEach(b => b.classList.toggle('on', b.dataset.id === cur.id)); $('charInfo').innerHTML = '<b style="color:var(--amarelo)">' + cur.nome + '</b> — ' + esc(cur.desc) + ' <span style="opacity:.7">[+ ' + esc(cur.pros) + ' · − ' + esc(cur.cons) + ']</span>'; }
  const _showMasks = showMasks; showMasks = function () { _showMasks(); refreshChar(); };
  refreshChar();
```

