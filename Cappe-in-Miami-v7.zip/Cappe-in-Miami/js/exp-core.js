/* Cappe in Miami - Expansão | NÚCLEO
   Salvamento versionado (com backup e migração), XP/níveis, pontos de habilidade,
   conquistas, ranking local e avisos (toasts). Não depende de nenhum outro exp-*.js. */
(function () {
  'use strict';
  const EXP = window.EXP;
  const KEY = 'hm_save_v2', BAK = 'hm_save_v2_bak';
  const MAXLV = 40;

  const defSave = () => ({
    v: 2, created: Date.now(), saved: 0,
    xp: 0, level: 1, sp: 0, perks: {},
    stats: { kills: 0, deaths: 0, rooms: 0, shots: 0, hits: 0, melee: 0, throwHits: 0, finishers: 0, playSec: 0, maxCombo: 0,
             bestScore: 0, runs: 0, sRanks: 0, ssRanks: 0, bossKills: 0, barrels: 0, cameras: 0, flawless: 0 },
    records: {},          // por modo: { best, wave, time, rooms }
    ranking: {},          // por modo: top 10
    ach: {}, unl: [], bosses: {}, weaponsUsed: {}, masksUsed: {}, flags: {}, daily: {},
    settings: { musVol: .8, sfxVol: .8 }
  });

  // mescla recursiva: campos novos de versões futuras nunca quebram um save antigo
  function merge(base, src) {
    if (!src || typeof src !== 'object') return base;
    for (const k of Object.keys(src)) {
      if (base[k] && typeof base[k] === 'object' && !Array.isArray(base[k])) base[k] = merge(base[k], src[k]);
      else base[k] = src[k];
    }
    return base;
  }
  function readKey(k) { try { const r = localStorage.getItem(k); return r ? JSON.parse(r) : null; } catch (e) { return null; } }
  function valid(o) { return o && typeof o === 'object' && o.v >= 1 && typeof o.level === 'number' && o.stats; }

  function migrate(sv) {   // traz dados das versões anteriores (v4) sem apagá-los
    try {
      const hi = +localStorage.getItem('hm_hiscore') || 0;
      if (hi > (sv.records.classico && sv.records.classico.best || 0)) sv.records.classico = Object.assign({}, sv.records.classico, { best: hi });
      if (localStorage.getItem('hm_unlock') === '1') sv.flags.hardcoreWon = true;
      sv.stats.bestScore = Math.max(sv.stats.bestScore, hi);
    } catch (e) {}
    return sv;
  }

  let SAVE = null, dirty = false, saveT = 0, lastBak = 0;
  function load() {
    let d = readKey(KEY);
    if (!valid(d)) { const b = readKey(BAK); if (valid(b)) { d = b; EXP.log && EXP.log('save principal inválido: restaurado do backup'); } else d = null; }
    SAVE = d ? merge(defSave(), d) : migrate(defSave());
    return SAVE;
  }
  function flush(force) {
    if (!SAVE || (!dirty && !force)) return;
    try {
      const prev = localStorage.getItem(KEY);
      if (prev && Date.now() - lastBak > 20000) { localStorage.setItem(BAK, prev); lastBak = Date.now(); }   // backup rotativo
      SAVE.saved = Date.now(); localStorage.setItem(KEY, JSON.stringify(SAVE)); dirty = false;
    } catch (e) { EXP.log && EXP.log('falha ao salvar: ' + e.message); }
  }
  function touch() { dirty = true; clearTimeout(saveT); saveT = setTimeout(() => flush(), 1500); }   // salvamento automático (agrupado)
  function exportSave() {
    flush(true);
    const blob = new Blob([JSON.stringify(SAVE, null, 1)], { type: 'application/json' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'cappe-in-miami-save.json';
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }
  function importSave(text) {
    let o; try { o = JSON.parse(text); } catch (e) { return 'Arquivo inválido (não é JSON).'; }
    if (!valid(o)) return 'Este arquivo não é um save do Cappe in Miami.';
    try { localStorage.setItem(BAK, JSON.stringify(SAVE)); } catch (e) {}
    SAVE = merge(defSave(), o); flush(true); EXP.recheck(); return '';
  }
  function resetSave() { try { localStorage.setItem(BAK, JSON.stringify(SAVE)); } catch (e) {} SAVE = defSave(); flush(true); }

  // ---------- XP / níveis / perks ----------
  const xpNeed = l => Math.round(90 * Math.pow(l, 1.45));
  const PERKS = [
    { id: 'agil',    nome: 'Pés Leves',   max: 5, desc: '+3% de velocidade por nível.' },
    { id: 'furtivo', nome: 'Sombra',      max: 5, desc: 'Inimigos te veem 20 px mais tarde e ouvem 4% menos por nível.' },
    { id: 'municao', nome: 'Bolsos Fundos', max: 5, desc: '+3 de munição inicial por nível.' },
    { id: 'folego',  nome: 'Embalo',      max: 5, desc: '+0,2 s na janela de combo por nível.' },
    { id: 'pele',    nome: 'Pele Grossa', max: 3, desc: 'Nível 1: +1 colete por sala. Nível 3: +2.' },
    { id: 'pontaria', nome: 'Mira Firme', max: 5, desc: 'Reduz a dispersão dos tiros em 6% por nível.' },
  ];
  function perk(id) { return (SAVE.perks[id] || 0); }
  function buyPerk(id) {
    const p = PERKS.find(x => x.id === id); if (!p) return false;
    if (SAVE.sp < 1 || perk(id) >= p.max) return false;
    SAVE.sp--; SAVE.perks[id] = perk(id) + 1; touch(); return true;
  }
  function addXP(n, why) {
    n = Math.round(n * ((typeof S !== 'undefined' && S.xp) || 1) * (EXP.xpMul || 1)); if (n <= 0) return 0;
    SAVE.xp += n;
    while (SAVE.level < MAXLV && SAVE.xp >= xpNeed(SAVE.level)) {
      SAVE.xp -= xpNeed(SAVE.level); SAVE.level++;
      SAVE.sp += 1 + (SAVE.level % 5 === 0 ? 1 : 0);
      toast('NÍVEL ' + SAVE.level, '+' + (1 + (SAVE.level % 5 === 0 ? 1 : 0)) + ' ponto(s) de habilidade', '#ffd23f');
      EXP.checkUnlocks();
    }
    if (SAVE.level >= MAXLV) SAVE.xp = Math.min(SAVE.xp, xpNeed(MAXLV));
    touch(); if (EXP.run) EXP.run.xp = (EXP.run.xp || 0) + n; return n;
  }

  // ---------- toasts (lista fixa, sem criar objetos por quadro) ----------
  const toasts = [];
  function toast(t, sub, c) { toasts.push({ t, sub: sub || '', c: c || '#19f0e6', life: 3.2 }); if (toasts.length > 5) toasts.shift(); }

  // ---------- conquistas ----------
  const ACH = [
    { id: 'primeiro',  nome: 'Primeiro Sangue',     desc: 'Derrote um inimigo.',                       test: s => s.stats.kills >= 1 },
    { id: 'k100',      nome: 'Faxineiro',           desc: 'Derrote 100 inimigos.',                     test: s => s.stats.kills >= 100 },
    { id: 'k500',      nome: 'Ceifador',            desc: 'Derrote 500 inimigos.',                     test: s => s.stats.kills >= 500 },
    { id: 'k2000',     nome: 'Lenda de Miami',      desc: 'Derrote 2000 inimigos.',                    test: s => s.stats.kills >= 2000 },
    { id: 'rank_s',    nome: 'Estilo',              desc: 'Consiga nota S em uma sala.',               test: s => s.stats.sRanks >= 1 },
    { id: 'rank_ss',   nome: 'Perfeição',           desc: 'Consiga nota SS em uma sala.',              test: s => s.stats.ssRanks >= 1 },
    { id: 'combo10',   nome: 'Frenesi',             desc: 'Chegue a um combo de 10x.',                 test: s => s.stats.maxCombo >= 10 },
    { id: 'combo20',   nome: 'Sem Freio',           desc: 'Chegue a um combo de 20x.',                 test: s => s.stats.maxCombo >= 20 },
    { id: 'horda10',   nome: 'Maré Alta',           desc: 'Chegue à onda 10 no Modo Horda.',           test: s => (s.records.horda && s.records.horda.wave || 0) >= 10 },
    { id: 'horda20',   nome: 'Inabalável',          desc: 'Chegue à onda 20 no Modo Horda.',           test: s => (s.records.horda && s.records.horda.wave || 0) >= 20 },
    { id: 'chefe1',    nome: 'Caça-Chefes',         desc: 'Derrote um chefe.',                         test: s => s.stats.bossKills >= 1 },
    { id: 'chefe6',    nome: 'Rei da Pista',        desc: 'Derrote todos os chefes disponíveis.',      test: s => Object.keys(s.bosses).length >= (EXP.bosses ? EXP.bosses.length : 99) },
    { id: 'surv',      nome: 'Sobrevivente',        desc: 'Complete o Modo Sobrevivência.',            test: s => !!s.flags.survWon },
    { id: 'arcade',    nome: 'Moedas Infinitas',    desc: 'Zere o Modo Arcade.',                       test: s => !!s.flags.arcadeWon },
    { id: 'fantasma',  nome: 'Fantasma',            desc: 'Vença o Modo Assassino sem ser detectado.', test: s => !!s.flags.ghostWon },
    { id: 'diario',    nome: 'Rotina',              desc: 'Complete um Desafio Diário.',               test: s => Object.keys(s.daily).length >= 1 },
    { id: 'barris',    nome: 'Pirotécnico',         desc: 'Exploda 10 barris.',                        test: s => s.stats.barrels >= 10 },
    { id: 'cameras',   nome: 'Ponto Cego',          desc: 'Destrua 5 câmeras de segurança.',           test: s => s.stats.cameras >= 5 },
    { id: 'variedade', nome: 'Arsenal',             desc: 'Use 5 armas diferentes na mesma sala.',     test: s => !!s.flags.variety5 },
    { id: 'impecavel', nome: 'Impecável',           desc: 'Complete 5 salas sem ser detectado.',       test: s => s.stats.flawless >= 5 },
    { id: 'hist',      nome: 'Fim da Linha',        desc: 'Termine o Modo História.',                  test: s => !!s.flags.storyWon },
    { id: 'pontos50k', nome: 'Placar Estourado',    desc: 'Faça 50.000 pontos em uma partida.',        test: s => s.stats.bestScore >= 50000 },
    { id: 'nivel10',   nome: 'Veterano',            desc: 'Chegue ao nível 10.',                       test: s => s.level >= 10 },
    { id: 'nivel25',   nome: 'Elite',               desc: 'Chegue ao nível 25.',                       test: s => s.level >= 25 },
  ];
  function checkAch() {
    for (const a of ACH) if (!SAVE.ach[a.id] && a.test(SAVE)) { SAVE.ach[a.id] = Date.now(); toast('CONQUISTA', a.nome, '#ff2e93'); touch(); EXP.checkUnlocks(); }
  }

  // ---------- ranking local ----------
  function addRank(mode, entry) {
    const L = SAVE.ranking[mode] || (SAVE.ranking[mode] = []);
    entry.date = new Date().toISOString().slice(0, 10); L.push(entry); L.sort((a, b) => b.score - a.score); if (L.length > 10) L.length = 10;
    const pos = L.indexOf(entry); touch(); return pos;   // -1 se ficou fora do top 10
  }
  function setRecord(mode, key, val, lowerBetter) {
    const R = SAVE.records[mode] || (SAVE.records[mode] = {}), old = R[key];
    if (old === undefined || (lowerBetter ? val < old : val > old)) { R[key] = val; touch(); return true; } return false;
  }

  load();
  Object.assign(EXP, {
    MAXLV, PERKS, ACH, xpNeed, perk, buyPerk, addXP, toast, toasts, checkAch, addRank, setRecord,
    save: () => SAVE, flush, touch, exportSave, importSave, resetSave, reload: load,
  });
  addEventListener('pagehide', () => flush(true));
  document.addEventListener('visibilitychange', () => { if (document.hidden) flush(true); });
  setInterval(() => flush(), 8000);
})();

/* ============ IA ACÚSTICA (anexar ao final de js/exp-core.js) ============
   Todo tiro do jogador alerta os inimigos num raio de 450 px, ATRAVÉS das paredes.
   Os inimigos alertados entram em 'INVESTIGATE' e andam até a origem do tiro,
   atravessando paredes durante o trajeto (noclip de 2,2 s). */
(function () {
  'use strict';
  const EXP = window.EXP;
  const SHOT_RADIUS = 450, NOCLIP_MS = 2200;

  const _emit = emitNoise;
  emitNoise = function (x, y, radius, kind) {
    if (kind === 'gunshot') { radius = SHOT_RADIUS; alertInRange(x, y); }
    _emit(x, y, radius, kind);
  };

  function alertInRange(x, y) {
    for (const e of enemies) {
      if (e.ko > 0 || e.cls === 'boss') continue;
      if (Math.hypot(e.x - x, e.y - y) > SHOT_RADIUS) continue;
      e.lkp = { x, y }; e.heard = { x, y };
      e.noclipUntil = performance.now() + NOCLIP_MS;
      if (e.state !== 'STUNNED') setEnemyState(e, 'INVESTIGATE', 4);
    }
  }

  // atravessar paredes só enquanto estiver investigando o tiro
  const _move = move;
  move = function (e, dx, dy) {
    if (e.noclipUntil && performance.now() < e.noclipUntil && e.state === 'INVESTIGATE') { e.x += dx; e.y += dy; return; }
    _move(e, dx, dy);
  };
  const _unstick = unstick;
  unstick = function (e) {
    if (e.noclipUntil && performance.now() < e.noclipUntil && e.state === 'INVESTIGATE') return;
    _unstick(e);
  };
})();

/* ============ COMBATE: INIMIGOS ARMADOS, TIRO LETAL, NOCAUTE E EXECUÇÃO ============
   ARQUIVO: js/exp-core.js (anexar ao final).
   Carregado antes de exp-world/exp-modes/exp-ui: os ganchos de jogo ficam em exp-ui.js,
   que carrega por último e encadeia os wrappers já existentes. */
(function () {
  'use strict';
  const EXP = window.EXP;
  const FIXED = 1 / 60;
  const SHOOT_CD = 45;          // frames entre disparos de inimigo armado
  const DOWN_FRAMES = 180;      // frames de nocaute por arremesso (3 s)
  const EXEC_FRAMES = 25;       // frames da animação de execução
  const COMBO_FRAMES = 240;     // janela do combo (4 s)

  const C = {
    SHOOT_CD, DOWN_FRAMES, EXEC_FRAMES, COMBO_FRAMES,
    execs: [],
    reset() { this.execs.length = 0; },
  };
  EXP.combat = C;

  function segDist(ax, ay, bx, by, px, py) {
    const vx = bx - ax, vy = by - ay, L = vx * vx + vy * vy;
    let t = L ? ((px - ax) * vx + (py - ay) * vy) / L : 0;
    t = Math.max(0, Math.min(1, t));
    return Math.hypot(ax + vx * t - px, ay + vy * t - py);
  }

  // ---------- armamento: tipo de arma por inimigo ----------
  function assignWeapon(e) {
    const L = EXP.camp && EXP.camp.on ? CAMPAIGN_LEVELS[EXP.camp.idx] : null;
    const col = Math.floor(e.x / TILE), row = Math.floor(e.y / TILE);
    if (L && L.loadout && L.loadout.some(([c, r]) => c === col && r === row)) return 'shotgun';
    if (e.type === 'shot') return 'shotgun';
    if (e.type === 'gun') return 'pistol';
    return null;                // 'bat' segue desarmado (faca)
  }

  // ---------- tiro: projéteis reais marcados como letais ----------
  function fire(e) {
    const n = e.weapon === 'shotgun' ? 3 : 1;
    if (n === 3) for (const o of [-.22, 0, .22]) shoot(e, e.a + o + (Math.random() - .5) * .06, 330, false);
    else shoot(e, e.a + (Math.random() - .5) * .08, 360, false);
    for (let i = bullets.length - 1, k = n; k > 0 && i >= 0; k--, i--) bullets[i].lethal = true;
  }

  function killPlayer() {
    if (st !== 'play' || !P) return;
    P.inv = 9;                                  // bloqueia qualquer hit() residual neste quadro
    for (let i = bullets.length - 1; i >= 0; i--) if (bullets[i].lethal) bullets.splice(i, 1);
    die();
  }

  // colisão contínua: o trecho percorrido no passo fixo é testado contra o raio do jogador
  function lethalTick(dt) {
    for (let i = bullets.length - 1; i >= 0; i--) {
      const b = bullets[i];
      if (!b.lethal) continue;
      if (segDist(b.x, b.y, b.x + b.vx * dt, b.y + b.vy * dt, P.x, P.y) < P.r + 1) { killPlayer(); return; }
    }
  }

  // ---------- IA armada: CHASE + linha de visão (raycasting) => para, alinha e atira a cada 45 frames ----------
  function armedAI(e) {
    if (e.weapon === undefined) e.weapon = assignWeapon(e);
    if (!e.weapon || e.ko > 0) return;
    if (e.shootCd === undefined) e.shootCd = SHOOT_CD;
    e.cd = 999;                                  // desliga o tiro padrão do loop de IA da engine
    const sees = e.state === 'CHASE' && los(e, P);
    e.combatLock = sees;                         // para de correr em linha reta
    if (!sees) return;
    e.a = Math.atan2(P.y - e.y, P.x - e.x);      // alinha o ângulo ao jogador
    e.shootCd--;
    if (e.shootCd <= 0) { fire(e); e.shootCd = SHOOT_CD; }
  }

  // ---------- nocaute por arremesso: 'downed' por 180 frames, imóvel ----------
  function down(e) {
    e.downed = true; e.downT = DOWN_FRAMES; e.ko = 0; e.iframe = 0; e.combatLock = true;
    e.stun = Math.max(e.stun || 0, .05);
    popup(e.x, e.y - 22, 'NOCAUTE!', '#c9ced8');
    burstSparks(e.x, e.y, 10, ['#c9ced8', '#ffffff'], 180);
    triggerScreenShake(4, .1);
  }
  function downedTick(e) {
    e.downT--;
    // o loop de IA da engine pula inimigos com stun > 0: enquanto estiver caído, fica imóvel e sem ataque de contato
    e.stun = Math.max(e.stun || 0, .05);
    if (e.downT <= 0) {
      e.downed = false; e.stun = 0; e.combatLock = false;
      e.lkp = { x: P.x, y: P.y }; setEnemyState(e, 'SEARCH', 1.5);
    }
  }

  // ---------- execução no chão ----------
  C.nearDowned = function () {
    let best = null, bd = 44;
    for (const e of enemies) if (e.downed && !e.exec) {
      const d = Math.hypot(e.x - P.x, e.y - P.y);
      if (d < bd) { bd = d; best = e; }
    }
    return best;
  };
  C.startExec = function (e) {
    e.exec = true;
    C.execs.push({ e, t: EXEC_FRAMES });
    popup(e.x, e.y - 24, 'EXECUÇÃO!', '#ff2e93');
  };
  function finishExec(e) {
    if (!enemies.includes(e)) return;
    const ang = Math.atan2(e.y - P.y, e.x - P.x);
    triggerScreenShake(15, .3);                              // camera.shake = 15
    if (EXP.bloodSplat) EXP.bloodSplat(e.x, e.y, ang, 3);    // 3 poças direcionais
    e.alive = false; e.downed = false; e.exec = false;
    e.hp = 1; e.iframe = 0;                                  // garante a morte (sem o ramo de blindado/chefe)
    kill(e, Math.cos(ang) * 300, Math.sin(ang) * 300);
  }
  function execTick() {
    for (let i = C.execs.length - 1; i >= 0; i--) {
      const x = C.execs[i];
      x.t--;
      if (P) P.inv = Math.max(P.inv, FIXED * 2);             // ninguém causa dano durante o golpe
      if (x.t > 0) continue;
      C.execs.splice(i, 1);
      finishExec(x.e);
    }
  }

  // ---------- travamento de movimento: jogador e IA durante a execução ----------
  const _move = move;
  move = function (e, dx, dy) {
    if (e === P) { if (C.execs.length) return; }
    else if (C.execs.length || e.combatLock || e.downed) return;
    _move(e, dx, dy);
  };

  // ---------- tick do combate (um por passo fixo, ou seja, por frame) ----------
  C.tick = function (dt) {
    if (st !== 'play' || !P) return;
    lethalTick(dt);
    if (st !== 'play') return;
    for (const e of enemies) {
      if (e.downed) downedTick(e); else armedAI(e);
    }
    execTick();
  };
  C.down = down;
})();
