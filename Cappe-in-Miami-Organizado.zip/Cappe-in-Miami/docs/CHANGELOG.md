# Cappe in Miami — v4

## Novidades
- 74 mapas originais do Hotline Neon (maps.js) jogáveis: aparecem no seletor "Mapa" com o prefixo ★ (sem menus, créditos ou cutscenes).
- História estendida: 12 capítulos novos (Expansão 1 a 12) que usam mapas originais, depois dos 14 capítulos já existentes. Total: 26.
- Portas dos mapas originais: abrem, giram e atordoam quem está atrás (mesmo sistema de portas da v3).
- Fase de mapa original com carro: a saída é o carro. Sem carro: é preciso sair e voltar à área de início.
- Armas dos mapas originais viram armas da Cappe (distribuídas de forma determinística).

## Notas
- Mapas originais são de uma só planta: sem escada/elevador.
- Inimigos dos mapas originais viram inimigos da Cappe (faca = corpo a corpo, demais = atiradores).
- As salas de teste (rmTestLevel1 a 10) têm inimigos e entram no seletor. Não estão na história.
- maps.js e collision_sizes.js devem ficar na mesma pasta do index.html.

## Correção
- Em mapas sem carro, a sala limpa avançava na hora se o último inimigo caísse perto do início. Agora a saída só conta depois que o jogador sai da área.
