# Cappe-in-Miami

Projeto do jogo organizado em uma única pasta.

## Como iniciar
Abra `index.html` no navegador. Se o navegador bloquear algum recurso local, abra a pasta pelo VS Code e execute com a extensão Live Server.

## Estrutura
- `index.html`: tela principal e ponto de entrada do jogo.
- `js/`: scripts de mapas e tamanhos de colisão.
- `assets/`: sprites, tilesets e demais imagens do jogo, mantendo as subpastas originais.
- `docs/`: histórico de alterações.

Os arquivos de recursos foram mantidos e os caminhos dos dois scripts foram atualizados para a nova pasta `js/`.
