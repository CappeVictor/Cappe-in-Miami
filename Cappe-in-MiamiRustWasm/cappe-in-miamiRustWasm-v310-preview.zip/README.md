# Cappe in Miami — Rust/WASM v310
1. Instale Node.js 18 ou superior.
2. Execute INICIAR_EXPERIMENTO_WASM.bat com duplo clique.
3. Mantenha a janela do servidor aberta enquanto joga.
Este pacote inclui o renderer Rust/WASM compilado; não exige instalar Rust. Código-fonte, testes e histórico: https://github.com/CappeVictor/Cappe-in-Miami