# Cappe in Miami — Rust/WASM v309
1. Instale Node.js 18 ou superior.
2. Execute INICIAR_EXPERIMENTO_WASM.bat com duplo clique.
3. Mantenha a janela do servidor aberta enquanto joga.
Esta prévia inclui o renderer Rust/WASM já compilado; não exige instalar Rust para jogar. Código, testes e histórico completo: https://github.com/CappeVictor/Cappe-in-Miami