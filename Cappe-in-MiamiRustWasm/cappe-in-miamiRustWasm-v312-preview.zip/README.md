# Cappe-in-Miami Rust/WASM v312

1. Instale Node.js 18 ou superior.
2. Execute INICIAR_EXPERIMENTO_WASM.bat.
3. Mantenha a janela do servidor aberta enquanto joga.