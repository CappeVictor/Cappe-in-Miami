# Cappe-in-Miami Rust/WASM v313

Execute INICIAR_EXPERIMENTO_WASM.bat. Requer Node.js 18 ou superior. Este pacote inclui o renderer Rust compilado para WebAssembly.