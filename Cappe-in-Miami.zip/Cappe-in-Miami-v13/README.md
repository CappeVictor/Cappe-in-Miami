# Cappe in Miami — v5 (Expansão)

Abra `index.html` no navegador (ou use o Live Server do VS Code se o navegador bloquear algum recurso local).

## Estrutura
- `index.html`: jogo base (inalterado, exceto 10 ganchos `EXP.*`).
- `js/maps.js`, `js/collision_sizes.js`: mapas e colisões originais.
- `js/exp-core.js`: salvamento v2 (backup, migração, exportar/importar), XP, perks, conquistas, ranking.
- `js/exp-content.js`: 30 máscaras, 23 armas, 6 chefes, regras de desbloqueio.
- `js/exp-world.js`: IA por classe, chefes, barris, câmeras/alarme, eventos, recarga.
- `js/exp-modes.js`: 8 modos novos + Diário/Personalizado, notas até SS, resumo por sala, HUD.
- `js/exp-fx.js`: clima, luzes, escuridão, transições, SFX, música dinâmica, volumes.
- `js/exp-ui.js`: telas de modos, perfil/coleção, resumo, resultado, opções.
- `js/exp-debug.js`: ferramentas de desenvolvedor (desligadas por padrão).
- `css/expansion.css`: estilos das telas novas.
- `assets/`: inalterado. As máscaras novas são geradas por código.

## Controles novos
`C` recarregar · `B` (na pausa) voltar ao menu.

## Modo desenvolvedor
Abra `index.html?dev=1`. F3 painel · F4 colisões · F6 IA · F7 próximo mapa · F8 reiniciar · F9 erros · F10 chefe.

## Salvamento
Automático em `localStorage` (`hm_save_v2`) com backup rotativo (`hm_save_v2_bak`). Dados da v4 (recorde, desbloqueio) são migrados. Perfil & Coleção → Dados exporta/importa o save.

Backup do projeto original: ver o ZIP `Cappe-in-Miami-v4-original.zip`.

## v5.1
- `docs/CODIGO_NOVO.md`: todo o código novo da campanha em tiles, personagens, IA e vidros, separado por arquivo.
- Personagem: escolhido na tela de máscaras. Campanha: Modos de Jogo → Campanha: 3 Fases.
- Tiles de `TILE_LEVELS` (maps.js): 0 chão, 1 parede, 2 vidro, 3 porta, 4 início, 5 inimigo corpo a corpo, 6 inimigo armado. As GRIDS antigas do index.html não mudaram (lá 2 continua parede).
