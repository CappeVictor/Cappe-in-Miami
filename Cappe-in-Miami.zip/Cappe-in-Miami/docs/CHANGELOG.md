# Cappe in Miami — v4

## Novidades
- 74 mapas originais do Hotline Neon (maps.js) jogáveis: aparecem no seletor "Mapa" com o prefixo ★ (sem menus, créditos ou cutscenes).
- História estendida: 12 capítulos novos (Expansão 1 a 12) que usam mapas originais, depois dos 14 capítulos já existentes. Total: 26.
- Portas dos mapas originais: abrem, giram e atordoam quem está atrás (mesmo sistema de portas da v3).
- Fase de mapa original com carro: a saída é o carro. Sem carro: é preciso sair e voltar à área de início.
- Armas dos mapas originais viram armas da Cappe (distribuídas de forma determinística).

## Notas
- Mapas originais são de uma só planta: sem escada/elevador.
- Inimigos dos mapas originais viram inimigos da Cappe (faca = corpo a corpo, demais = atiradores).
- As salas de teste (rmTestLevel1 a 10) têm inimigos e entram no seletor. Não estão na história.
- maps.js e collision_sizes.js devem ficar na mesma pasta do index.html.

## Correção
- Em mapas sem carro, a sala limpa avançava na hora se o último inimigo caísse perto do início. Agora a saída só conta depois que o jogador sai da área.

# Cappe in Miami — v5 (Expansão)

## Novo
- Modos: Horda (chefe a cada 5 ondas), Sobrevivência (180 s), Arcade (fichas), Contrarrelógio, Assassino, Limpeza, Invasão, Desafio Diário (por data), Personalizado (mapa, máscara, arma, inimigos, dificuldade, velocidade, vida, 7 modificadores).
- 16 máscaras novas (total 30) com raridade, condição de desbloqueio e arte própria.
- 11 armas novas (total 23): pente, recarga (C), recuo, perfuração, durabilidade (garrafa).
- IA: classes (corredor, blindado, atirador com laser de aviso, líder), comunicação, reação a companheiros caídos e portas, recuo.
- 6 chefes com fases, padrões próprios, introdução/encerramento, barra de vida e música própria.
- Mapas: barris explosivos, câmeras de segurança e alarme, eventos aleatórios (apagão, reforços, alarme geral).
- Atmosfera: chuva, neblina, fumaça, poeira, neon, luzes, escuridão com lanterna, transição cinematográfica.
- Áudio: SFX por arma/porta/passos/explosão, ambiente em loop, 3 faixas novas + 3 de chefe, música por intensidade, volumes separados.
- Progressão: níveis (40), XP, pontos de habilidade (6 perks), 24 conquistas, ranking local, estatísticas.
- Notas D–SS, bônus (velocidade, precisão, variedade, cenário, sem detecção), resumo ao fim de cada sala.
- Salvamento v2 com backup, migração e exportar/importar.
- Ferramentas de depuração (?dev=1).

## Não incluído nesta versão (honestamente)
- 20 personagens com sprites/animações próprios, campanha de 100 fases, 15 chefes (há 6), cobertura/flanco na IA, janelas/áreas secretas. Cada um exige arte ou conteúdo de grande volume; a estrutura de dados já comporta a adição.
