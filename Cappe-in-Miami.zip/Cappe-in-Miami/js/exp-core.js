/* Cappe in Miami - Expansão | NÚCLEO
   Salvamento versionado (com backup e migração), XP/níveis, pontos de habilidade,
   conquistas, ranking local e avisos (toasts). Não depende de nenhum outro exp-*.js. */
(function () {
  'use strict';
  const EXP = window.EXP;
  const KEY = 'hm_save_v2', BAK = 'hm_save_v2_bak';
  const MAXLV = 40;

  const defSave = () => ({
    v: 2, created: Date.now(), saved: 0,
    xp: 0, level: 1, sp: 0, perks: {},
    stats: { kills: 0, deaths: 0, rooms: 0, shots: 0, hits: 0, melee: 0, throwHits: 0, finishers: 0, playSec: 0, maxCombo: 0,
             bestScore: 0, runs: 0, sRanks: 0, ssRanks: 0, bossKills: 0, barrels: 0, cameras: 0, flawless: 0 },
    records: {},          // por modo: { best, wave, time, rooms }
    ranking: {},          // por modo: top 10
    ach: {}, unl: [], bosses: {}, weaponsUsed: {}, masksUsed: {}, flags: {}, daily: {},
    settings: { musVol: .8, sfxVol: .8 }
  });

  // mescla recursiva: campos novos de versões futuras nunca quebram um save antigo
  function merge(base, src) {
    if (!src || typeof src !== 'object') return base;
    for (const k of Object.keys(src)) {
      if (base[k] && typeof base[k] === 'object' && !Array.isArray(base[k])) base[k] = merge(base[k], src[k]);
      else base[k] = src[k];
    }
    return base;
  }
  function readKey(k) { try { const r = localStorage.getItem(k); return r ? JSON.parse(r) : null; } catch (e) { return null; } }
  function valid(o) { return o && typeof o === 'object' && o.v >= 1 && typeof o.level === 'number' && o.stats; }

  function migrate(sv) {   // traz dados das versões anteriores (v4) sem apagá-los
    try {
      const hi = +localStorage.getItem('hm_hiscore') || 0;
      if (hi > (sv.records.classico && sv.records.classico.best || 0)) sv.records.classico = Object.assign({}, sv.records.classico, { best: hi });
      if (localStorage.getItem('hm_unlock') === '1') sv.flags.hardcoreWon = true;
      sv.stats.bestScore = Math.max(sv.stats.bestScore, hi);
    } catch (e) {}
    return sv;
  }

  let SAVE = null, dirty = false, saveT = 0, lastBak = 0;
  function load() {
    let d = readKey(KEY);
    if (!valid(d)) { const b = readKey(BAK); if (valid(b)) { d = b; EXP.log && EXP.log('save principal inválido: restaurado do backup'); } else d = null; }
    SAVE = d ? merge(defSave(), d) : migrate(defSave());
    return SAVE;
  }
  function flush(force) {
    if (!SAVE || (!dirty && !force)) return;
    try {
      const prev = localStorage.getItem(KEY);
      if (prev && Date.now() - lastBak > 20000) { localStorage.setItem(BAK, prev); lastBak = Date.now(); }   // backup rotativo
      SAVE.saved = Date.now(); localStorage.setItem(KEY, JSON.stringify(SAVE)); dirty = false;
    } catch (e) { EXP.log && EXP.log('falha ao salvar: ' + e.message); }
  }
  function touch() { dirty = true; clearTimeout(saveT); saveT = setTimeout(() => flush(), 1500); }   // salvamento automático (agrupado)
  function exportSave() {
    flush(true);
    const blob = new Blob([JSON.stringify(SAVE, null, 1)], { type: 'application/json' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'cappe-in-miami-save.json';
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }
  function importSave(text) {
    let o; try { o = JSON.parse(text); } catch (e) { return 'Arquivo inválido (não é JSON).'; }
    if (!valid(o)) return 'Este arquivo não é um save do Cappe in Miami.';
    try { localStorage.setItem(BAK, JSON.stringify(SAVE)); } catch (e) {}
    SAVE = merge(defSave(), o); flush(true); EXP.recheck(); return '';
  }
  function resetSave() { try { localStorage.setItem(BAK, JSON.stringify(SAVE)); } catch (e) {} SAVE = defSave(); flush(true); }

  // ---------- XP / níveis / perks ----------
  const xpNeed = l => Math.round(90 * Math.pow(l, 1.45));
  const PERKS = [
    { id: 'agil',    nome: 'Pés Leves',   max: 5, desc: '+3% de velocidade por nível.' },
    { id: 'furtivo', nome: 'Sombra',      max: 5, desc: 'Inimigos te veem 20 px mais tarde e ouvem 4% menos por nível.' },
    { id: 'municao', nome: 'Bolsos Fundos', max: 5, desc: '+3 de munição inicial por nível.' },
    { id: 'folego',  nome: 'Embalo',      max: 5, desc: '+0,2 s na janela de combo por nível.' },
    { id: 'pele',    nome: 'Pele Grossa', max: 3, desc: 'Nível 1: +1 colete por sala. Nível 3: +2.' },
    { id: 'pontaria', nome: 'Mira Firme', max: 5, desc: 'Reduz a dispersão dos tiros em 6% por nível.' },
  ];
  function perk(id) { return (SAVE.perks[id] || 0); }
  function buyPerk(id) {
    const p = PERKS.find(x => x.id === id); if (!p) return false;
    if (SAVE.sp < 1 || perk(id) >= p.max) return false;
    SAVE.sp--; SAVE.perks[id] = perk(id) + 1; touch(); return true;
  }
  function addXP(n, why) {
    n = Math.round(n * ((typeof S !== 'undefined' && S.xp) || 1) * (EXP.xpMul || 1)); if (n <= 0) return 0;
    SAVE.xp += n;
    while (SAVE.level < MAXLV && SAVE.xp >= xpNeed(SAVE.level)) {
      SAVE.xp -= xpNeed(SAVE.level); SAVE.level++;
      SAVE.sp += 1 + (SAVE.level % 5 === 0 ? 1 : 0);
      toast('NÍVEL ' + SAVE.level, '+' + (1 + (SAVE.level % 5 === 0 ? 1 : 0)) + ' ponto(s) de habilidade', '#ffd23f');
      EXP.checkUnlocks();
    }
    if (SAVE.level >= MAXLV) SAVE.xp = Math.min(SAVE.xp, xpNeed(MAXLV));
    touch(); if (EXP.run) EXP.run.xp = (EXP.run.xp || 0) + n; return n;
  }

  // ---------- toasts (lista fixa, sem criar objetos por quadro) ----------
  const toasts = [];
  function toast(t, sub, c) { toasts.push({ t, sub: sub || '', c: c || '#19f0e6', life: 3.2 }); if (toasts.length > 5) toasts.shift(); }

  // ---------- conquistas ----------
  const ACH = [
    { id: 'primeiro',  nome: 'Primeiro Sangue',     desc: 'Derrote um inimigo.',                       test: s => s.stats.kills >= 1 },
    { id: 'k100',      nome: 'Faxineiro',           desc: 'Derrote 100 inimigos.',                     test: s => s.stats.kills >= 100 },
    { id: 'k500',      nome: 'Ceifador',            desc: 'Derrote 500 inimigos.',                     test: s => s.stats.kills >= 500 },
    { id: 'k2000',     nome: 'Lenda de Miami',      desc: 'Derrote 2000 inimigos.',                    test: s => s.stats.kills >= 2000 },
    { id: 'rank_s',    nome: 'Estilo',              desc: 'Consiga nota S em uma sala.',               test: s => s.stats.sRanks >= 1 },
    { id: 'rank_ss',   nome: 'Perfeição',           desc: 'Consiga nota SS em uma sala.',              test: s => s.stats.ssRanks >= 1 },
    { id: 'combo10',   nome: 'Frenesi',             desc: 'Chegue a um combo de 10x.',                 test: s => s.stats.maxCombo >= 10 },
    { id: 'combo20',   nome: 'Sem Freio',           desc: 'Chegue a um combo de 20x.',                 test: s => s.stats.maxCombo >= 20 },
    { id: 'horda10',   nome: 'Maré Alta',           desc: 'Chegue à onda 10 no Modo Horda.',           test: s => (s.records.horda && s.records.horda.wave || 0) >= 10 },
    { id: 'horda20',   nome: 'Inabalável',          desc: 'Chegue à onda 20 no Modo Horda.',           test: s => (s.records.horda && s.records.horda.wave || 0) >= 20 },
    { id: 'chefe1',    nome: 'Caça-Chefes',         desc: 'Derrote um chefe.',                         test: s => s.stats.bossKills >= 1 },
    { id: 'chefe6',    nome: 'Rei da Pista',        desc: 'Derrote todos os chefes disponíveis.',      test: s => Object.keys(s.bosses).length >= (EXP.bosses ? EXP.bosses.length : 99) },
    { id: 'surv',      nome: 'Sobrevivente',        desc: 'Complete o Modo Sobrevivência.',            test: s => !!s.flags.survWon },
    { id: 'arcade',    nome: 'Moedas Infinitas',    desc: 'Zere o Modo Arcade.',                       test: s => !!s.flags.arcadeWon },
    { id: 'fantasma',  nome: 'Fantasma',            desc: 'Vença o Modo Assassino sem ser detectado.', test: s => !!s.flags.ghostWon },
    { id: 'diario',    nome: 'Rotina',              desc: 'Complete um Desafio Diário.',               test: s => Object.keys(s.daily).length >= 1 },
    { id: 'barris',    nome: 'Pirotécnico',         desc: 'Exploda 10 barris.',                        test: s => s.stats.barrels >= 10 },
    { id: 'cameras',   nome: 'Ponto Cego',          desc: 'Destrua 5 câmeras de segurança.',           test: s => s.stats.cameras >= 5 },
    { id: 'variedade', nome: 'Arsenal',             desc: 'Use 5 armas diferentes na mesma sala.',     test: s => !!s.flags.variety5 },
    { id: 'impecavel', nome: 'Impecável',           desc: 'Complete 5 salas sem ser detectado.',       test: s => s.stats.flawless >= 5 },
    { id: 'hist',      nome: 'Fim da Linha',        desc: 'Termine o Modo História.',                  test: s => !!s.flags.storyWon },
    { id: 'pontos50k', nome: 'Placar Estourado',    desc: 'Faça 50.000 pontos em uma partida.',        test: s => s.stats.bestScore >= 50000 },
    { id: 'nivel10',   nome: 'Veterano',            desc: 'Chegue ao nível 10.',                       test: s => s.level >= 10 },
    { id: 'nivel25',   nome: 'Elite',               desc: 'Chegue ao nível 25.',                       test: s => s.level >= 25 },
  ];
  function checkAch() {
    for (const a of ACH) if (!SAVE.ach[a.id] && a.test(SAVE)) { SAVE.ach[a.id] = Date.now(); toast('CONQUISTA', a.nome, '#ff2e93'); touch(); EXP.checkUnlocks(); }
  }

  // ---------- ranking local ----------
  function addRank(mode, entry) {
    const L = SAVE.ranking[mode] || (SAVE.ranking[mode] = []);
    entry.date = new Date().toISOString().slice(0, 10); L.push(entry); L.sort((a, b) => b.score - a.score); if (L.length > 10) L.length = 10;
    const pos = L.indexOf(entry); touch(); return pos;   // -1 se ficou fora do top 10
  }
  function setRecord(mode, key, val, lowerBetter) {
    const R = SAVE.records[mode] || (SAVE.records[mode] = {}), old = R[key];
    if (old === undefined || (lowerBetter ? val < old : val > old)) { R[key] = val; touch(); return true; } return false;
  }

  load();
  Object.assign(EXP, {
    MAXLV, PERKS, ACH, xpNeed, perk, buyPerk, addXP, toast, toasts, checkAch, addRank, setRecord,
    save: () => SAVE, flush, touch, exportSave, importSave, resetSave, reload: load,
  });
  addEventListener('pagehide', () => flush(true));
  document.addEventListener('visibilitychange', () => { if (document.hidden) flush(true); });
  setInterval(() => flush(), 8000);
})();
