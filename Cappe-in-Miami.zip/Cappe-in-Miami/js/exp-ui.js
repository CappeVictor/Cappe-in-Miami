/* Cappe in Miami - Expansão | INTERFACE
   Seleção de modos, modo personalizado, perfil/coleção/conquistas/recordes, resumo por sala,
   tela de resultado, volume e gerenciamento de dados de salvamento. */
(function () {
  'use strict';
  const EXP = window.EXP, MODES = EXP.MODES, stage = document.querySelector('.stage');
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const mk = (id, html) => { const s = document.createElement('section'); s.id = id; s.className = 'overlay exp oculto'; s.innerHTML = html; stage.insertBefore(s, document.querySelector('.scan')); return s; };
  const screens = [];
  const open = el => { hideAll(); menu.classList.add('oculto'); el.classList.remove('oculto'); st = 'expui'; };
  const back = () => { hideAll(); toMenu(); };
  function hideAll() { screens.forEach(s => s.classList.add('oculto')); }

  // ---------- menu principal ----------
  const row = document.createElement('div'); row.className = 'menu-row';
  row.innerHTML = '<button id="modosBtn" type="button">Modos de Jogo</button><button id="perfilBtn" type="button" class="sec">Perfil &amp; Coleção</button>';
  $('histBtn').after(row);
  document.querySelector('.controles').insertAdjacentHTML('beforeend', '<li><b>C</b>: recarregar (armas com pente) &nbsp; <b>ESC</b>: pausar &nbsp; <b>B</b> (pausa): menu</li>');
  const lvlTag = document.createElement('p'); lvlTag.className = 'dica'; lvlTag.id = 'lvlTag'; $('jogar').before(lvlTag);
  function refreshTag() { const s = EXP.save(); lvlTag.textContent = 'Nível ' + s.level + ' · ' + s.sp + ' ponto(s) de habilidade · ' + Object.keys(s.ach).length + '/' + EXP.ACH.length + ' conquistas'; }
  refreshTag();
  $('jogar').onclick = () => { EXP.pending = null; showMasks(); };
  const _toMenu = toMenu; toMenu = function () { _toMenu(); refreshTag(); };

  // ---------- MODOS ----------
  const sModos = mk('expModos', '<h2>Modos de Jogo</h2><div class="modos" id="modoCards"></div><div class="detalhe" id="modoDet"></div><div class="linha"><button id="modoGo" type="button">Jogar</button><button id="modoBack" type="button" class="sec">Voltar</button></div>');
  screens.push(sModos);
  let curMode = 'horda', curMap = 'rand';
  const list = Object.values(MODES).filter(m => !m.hidden);
  const cards = $('modoCards');
  list.forEach(m => { const b = document.createElement('button'); b.type = 'button'; b.className = 'card'; b.dataset.id = m.id; b.style.setProperty('--c', m.color); b.innerHTML = '<b>' + m.nome + '</b>' + esc(m.desc); b.onclick = () => selMode(m.id); cards.appendChild(b); });
  function selMode(id) {
    curMode = id; const m = MODES[id], rec = EXP.save().records[id] || {};
    [...cards.children].forEach(c => c.classList.toggle('on', c.dataset.id === id));
    let recTxt = rec.best ? 'Recorde: ' + rec.best + ' pts' + (rec.wave ? ' · onda ' + rec.wave : '') + (rec.time ? ' · ' + rec.time + ' s' : '') + (rec.rooms ? ' · ' + rec.rooms + ' salas' : '') : 'Sem recorde ainda';
    let extra = '';
    if (m.map) extra = '<label>Arena: <select id="arenaSel"><option value="rand">Aleatória</option>' + EXP.ARENAS.map(a => '<option value="' + a + '"' + (a === curMap ? ' selected' : '') + '>' + (MAPAS.find(x => x.id === a) || { nome: a }).nome + '</option>').join('') + '</select></label>';
    if (id === 'diario') { const d = EXP.dailyInfo(), done = EXP.save().daily[d.date]; extra = '<p>Hoje (' + d.date + '): máscara <b>' + MASKS[d.mask].nome + '</b>, arma inicial <b>' + WP[d.weapon].nome + '</b>, modificador <b>' + EXP.MODS[d.mod].nome + '</b>.' + (done ? ' <span class="rec">Melhor de hoje: ' + done.score + '</span>' : '') + '</p>'; }
    $('modoDet').innerHTML = '<b style="color:' + m.color + '">' + m.nome.toUpperCase() + '</b> — ' + esc(m.desc) + '<ul>' + m.rules.map(r => '<li>' + esc(r) + '</li>').join('') + '</ul><div>Recompensa: ' + esc(m.reward) + '</div><div class="rec">' + recTxt + '</div>' + extra;
    const a = $('arenaSel'); if (a) a.onchange = () => { curMap = a.value; };
  }
  $('modosBtn').onclick = () => { open(sModos); selMode(curMode); };
  $('modoBack').onclick = back;
  $('modoGo').onclick = () => { if (curMode === 'custom') { openCustom(); return; } EXP.startMode(curMode, { map: curMap }); };

  // ---------- PERSONALIZADO ----------
  const sCust = mk('expCust', '<h2>Partida Personalizada</h2><div class="form" id="custForm"></div><p class="aviso">Partidas personalizadas dão 50% do XP e não contam para os recordes oficiais.</p><div class="linha"><button id="custGo" type="button">Começar</button><button id="custBack" type="button" class="sec">Voltar</button></div>');
  screens.push(sCust);
  function openCustom() {
    const maps = [['seq', 'Sequência'], ['proc', 'Apartamento aleatório'], ...MAPAS.filter(m => m.id !== 'boate-b').map(m => [m.id, m.nome])];
    const unlockedMasks = MASKS.map((m, i) => [i, m.nome]).filter(([i]) => !EXP.maskLocked(i));
    const guns = [['pistola', 'Pistola'], ...Object.keys(WP).filter(k => k !== 'punho' && k !== 'pistola' && EXP.weaponUnlocked(k)).map(k => [k, WP[k].nome])];
    const sel = (id, opts, d) => '<select id="' + id + '">' + opts.map(([v, t]) => '<option value="' + v + '"' + (v == d ? ' selected' : '') + '>' + t + '</option>').join('') + '</select>';
    $('custForm').innerHTML = '<label>Mapa ' + sel('c-map', maps, 'seq') + '</label><label>Máscara ' + sel('c-mask', unlockedMasks, 0) + '</label><label>Arma inicial ' + sel('c-wp', guns, 'pistola') + '</label>' +
      '<label>Dificuldade ' + sel('c-dif', [['facil', 'Fácil'], ['medio', 'Médio'], ['dificil', 'Difícil'], ['hardcore', 'Hardcore']], 'medio') + '</label><label>Quantidade de inimigos ' + sel('c-en', [[.5, 'Metade'], [1, 'Normal'], [1.5, '+50%'], [2, 'Dobro']], 1) + '</label>' +
      '<label>Velocidade dos inimigos ' + sel('c-foe', [[.8, 'Lenta'], [1, 'Normal'], [1.25, 'Rápida'], [1.5, 'Muito rápida']], 1) + '</label><label>Vida (coletes extra) ' + sel('c-life', [[0, '0'], [1, '+1'], [2, '+2'], [3, '+3']], 0) + '</label><label>Número de salas ' + sel('c-rooms', [[3, '3'], [5, '5'], [8, '8'], [12, '12']], 5) + '</label>' +
      '<div class="mods">' + Object.entries(EXP.MODS).map(([k, m]) => '<label title="' + esc(m.desc) + '"><input type="checkbox" data-mod="' + k + '"> ' + m.nome + '</label>').join('') + '</div>';
    open(sCust);
  }
  $('custBack').onclick = () => open(sModos);
  $('custGo').onclick = () => {
    const v = id => $(id).value, mods = [...document.querySelectorAll('#custForm [data-mod]')].filter(c => c.checked).map(c => c.dataset.mod);
    EXP.startMode('custom', { map: v('c-map'), mask: +v('c-mask'), weapon: v('c-wp'), dif: v('c-dif'), enemies: +v('c-en'), foe: +v('c-foe'), life: +v('c-life'), rooms: +v('c-rooms'), mods });
  };

  // ---------- PERFIL & COLEÇÃO ----------
  const sPerfil = mk('expPerfil', '<h2>Perfil &amp; Coleção</h2><div class="tabs" id="tabs"></div><div class="painel" id="painel"></div><div class="linha"><button id="perfBack" type="button" class="sec">Voltar</button></div>');
  screens.push(sPerfil);
  const TABS = [['perfil', 'Progresso'], ['mascaras', 'Máscaras'], ['armas', 'Armas'], ['chefes', 'Chefes'], ['conq', 'Conquistas'], ['rank', 'Recordes'], ['dados', 'Dados']];
  let tab = 'perfil';
  const tabs = $('tabs'); TABS.forEach(([id, t]) => { const b = document.createElement('button'); b.type = 'button'; b.dataset.id = id; b.textContent = t; b.onclick = () => showTab(id); tabs.appendChild(b); });
  const fmtT = s => Math.floor(s / 3600) + 'h ' + Math.floor(s % 3600 / 60) + 'min';
  function showTab(id) {
    tab = id; [...tabs.children].forEach(b => b.classList.toggle('on', b.dataset.id === id));
    const sv = EXP.save(), p = $('painel'); let h = '';
    if (id === 'perfil') {
      const need = EXP.xpNeed(sv.level), s = sv.stats, acc = s.shots ? Math.round(s.hits / s.shots * 100) + '%' : '—';
      h = '<b>Nível ' + sv.level + '</b> — XP ' + sv.xp + ' / ' + need + (sv.level >= EXP.MAXLV ? ' (máx.)' : '') + '<div class="xpbar"><i style="width:' + Math.min(100, sv.xp / need * 100) + '%"></i></div>' +
        '<p><b style="color:var(--amarelo)">Pontos de habilidade: ' + sv.sp + '</b></p>' + EXP.PERKS.map(p => { const l = EXP.perk(p.id); return '<div class="perk"><span style="min-width:8em"><b>' + p.nome + '</b></span><span class="pips">' + '■'.repeat(l) + '□'.repeat(p.max - l) + '</span><button type="button" data-perk="' + p.id + '"' + (sv.sp < 1 || l >= p.max ? ' disabled' : '') + '>+</button><span>' + p.desc + '</span></div>'; }).join('') +
        '<h4 style="color:var(--ciano);margin:.6rem 0 .2rem">ESTATÍSTICAS</h4><div class="stats">' + [['Abates', s.kills], ['Mortes', s.deaths], ['Salas', s.rooms], ['Partidas', s.runs], ['Precisão geral', acc], ['Maior combo', s.maxCombo + 'x'], ['Melhor pontuação', s.bestScore], ['Notas S / SS', s.sRanks + ' / ' + s.ssRanks], ['Chefes', s.bossKills], ['Finalizações', s.finishers], ['Barris explodidos', s.barrels], ['Câmeras destruídas', s.cameras], ['Salas sem detecção', s.flawless], ['Tempo de jogo', fmtT(s.playSec)], ['Corpo a corpo', s.melee]].map(([a, b]) => '<span>' + a + ': <b>' + b + '</b></span>').join('') + '</div>';
    } else if (id === 'mascaras') {
      const got = MASKS.filter((m, i) => !EXP.maskLocked(i)).length;
      h = '<p>' + got + ' / ' + MASKS.length + ' máscaras desbloqueadas</p><div class="col">' + MASKS.map((m, i) => { const lk = EXP.maskLocked(i), r = EXP.RAR[m.rar]; return '<div class="item' + (lk ? ' lk' : '') + '" style="border-color:' + r.c + '"><img src="' + (m.img.src || 'assets/' + m.id + '.png') + '" alt=""><b>' + (lk ? '???' : m.nome) + '</b><small style="color:' + r.c + '">' + r.nome + '</small><small>' + (lk ? esc(EXP.unlockInfo(m.unl).txt) : esc(m.desc)) + '</small><small style="opacity:.7">' + (lk ? '' : EXP.maskTags(m).join(' · ')) + '</small></div>'; }).join('') + '</div>';
    } else if (id === 'armas') {
      h = '<div class="col">' + Object.keys(WP).filter(k => k !== 'punho').map(k => { const w = WP[k], lk = !EXP.weaponUnlocked(k), r = EXP.RAR[w.rar], used = sv.weaponsUsed[k] || 0;
        return '<div class="item' + (lk ? ' lk' : '') + '" style="border-color:' + r.c + '"><b>' + (lk ? '???' : w.nome) + '</b><small>' + w.cat + ' · <span style="color:' + r.c + '">' + r.nome + '</span></small><small>' + (lk ? 'Nível ' + w.lv : (w.melee ? 'Corpo a corpo · alcance ' + w.range : 'Cadência ' + (1 / w.cd).toFixed(1) + '/s · ' + (EXP.magOf(k) ? 'pente ' + EXP.magOf(k)[0] : 'sem pente') + (w.pel > 1 ? ' · ' + w.pel + ' projéteis' : ''))) + '</small><small style="opacity:.7">Usada ' + used + 'x</small></div>'; }).join('') + '</div>';
    } else if (id === 'chefes') {
      h = EXP.bosses.map(b => { const n = sv.bosses[b.id] || 0; return '<div class="item" style="border-color:' + b.col + ';margin-bottom:.4rem"><b style="color:' + b.col + '">' + b.nome + (n ? ' ✔ ×' + n : '') + '</b><small>Aparece na onda ' + b.wave + ' do Modo Horda · ' + b.phases.length + ' fases</small><small>' + (n ? esc(b.bio) : 'Derrote para revelar a história.') + '</small></div>'; }).join('') + '<p class="aviso">Chefes extras chegam em futuras atualizações (veja o CHANGELOG).</p>';
    } else if (id === 'conq') {
      h = EXP.ACH.map(a => { const ok = sv.ach[a.id]; return '<div class="ach' + (ok ? ' ok' : '') + '"><span><b>' + a.nome + '</b> — ' + a.desc + '</span><span>' + (ok ? '✔' : '—') + '</span></div>'; }).join('');
    } else if (id === 'rank') {
      const ids = Object.keys(MODES).filter(k => k !== 'historia');
      h = ids.map(k => { const L = sv.ranking[k] || []; return '<h4 style="color:var(--ciano);margin:.3rem 0">' + MODES[k].nome.toUpperCase() + '</h4>' + (L.length ? '<table class="rank-t"><tr><th>#</th><th>Pontos</th><th>Máscara</th><th>Resultado</th><th>Data</th></tr>' + L.slice(0, 5).map((e, i) => '<tr><td>' + (i + 1) + '</td><td>' + e.score + '</td><td>' + esc(e.mask) + '</td><td>' + esc(e.info) + (e.win ? ' ✔' : '') + '</td><td>' + e.date + '</td></tr>').join('') + '</table>' : '<p style="opacity:.6;margin:.1rem 0">sem registros</p>'); }).join('');
    } else if (id === 'dados') {
      h = '<p>O progresso é salvo automaticamente neste navegador, com cópia de segurança. Exporte um arquivo para guardar ou mover o seu save.</p><div class="linha"><button type="button" id="dExp">Exportar save</button><label class="sec" style="cursor:pointer;padding:.45rem 1rem;background:var(--amarelo);color:var(--noite);font:700 .95rem Orbitron">Importar save<input type="file" id="dImp" accept=".json,application/json" hidden></label><button type="button" id="dRes" class="sec">Restaurar backup</button></div><p id="dMsg" class="aviso"></p><p style="opacity:.6;font-size:.8rem">Última gravação: ' + (sv.saved ? new Date(sv.saved).toLocaleString() : '—') + '</p>';
    }
    p.innerHTML = h;
    p.querySelectorAll('[data-perk]').forEach(b => b.onclick = () => { if (EXP.buyPerk(b.dataset.perk)) { showTab('perfil'); refreshTag(); } });
    if (id === 'dados') {
      $('dExp').onclick = () => EXP.exportSave();
      $('dImp').onchange = e => { const f = e.target.files[0]; if (!f) return; const rd = new FileReader(); rd.onload = () => { const m = EXP.importSave(String(rd.result)); $('dMsg').textContent = m || 'Save importado com sucesso!'; refreshTag(); }; rd.readAsText(f); };
      $('dRes').onclick = () => { try { const b = JSON.parse(localStorage.getItem('hm_save_v2_bak')); if (b) { localStorage.setItem('hm_save_v2', JSON.stringify(b)); EXP.reload(); EXP.recheck(); $('dMsg').textContent = 'Backup restaurado.'; refreshTag(); } else $('dMsg').textContent = 'Nenhum backup disponível.'; } catch (e) { $('dMsg').textContent = 'Backup inválido.'; } };
    }
  }
  $('perfilBtn').onclick = () => { open(sPerfil); showTab(tab); };
  $('perfBack').onclick = back;

  // ---------- RESUMO POR SALA ----------
  const sSum = mk('expSum', '<p class="tag" id="sumT"></p><div class="nota" id="sumN"></div><div class="duas"><div><h4>DESEMPENHO</h4><div id="sumS"></div></div><div><h4>BÔNUS</h4><div id="sumB"></div></div></div><p id="sumX" class="novo"></p><button id="sumGo" type="button">Continuar</button><p class="dica">Enter continua</p>');
  screens.push(sSum); let sumCb = null;
  EXP.ui = {
    hideAll,
    summary(r, cb) {
      sumCb = cb; $('sumT').textContent = r.title; $('sumN').textContent = r.rank; $('sumN').className = 'nota ' + r.rank;
      $('sumS').innerHTML = r.stats.map(([a, b]) => '<p>' + a + '<b>' + b + '</b></p>').join('') + '<p>Pontos<b>' + r.score + '</b></p>';
      $('sumB').innerHTML = r.bonus.length ? r.bonus.map(([a, b]) => '<p>' + a + '<b>' + b + '</b></p>').join('') : '<p style="opacity:.6">sem bônus</p>';
      const un = EXP.takeNewUnlocks(); $('sumX').textContent = '+' + r.xp + ' XP · Nível ' + EXP.save().level + un.map(u => ' · NOVO: ' + u.label).join('');
      sSum.classList.remove('oculto'); $('sumGo').focus();
    },
    result(r) {
      EXP.takeNewUnlocks; const e = $('expRes'); $('resT').textContent = r.title; $('resT').style.color = r.win ? 'var(--ciano)' : 'var(--rosa)'; $('resSub').textContent = r.sub;
      $('resN').textContent = r.rank; $('resN').className = 'nota ' + r.rank; $('resR').textContent = r.rankText === '—' ? '' : 'Notas das salas: ' + r.rankText;
      $('resL').innerHTML = r.lines.map(([a, b]) => '<p>' + a + '<b>' + b + '</b></p>').join('');
      $('resX').innerHTML = '<p>XP ganho<b>+' + (r.xp || 0) + '</b></p><p>Nível<b>' + r.level + '</b></p>' + (r.record ? '<p class="novo">NOVO RECORDE!</p>' : '') + (r.pos >= 0 ? '<p class="novo">Ranking local: #' + (r.pos + 1) + '</p>' : '') + (r.unl || []).map(u => '<p class="novo">DESBLOQUEADO: ' + esc(u.label) + '</p>').join('');
      $('expRes').classList.remove('oculto'); $('resAgain').focus(); if (r.record) playSfx('record');
    },
  };
  $('sumGo').onclick = () => { sSum.classList.add('oculto'); const cb = sumCb; sumCb = null; if (cb) cb(); };
  const sRes = mk('expRes', '<h2 id="resT"></h2><p class="tag" id="resSub"></p><div class="nota" id="resN"></div><p id="resR" class="dica"></p><div class="duas"><div><h4>RESUMO</h4><div id="resL"></div></div><div><h4>PROGRESSO</h4><div id="resX"></div></div></div><div class="linha"><button id="resAgain" type="button">Jogar de novo</button><button id="resMask" type="button" class="sec">Trocar máscara</button><button id="resMenu" type="button" class="sec">Menu</button></div>');
  screens.push(sRes);
  $('resAgain').onclick = () => { sRes.classList.add('oculto'); newGame(); };
  $('resMask').onclick = () => { sRes.classList.add('oculto'); showMasks(); };
  $('resMenu').onclick = () => { sRes.classList.add('oculto'); toMenu(); };
  addEventListener('keydown', e => { if (e.key === 'Enter' && st === 'summary') { $('sumGo').click(); e.preventDefault(); } if (e.key === 'Escape' && st === 'expui') { back(); } });

  // ---------- OPÇÕES: áudio e dados ----------
  const fs = document.createElement('fieldset');
  fs.innerHTML = '<legend>ÁUDIO &amp; DADOS</legend><label>Volume da música <input type="range" id="o-musVol" min="0" max="1" step=".05"></label><label>Volume dos efeitos <input type="range" id="o-sfxVol" min="0" max="1" step=".05"></label><label><input type="checkbox" id="o-events"> Eventos aleatórios (apagão, reforços, alarme)</label><p class="dica">Ferramentas de desenvolvedor: abra com ?dev=1</p>';
  document.querySelector('#opcoes .opt-grid').appendChild(fs); $('opcoes').style.overflowY = 'auto'; $('opcoes').style.justifyContent = 'flex-start';
  const syncVol = () => { const s = EXP.save().settings; $('o-musVol').value = s.musVol; $('o-sfxVol').value = s.sfxVol; $('o-events').checked = s.events !== false; };
  $('o-musVol').oninput = e => EXP.setVol('musVol', +e.target.value); $('o-sfxVol').oninput = e => { EXP.setVol('sfxVol', +e.target.value); EXP.sfx('pistol'); };
  $('o-events').onchange = e => { EXP.save().settings.events = e.target.checked; EXP.touch(); };
  const _ob = $('optBtn').onclick; $('optBtn').onclick = () => { _ob(); syncVol(); };

  // ---------- grade de máscaras ----------
  EXP.cols = 10; EXP.rebuildMaskGrid(); EXP.recheck();
})();
