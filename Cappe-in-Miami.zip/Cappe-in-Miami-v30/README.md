# Cappe in Miami — v30 (Multiplayer Local + Menu)

Abra `index.html` no navegador (ou use o Live Server do VS Code se o navegador bloquear algum recurso local).

## Novidades v30
- **Menu redesenhado**: controles separados (solo / multiplayer), botão dedicado de Multiplayer Local, melhor hierarquia visual.
- **Multiplayer Local (2 jogadores)**:
  - P1: WASD + Mouse (mirar e atirar)
  - P2: Setas + Ctrl Direito (atirar) / . (soco) / / (pegar) / ; (largar)
  - Câmera segue o ponto médio (configurável: P1, P2 ou médio)
  - Modo de vidas: compartilhadas ou independentes
  - Fogo amigo opcional
- **Mais configurações** em Opções:
  - Seção MULTIPLAYER LOCAL completa
  - Volume mestre, sensibilidade do mouse, inverter Y
  - Mira customizada (cruz) com opacidade
  - Recarregar automático
  - Contador de FPS
- Arquivo novo: `js/exp-multi.js`

## Estrutura
- `index.html`: jogo base (inalterado, exceto 10 ganchos `EXP.*`).
- `js/maps.js`, `js/collision_sizes.js`: mapas e colisões originais.
- `js/exp-core.js`: salvamento v2 (backup, migração, exportar/importar), XP, perks, conquistas, ranking.
- `js/exp-content.js`: 30 máscaras, 23 armas, 6 chefes, regras de desbloqueio.
- `js/exp-world.js`: IA por classe, chefes, barris, câmeras/alarme, eventos, recarga.
- `js/exp-modes.js`: 8 modos novos + Diário/Personalizado, notas até SS, resumo por sala, HUD.
- `js/exp-fx.js`: clima, luzes, escuridão, transições, SFX, música dinâmica, volumes.
- `js/exp-ui.js`: telas de modos, perfil/coleção, resumo, resultado, opções.
- `js/exp-debug.js`: ferramentas de desenvolvedor (desligadas por padrão).
- `css/expansion.css`: estilos das telas novas.
- `assets/`: inalterado. As máscaras novas são geradas por código.

## Controles novos
`C` recarregar · `B` (na pausa) voltar ao menu.

## Modo desenvolvedor
Abra `index.html?dev=1`. F3 painel · F4 colisões · F6 IA · F7 próximo mapa · F8 reiniciar · F9 erros · F10 chefe.

## Salvamento
Automático em `localStorage` (`hm_save_v2`) com backup rotativo (`hm_save_v2_bak`). Dados da v4 (recorde, desbloqueio) são migrados. Perfil & Coleção → Dados exporta/importa o save.

Backup do projeto original: ver o ZIP `Cappe-in-Miami-v4-original.zip`.

## v5.1
- `docs/CODIGO_NOVO.md`: todo o código novo da campanha em tiles, personagens, IA e vidros, separado por arquivo.
- Personagem: escolhido na tela de máscaras. Campanha: Modos de Jogo → Campanha: 3 Fases.
- Tiles de `TILE_LEVELS` (maps.js): 0 chão, 1 parede, 2 vidro, 3 porta, 4 início, 5 inimigo corpo a corpo, 6 inimigo armado. As GRIDS antigas do index.html não mudaram (lá 2 continua parede).

## v14 — organização de menus
- Menu principal agora fica inteiro no `index.html`, em dois grupos: **Jogar / Modos de Jogo** (ações principais) e **Modo História / Perfil & Coleção** (telas secundárias). Opções fica abaixo.
- Tela de Opções montada no HTML: VÍDEO (inclui tamanho da tela), JOGABILIDADE, ÁUDIO & DADOS, IDIOMA. O JS só liga os eventos.
- Lista de controles do menu inclui a linha de `C` / `ESC` / `B` diretamente no HTML.
- Estilos que estavam no JS (rolagem de Opções) foram para `css/expansion.css`.

## v15 — otimização de desempenho
- `js/maps.js`: os tiles de cada mapa agora são decodificados só quando o mapa é usado (antes eram decodificados todos os 159 na abertura). Carregamento inicial ~2,8x mais rápido. Dados verificados: os 159 mapas são idênticos aos da v14.
- Inimigos: o brilho do anel usa um traço largo translúcido em vez de `shadowBlur` a cada quadro (visual parecido, bem mais barato).
- Sangue, faíscas e efeitos de texto são compactados no próprio array, sem criar novos arrays a cada quadro.
- Escala máxima do canvas em telas de alta densidade reduzida de 2,5x para 2x.
- Sugestão para hospedagem: servir o `maps.js` com compressão gzip (o arquivo de texto cai bastante de tamanho).

## v16 — carregamento
- Máscaras novas são desenhadas em canvas direto (antes: 23 PNGs gerados via toDataURL na abertura). Visual igual.
- Fonte do Google não bloqueia mais a primeira renderização (carrega em segundo plano; com fallback).
- `sw.js`: cache offline. Só funciona em http(s) (ex.: hospedagem ou Live Server); abrindo o index.html direto (file://) o jogo funciona normalmente, sem cache.
- ATENÇÃO: ao publicar uma versão nova, troque o número em `const CACHE = 'cappe-vNN'` dentro de `sw.js`, senão quem já visitou continua com a versão antiga.

## v17 — PCs fracos
- Ajuste automático: se a partida ficar abaixo de ~38 FPS nos primeiros 240 quadros, aplica "Desempenho máximo" uma única vez (marcado em `hm_perf_auto`). Para voltar, escolha outra predefinição em Opções.
- Filtro de brilho do canvas só é aplicado quando diferente de 100% (evita composição extra a cada quadro).

## v18 — otimização profunda (medida no Chromium, renderização por software)
Medição: 420 quadros por cenário, mesmo roteiro de jogo, v17 vs v18. Os testes de equivalência (colisão e distâncias) deram 0 divergências em 40 mil amostras.
- **Lanterna / escuridão**: os 3 gradientes radiais criados por quadro viraram sprites pré-renderizados, e a camada escura passou a meia resolução (4x menos pixels). Custo de `draw` no escuro: ~8 ms → ~0,6 ms.
- **Luzes de neon e clarão de tiro**: sprite guardado em cada luz, intensidade via `globalAlpha` (antes: 1 gradiente novo por luz por quadro).
- **Sangue parado**: desenhado uma única vez numa camada (antes: até 1.200 arcos a cada quadro). O corte do limite agora é em lote (1.500 → 1.200), para a camada quase nunca ser refeita.
- **Chão, móveis e sangue**: só a área visível da tela é copiada por quadro (`drawImage` com recorte).
- **`shadowBlur` removido de tudo que roda por quadro** (portas, escadas/elevador, itens, saída, atordoamento, barris, chefes, inimigos sem sprite, combo, "GO TO CAR", modos). Substituído por halos translúcidos. Os de geração de tiles/máscaras (rodam uma vez) foram mantidos.
- **Sem alocação por quadro**: `slice()`/`filter()` nos laços de balas, inimigos, itens, arremessos, textos flutuantes e ruídos trocados por cópias reutilizáveis e compactação no próprio array; `forEach` dos fantasmas virou `for`; `tx()` não chama mais `getTransform()` (criava uma matriz por texto) nem concatena a chave do cache.
- **Distâncias**: `Math.hypot` (lento no V8) → `hyp()`; separação entre inimigos e escuta de ruídos comparam distância ao quadrado, sem raiz.
- **Linha de visão da IA com vidro**: usa a mesma grade espacial de colisão (`hitWallNG`) em vez de varrer todos os sólidos, e não copia mais o array de sólidos a cada atualização.
- **Pausa**: a cena estática é redesenhada 5x/s em vez de 60x/s.
- **CSS**: scanlines sem `mix-blend-mode` (visual idêntico, sem recomposição extra) e a grade 3D do fundo para de animar durante a partida (antes repintava a tela inteira todo quadro).
- `sw.js`: cache `cappe-v18`.

## v19 — segunda rodada de otimização
Perfil de CPU na v18: a thread principal ficou ~93% ociosa (o JavaScript deixou de ser o gargalo); o que restava era composição/GPU.
- **Scanlines CRT**: durante a partida ficam dentro da vinheta (que já era desenhada todo quadro) em vez de uma camada DOM sobre o canvas, que custava cerca de 40% do FPS em máquinas sem GPU forte. Nos menus a camada CSS continua. A opção "Scanlines CRT" segue funcionando.
- **Faíscas** em lote: 1 preenchimento por cor e nível de transparência (6 níveis), em vez de 1 desenho por faísca.
- **Tradução** (`tr()`): resultado guardado por texto (antes ordenava as chaves do dicionário a cada chamada fora do português) e `tx()` sem array de argumentos por chamada.
- **Rótulo de clima** do canto: vira imagem guardada em vez de `fillText` + `toUpperCase` por quadro.
- `sw.js`: cache `cappe-v19`.

## v26 — IA e gráficos
- **Perseguição inteligente** (`js/exp-core.js`, `EXP.steer`): o inimigo só anda em linha reta quando o caminho está livre com o seu tamanho real (raio 13). Se houver parede no meio, segue o caminho calculado. Antes, em perseguição ele andava direto até o jogador e batia nas paredes e quinas.
- **Pinça**: inimigos que ainda estão longe pegam um dos dois lados do jogador, em vez de formar fila atrás.
- **Anti-travamento**: se um inimigo fica sem avançar por 0,7 s, replaneja o caminho e dá um passo lateral.
- **Grade de navegação** com folga igual ao raio do inimigo (14 px); o caminho começa no nó mais próximo, não no início.
- **Corredores** também usam o caminho; **chefe** para a investida ao bater numa parede.
- **Gráficos**: suavização ligada nos sprites rotacionados (jogador, inimigos, armas, portas, neon) e no zoom, o que remove o serrilhado. Desempenho igual ao da v25.
- `sw.js`: cache `cappe-v26`.

## v27 — bots, mira, idioma e título
- **Nome**: menu e aba agora são "Cappe-in-Miami".
- **Idioma padrão**: português do Brasil, independente do idioma do navegador. Quem escolher outro idioma em Opções mantém a escolha.
- **Mira dos bots** (`js/exp-brain.js`): antecipação do movimento do jogador limitada e proporcional à inteligência. Antes, o cálculo ia longe demais e as balas iam para o vazio. O erro de mira diminui conforme a dificuldade, e o leque de tiro da espingarda ficou mais estreito.
- **Reação**: o bot só atira depois de um tempo de reação após te ver (0,7 s no fácil, cerca de 0,4 s no difícil).
- **Esquiva**: bots mais espertos desviam de balas que vêm na direção deles.
- **Inteligência por dificuldade** (`DIF.iq`): fácil 0,15, médio 0,4, difícil 0,6, Hardcore 0,72, com teto de 0,75 para o nível mais alto.
- **Qualidade**: escala de renderização padrão mínima de 1,5x e suavização em alta qualidade. O modo "Desempenho máximo" (também ativado automaticamente em PCs fracos) volta para 1x.
- `sw.js`: cache `cappe-v27`.

## v28 — vendedor de armas
- **Créditos**: +10 por abate e bônus ao limpar a sala. Zerados quando uma partida Arcade começa ou quando uma campanha de História começa (não a cada capítulo).
- **Quando aparece**: no Arcade, nas fases 5, 10, 15...; na História, nos capítulos 3, 6, 9... Surge no meio da fase, depois que metade dos inimigos cai.
- **Como usar**: chegue perto e aperte E. Teclas 1-9 compram, ESC fecha.
- **Itens**: munição (recarga), colete extra, faca, pistola, revólver, escopeta, SMG, uzi, rifle.
- Ajustes: `EXP.shop` e `ITEMS` em `js/exp-shop.js`; a frequência fica em `eligibleLevel()`.
- `sw.js`: cache `cappe-v28`.

---

## 🆕 Novidades v29

* **Vendedor sem menu (`js/exp-shop.js`):** o vendedor cai perto do jogador com três cartas no chão — OFENSIVA (arma aleatória), DEFENSIVA (colete) e UTILIDADE (munição). Compra-se passando por cima. O mundo não para. Ele fica 4s e vai embora.
* **Trilha sonora escolhível (`js/exp-music.js`):** em Opções → TRILHA SONORA, escolha uma faixa fixa ou deixe em automática. Novos gêneros sintetizados: Dub Techno, Industrial Techno, Dark Disco e Cyberpunk Midtempo. Chefes mantêm a trilha própria. A escolha fica salva no navegador.

## 🆕 v30

* **Madame Piranha (vendedora):** personagem com falas de chegada, compra, falta de crédito e saída. Aparece no máximo uma vez por fase, não reaparece depois de sair e fica 4s.
* **Correções:** o vendedor não volta sem parar depois de sair; Tony (sem armas de fogo) não recebe mais armas na loja; a carta de munição vira faca quando você não tem arma de fogo.
* **Preços:** sobem 6% por fase.
* **História reescrita:** novos personagens, lugares e capítulos. Mapas e progressão iguais.

## 🆕 v31 (loja)

* **3 mercadorias + REROLAR:** a loja tem três itens (Ofensiva, Defensiva, Utilidade) e uma carta de reroll.
* **Reroll:** 1 grátis por partida. Depois custa 40 cr, subindo 10 cr a cada 30s da partida.
* **Raridade:** cada reroll na mesma visita aumenta a chance de itens raros e épicos. Novos itens: Caixa de munição (dobra a munição), Colete reforçado (+2 de escudo).

## 🆕 v32 (loja)

* **Descrição dos itens:** ao chegar perto de uma mercadoria, aparece o que ela faz.
* **Congelamento de impacto:** compra e reroll param o mundo por 50–70 ms, para o clique ter peso.


## v33 — melhorias incrementais (03/11/2026)
- Mantido todo o conteúdo, arquivos, mapas, modos, personagens, sistemas e recursos existentes.
- Adicionadas 8 trilhas instrumentais originais geradas em tempo real pela Web Audio API: Neon Boulevard, Blood Moon Drive, Outrun Memories, Concrete Dreams, After Hours, Toxic Skyline, VHS Sunset e Noir Pursuit.
- As novas faixas aparecem automaticamente no seletor **Opções → Trilha Sonora**. A opção Automática e a trilha especial dos chefes continuam funcionando.
- Refinado o menu principal: hierarquia visual, agrupamento dos botões, leitura dos controles e melhor aproveitamento do espaço.
- Melhorada a adaptação para telas menores e telas com pouca altura; os cartões de modos, opções e formulários também receberam ajustes.
- Ajustes de foco, estados desabilitados, feedback de clique e rolagem das telas para facilitar a navegação.
- Validada a sintaxe de todos os arquivos JavaScript com Node.js. A execução completa ainda deve ser conferida no navegador, pois depende de interação, áudio e APIs do navegador.
