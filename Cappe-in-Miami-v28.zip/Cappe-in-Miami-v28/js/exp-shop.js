/* Cappe-in-Miami | VENDEDOR DE ARMAS
   Créditos: +10 por abate e bônus ao limpar a sala.
   Quando aparece: Arcade a cada 5 fases; História nos capítulos 3, 6, 9...
   O vendedor surge no meio da fase, depois que metade dos inimigos cai.
   Chegue perto e aperte E para abrir a loja. Teclas 1-9 compram, ESC fecha.
   Os créditos são zerados quando uma partida começa (Arcade) ou uma campanha começa (História). */
(function () {
  'use strict';
  const EXP = window.EXP;
  const KILL_CRED = 10, CLEAR_BASE = 40, CLEAR_PER_LVL = 5, REACH = 50;

  const ITEMS = [
    { id: 'municao', nome: 'Munição (recarga)', preco: 25 },
    { id: 'colete', nome: 'Colete extra', preco: 60 },
    { id: 'faca', nome: 'Faca', preco: 30 },
    { id: 'pistola', nome: 'Pistola', preco: 45 },
    { id: 'revolver', nome: 'Revólver', preco: 80 },
    { id: 'escopeta', nome: 'Escopeta', preco: 110 },
    { id: 'smg', nome: 'SMG', preco: 120 },
    { id: 'uzi', nome: 'Uzi', preco: 130 },
    { id: 'rifle', nome: 'Rifle', preco: 150 },
  ];

  const SH = { cred: 0, dealer: null, eligible: false, lastKills: 0, lastCleared: false, msg: '', msgT: 0, sel: 0 };
  EXP.shop = SH;

  function eligibleLevel() { return historia ? capIdx % 3 === 2 : lvl > 0 && lvl % 5 === 0; }

  function say(txt) { SH.msg = txt; SH.msgT = 1.6; }

  function spawnDealer() {
    for (let i = 0; i < 400; i++) {
      const x = 40 + Math.random() * (WW - 80), y = 40 + Math.random() * (WH - 80);
      if (hitWall(x, y, 18) || hyp(x - P.x, y - P.y) < 180) continue;
      if (exitR && x > exitR[0] - 40 && x < exitR[0] + exitR[2] + 40 && y > exitR[1] - 40 && y < exitR[1] + exitR[3] + 40) continue;
      SH.dealer = { x, y };
      banner = { txt: 'VENDEDOR', sub: 'chegue perto e aperte ' + String(CFG.pick).toUpperCase(), t: 2.4 };
      return;
    }
  }

  function closeShop() { st = 'play'; }

  function buy(it) {
    if (SH.cred < it.preco) return say('Créditos insuficientes');
    const W_ = WP[cw];
    if (it.id === 'municao') {
      if (!W_ || !W_.gun) return say('Você não tem arma de fogo');
      ammo = W_.start(lvl) + (S.ammo || 0);
    } else if (it.id === 'colete') {
      P.shield = (P.shield || 0) + 1;
    } else {
      const N = WP[it.id];
      cw = it.id;
      ammo = N.gun ? N.start(lvl) + (S.ammo || 0) : 0;
    }
    SH.cred -= it.preco;
    say('Comprado: ' + it.nome);
  }

  // ----- ganchos no jogo -----
  const _startLevel = startLevel;
  startLevel = function () {
    _startLevel();
    SH.dealer = null; SH.eligible = eligibleLevel(); SH.lastKills = 0; SH.lastCleared = false;
  };

  const _newGame = newGame;
  newGame = function () {
    if (!historia || capIdx === 0) SH.cred = 0;
    return _newGame();
  };

  const _tick = EXP.tick;
  EXP.tick = function (dt) {
    _tick(dt);
    if (st !== 'play') return;
    if (levelStats.kills < SH.lastKills) SH.lastKills = levelStats.kills;
    if (levelStats.kills > SH.lastKills) { SH.cred += (levelStats.kills - SH.lastKills) * KILL_CRED; SH.lastKills = levelStats.kills; }
    if (cleared && !SH.lastCleared) SH.cred += CLEAR_BASE + CLEAR_PER_LVL * lvl;
    SH.lastCleared = cleared;
    if (SH.eligible && !SH.dealer && !cleared && levelStats.total > 0 && levelStats.kills * 2 >= levelStats.total) spawnDealer();
    if (SH.msgT > 0) SH.msgT -= dt;
  };

  // chamado pela tecla de interação (E): abre a loja se o jogador estiver perto do vendedor
  EXP.shopInteract = function () {
    if (st === 'shop') { closeShop(); return true; }
    if (st !== 'play' || !SH.dealer) return false;
    if (hyp(SH.dealer.x - P.x, SH.dealer.y - P.y) > REACH) return false;
    st = 'shop'; SH.sel = 0;
    return true;
  };

  addEventListener('keydown', function (e) {
    if (st !== 'shop') return;
    const k = e.key.toLowerCase();
    if (k === 'escape') { closeShop(); e.preventDefault(); return; }
    const n = parseInt(k, 10);
    if (n >= 1 && n <= ITEMS.length) { buy(ITEMS[n - 1]); e.preventDefault(); }
  });

  // ----- desenho (camada sobre o jogo, em coordenadas lógicas W x H) -----
  function drawDealer(g) {
    const z = CFG.zoom, dl = SH.dealer;
    const sx = (dl.x - cam.x - W / 2) * z + W / 2, sy = (dl.y - cam.y - H / 2) * z + H / 2;
    if (sx < -40 || sy < -40 || sx > W + 40 || sy > H + 40) return;
    g.save(); g.translate(sx, sy);
    g.fillStyle = 'rgba(0,0,0,.35)'; g.beginPath(); g.ellipse(2, 10, 12, 6, 0, 0, 6.2832); g.fill();
    g.fillStyle = '#19f0e6'; g.fillRect(-9, -8, 18, 20);
    g.fillStyle = '#f3c9a0'; g.beginPath(); g.arc(0, -14, 7, 0, 6.2832); g.fill();
    g.fillStyle = '#2d0f5c'; g.fillRect(-10, -21, 20, 5);
    g.fillStyle = '#222'; g.fillRect(8, -2, 14, 5);
    g.restore();
    const near = hyp(dl.x - P.x, dl.y - P.y) <= REACH;
    g.save(); g.textAlign = 'center'; g.font = 'bold 13px Impact, sans-serif';
    g.fillStyle = near ? '#ffd23f' : '#fff';
    g.fillText(near ? 'E: LOJA' : 'VENDEDOR', sx, sy - 32); g.restore();
  }

  function drawShop(g) {
    g.fillStyle = 'rgba(8,2,20,.82)'; g.fillRect(0, 0, W, H);
    const x = 250, y = 70, w = 460, h = 460;
    g.fillStyle = 'rgba(45,15,92,.95)'; g.fillRect(x, y, w, h);
    g.strokeStyle = '#19f0e6'; g.lineWidth = 3; g.strokeRect(x + 1.5, y + 1.5, w - 3, h - 3);
    g.textAlign = 'center'; g.font = 'bold 26px Impact, sans-serif'; g.fillStyle = '#ff2e93';
    g.fillText('VENDEDOR DE ARMAS', W / 2, y + 42);
    g.font = 'bold 18px Impact, sans-serif'; g.fillStyle = '#ffd23f';
    g.fillText('Créditos: ' + SH.cred, W / 2, y + 74);
    g.textAlign = 'left'; g.font = 'bold 18px Impact, sans-serif';
    ITEMS.forEach(function (it, i) {
      const iy = y + 112 + i * 34, can = SH.cred >= it.preco;
      g.fillStyle = can ? '#fff' : '#777';
      g.fillText((i + 1) + '  ' + it.nome, x + 30, iy);
      g.textAlign = 'right'; g.fillStyle = can ? '#19f0e6' : '#777';
      g.fillText(it.preco + ' cr', x + w - 30, iy); g.textAlign = 'left';
    });
    g.textAlign = 'center'; g.font = '14px Impact, sans-serif'; g.fillStyle = '#e8d9ff';
    g.fillText(SH.msgT > 0 && SH.msg ? SH.msg : '1-9 comprar  ·  ESC sair', W / 2, y + h - 22);
  }

  EXP.overlay = function (g) {
    if (SH.dealer && (st === 'play' || st === 'paused' || st === 'shop')) drawDealer(g);
    if (st === 'play' || st === 'shop') {
      g.save(); g.textAlign = 'left'; g.font = 'bold 18px Impact, sans-serif'; g.fillStyle = '#ffd23f';
      g.fillText('CRÉDITOS ' + SH.cred, 34, 156); g.restore();
    }
    if (st === 'shop') drawShop(g);
  };
})();
