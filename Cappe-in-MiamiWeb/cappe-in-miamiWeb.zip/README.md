# Cappe in Miami — Web v95
1. Instale Node.js 18 ou superior.
2. Execute INICIAR_WEB.bat com duplo clique.
3. Mantenha a janela do servidor aberta enquanto joga.
Versão HTML, CSS e JavaScript. Código, testes e histórico completo: https://github.com/CappeVictor/Cappe-in-Miami
