# Cappe in Miami Web v98

Execute INICIAR_WEB.bat. Requer Node.js 18 ou superior. A campanha carrega as fases em tiles antes dos modos.