# Cappe in Miami Web v96

1. Instale Node.js 18 ou superior.
2. Execute INICIAR_WEB.bat.
3. Mantenha a janela do servidor aberta enquanto joga.