# Cappe in Miami Web v97

Execute INICIAR_WEB.bat. Requer Node.js 18 ou superior. Este pacote contém os arquivos necessários para jogar a edição Web.