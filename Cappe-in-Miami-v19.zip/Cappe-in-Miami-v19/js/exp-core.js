/* Cappe in Miami - Expansão | NÚCLEO
   Salvamento versionado (com backup e migração), XP/níveis, pontos de habilidade,
   conquistas, ranking local e avisos (toasts). Não depende de nenhum outro exp-*.js. */
(function () {
  'use strict';
  const EXP = window.EXP;
  const KEY = 'hm_save_v2', BAK = 'hm_save_v2_bak';
  const MAXLV = 40;

  const defSave = () => ({
    v: 2, created: Date.now(), saved: 0,
    xp: 0, level: 1, sp: 0, perks: {},
    stats: { kills: 0, deaths: 0, rooms: 0, shots: 0, hits: 0, melee: 0, throwHits: 0, finishers: 0, playSec: 0, maxCombo: 0,
             bestScore: 0, runs: 0, sRanks: 0, ssRanks: 0, bossKills: 0, barrels: 0, cameras: 0, flawless: 0 },
    records: {},          // por modo: { best, wave, time, rooms }
    ranking: {},          // por modo: top 10
    ach: {}, unl: [], bosses: {}, weaponsUsed: {}, masksUsed: {}, flags: {}, daily: {},
    settings: { musVol: .8, sfxVol: .8 }
  });

  // mescla recursiva: campos novos de versões futuras nunca quebram um save antigo
  function merge(base, src) {
    if (!src || typeof src !== 'object') return base;
    for (const k of Object.keys(src)) {
      if (base[k] && typeof base[k] === 'object' && !Array.isArray(base[k])) base[k] = merge(base[k], src[k]);
      else base[k] = src[k];
    }
    return base;
  }
  function readKey(k) { try { const r = localStorage.getItem(k); return r ? JSON.parse(r) : null; } catch (e) { return null; } }
  function valid(o) { return o && typeof o === 'object' && o.v >= 1 && typeof o.level === 'number' && o.stats; }

  function migrate(sv) {   // traz dados das versões anteriores (v4) sem apagá-los
    try {
      const hi = +localStorage.getItem('hm_hiscore') || 0;
      if (hi > (sv.records.classico && sv.records.classico.best || 0)) sv.records.classico = Object.assign({}, sv.records.classico, { best: hi });
      if (localStorage.getItem('hm_unlock') === '1') sv.flags.hardcoreWon = true;
      sv.stats.bestScore = Math.max(sv.stats.bestScore, hi);
    } catch (e) {}
    return sv;
  }

  let SAVE = null, dirty = false, saveT = 0, lastBak = 0;
  function load() {
    let d = readKey(KEY);
    if (!valid(d)) { const b = readKey(BAK); if (valid(b)) { d = b; EXP.log && EXP.log('save principal inválido: restaurado do backup'); } else d = null; }
    SAVE = d ? merge(defSave(), d) : migrate(defSave());
    return SAVE;
  }
  function flush(force) {
    if (!SAVE || (!dirty && !force)) return;
    try {
      const prev = localStorage.getItem(KEY);
      if (prev && Date.now() - lastBak > 20000) { localStorage.setItem(BAK, prev); lastBak = Date.now(); }   // backup rotativo
      SAVE.saved = Date.now(); localStorage.setItem(KEY, JSON.stringify(SAVE)); dirty = false;
    } catch (e) { EXP.log && EXP.log('falha ao salvar: ' + e.message); }
  }
  function touch() { dirty = true; clearTimeout(saveT); saveT = setTimeout(() => flush(), 1500); }   // salvamento automático (agrupado)
  function exportSave() {
    flush(true);
    const blob = new Blob([JSON.stringify(SAVE, null, 1)], { type: 'application/json' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'cappe-in-miami-save.json';
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }
  function importSave(text) {
    let o; try { o = JSON.parse(text); } catch (e) { return 'Arquivo inválido (não é JSON).'; }
    if (!valid(o)) return 'Este arquivo não é um save do Cappe in Miami.';
    try { localStorage.setItem(BAK, JSON.stringify(SAVE)); } catch (e) {}
    SAVE = merge(defSave(), o); flush(true); EXP.recheck(); return '';
  }
  function resetSave() { try { localStorage.setItem(BAK, JSON.stringify(SAVE)); } catch (e) {} SAVE = defSave(); flush(true); }

  // ---------- XP / níveis / perks ----------
  const xpNeed = l => Math.round(90 * Math.pow(l, 1.45));
  const PERKS = [
    { id: 'agil',    nome: 'Pés Leves',   max: 5, desc: '+3% de velocidade por nível.' },
    { id: 'furtivo', nome: 'Sombra',      max: 5, desc: 'Inimigos te veem 20 px mais tarde e ouvem 4% menos por nível.' },
    { id: 'municao', nome: 'Bolsos Fundos', max: 5, desc: '+3 de munição inicial por nível.' },
    { id: 'folego',  nome: 'Embalo',      max: 5, desc: '+0,2 s na janela de combo por nível.' },
    { id: 'pele',    nome: 'Pele Grossa', max: 3, desc: 'Nível 1: +1 colete por sala. Nível 3: +2.' },
    { id: 'pontaria', nome: 'Mira Firme', max: 5, desc: 'Reduz a dispersão dos tiros em 6% por nível.' },
  ];
  function perk(id) { return (SAVE.perks[id] || 0); }
  function buyPerk(id) {
    const p = PERKS.find(x => x.id === id); if (!p) return false;
    if (SAVE.sp < 1 || perk(id) >= p.max) return false;
    SAVE.sp--; SAVE.perks[id] = perk(id) + 1; touch(); return true;
  }
  function addXP(n, why) {
    n = Math.round(n * ((typeof S !== 'undefined' && S.xp) || 1) * (EXP.xpMul || 1)); if (n <= 0) return 0;
    SAVE.xp += n;
    while (SAVE.level < MAXLV && SAVE.xp >= xpNeed(SAVE.level)) {
      SAVE.xp -= xpNeed(SAVE.level); SAVE.level++;
      SAVE.sp += 1 + (SAVE.level % 5 === 0 ? 1 : 0);
      toast('NÍVEL ' + SAVE.level, '+' + (1 + (SAVE.level % 5 === 0 ? 1 : 0)) + ' ponto(s) de habilidade', '#ffd23f');
      EXP.checkUnlocks();
    }
    if (SAVE.level >= MAXLV) SAVE.xp = Math.min(SAVE.xp, xpNeed(MAXLV));
    touch(); if (EXP.run) EXP.run.xp = (EXP.run.xp || 0) + n; return n;
  }

  // ---------- toasts (lista fixa, sem criar objetos por quadro) ----------
  const toasts = [];
  function toast(t, sub, c) { toasts.push({ t, sub: sub || '', c: c || '#19f0e6', life: 3.2 }); if (toasts.length > 5) toasts.shift(); }

  // ---------- conquistas ----------
  const ACH = [
    { id: 'primeiro',  nome: 'Primeiro Sangue',     desc: 'Derrote um inimigo.',                       test: s => s.stats.kills >= 1 },
    { id: 'k100',      nome: 'Faxineiro',           desc: 'Derrote 100 inimigos.',                     test: s => s.stats.kills >= 100 },
    { id: 'k500',      nome: 'Ceifador',            desc: 'Derrote 500 inimigos.',                     test: s => s.stats.kills >= 500 },
    { id: 'k2000',     nome: 'Lenda de Miami',      desc: 'Derrote 2000 inimigos.',                    test: s => s.stats.kills >= 2000 },
    { id: 'rank_s',    nome: 'Estilo',              desc: 'Consiga nota S em uma sala.',               test: s => s.stats.sRanks >= 1 },
    { id: 'rank_ss',   nome: 'Perfeição',           desc: 'Consiga nota SS em uma sala.',              test: s => s.stats.ssRanks >= 1 },
    { id: 'combo10',   nome: 'Frenesi',             desc: 'Chegue a um combo de 10x.',                 test: s => s.stats.maxCombo >= 10 },
    { id: 'combo20',   nome: 'Sem Freio',           desc: 'Chegue a um combo de 20x.',                 test: s => s.stats.maxCombo >= 20 },
    { id: 'horda10',   nome: 'Maré Alta',           desc: 'Chegue à onda 10 no Modo Horda.',           test: s => (s.records.horda && s.records.horda.wave || 0) >= 10 },
    { id: 'horda20',   nome: 'Inabalável',          desc: 'Chegue à onda 20 no Modo Horda.',           test: s => (s.records.horda && s.records.horda.wave || 0) >= 20 },
    { id: 'chefe1',    nome: 'Caça-Chefes',         desc: 'Derrote um chefe.',                         test: s => s.stats.bossKills >= 1 },
    { id: 'chefe6',    nome: 'Rei da Pista',        desc: 'Derrote todos os chefes disponíveis.',      test: s => Object.keys(s.bosses).length >= (EXP.bosses ? EXP.bosses.length : 99) },
    { id: 'surv',      nome: 'Sobrevivente',        desc: 'Complete o Modo Sobrevivência.',            test: s => !!s.flags.survWon },
    { id: 'arcade',    nome: 'Moedas Infinitas',    desc: 'Zere o Modo Arcade.',                       test: s => !!s.flags.arcadeWon },
    { id: 'fantasma',  nome: 'Fantasma',            desc: 'Vença o Modo Assassino sem ser detectado.', test: s => !!s.flags.ghostWon },
    { id: 'diario',    nome: 'Rotina',              desc: 'Complete um Desafio Diário.',               test: s => Object.keys(s.daily).length >= 1 },
    { id: 'barris',    nome: 'Pirotécnico',         desc: 'Exploda 10 barris.',                        test: s => s.stats.barrels >= 10 },
    { id: 'cameras',   nome: 'Ponto Cego',          desc: 'Destrua 5 câmeras de segurança.',           test: s => s.stats.cameras >= 5 },
    { id: 'variedade', nome: 'Arsenal',             desc: 'Use 5 armas diferentes na mesma sala.',     test: s => !!s.flags.variety5 },
    { id: 'impecavel', nome: 'Impecável',           desc: 'Complete 5 salas sem ser detectado.',       test: s => s.stats.flawless >= 5 },
    { id: 'hist',      nome: 'Fim da Linha',        desc: 'Termine o Modo História.',                  test: s => !!s.flags.storyWon },
    { id: 'pontos50k', nome: 'Placar Estourado',    desc: 'Faça 50.000 pontos em uma partida.',        test: s => s.stats.bestScore >= 50000 },
    { id: 'nivel10',   nome: 'Veterano',            desc: 'Chegue ao nível 10.',                       test: s => s.level >= 10 },
    { id: 'nivel25',   nome: 'Elite',               desc: 'Chegue ao nível 25.',                       test: s => s.level >= 25 },
  ];
  function checkAch() {
    for (const a of ACH) if (!SAVE.ach[a.id] && a.test(SAVE)) { SAVE.ach[a.id] = Date.now(); toast('CONQUISTA', a.nome, '#ff2e93'); touch(); EXP.checkUnlocks(); }
  }

  // ---------- ranking local ----------
  function addRank(mode, entry) {
    const L = SAVE.ranking[mode] || (SAVE.ranking[mode] = []);
    entry.date = new Date().toISOString().slice(0, 10); L.push(entry); L.sort((a, b) => b.score - a.score); if (L.length > 10) L.length = 10;
    const pos = L.indexOf(entry); touch(); return pos;   // -1 se ficou fora do top 10
  }
  function setRecord(mode, key, val, lowerBetter) {
    const R = SAVE.records[mode] || (SAVE.records[mode] = {}), old = R[key];
    if (old === undefined || (lowerBetter ? val < old : val > old)) { R[key] = val; touch(); return true; } return false;
  }

  load();
  Object.assign(EXP, {
    MAXLV, PERKS, ACH, xpNeed, perk, buyPerk, addXP, toast, toasts, checkAch, addRank, setRecord,
    save: () => SAVE, flush, touch, exportSave, importSave, resetSave, reload: load,
  });
  addEventListener('pagehide', () => flush(true));
  document.addEventListener('visibilitychange', () => { if (document.hidden) flush(true); });
  setInterval(() => flush(), 8000);
})();

/* ==== BLOCO: IA ESTENDIDA (exp-core.js) ===========================================
   Estados mentais explícitos, expostos em enemy.mind:
     'patrol'      segue os waypoints definidos em maps.js (enemy.route, em pixels)
     'chase'       linha de visão limpa (raycast, que atravessa vidro) rastreia o jogador
     'investigate' tiro do jogador em qualquer lugar: inimigos a até 450 px (através de paredes)
                   caminham até a origem do ruído usando busca de caminho (BFS em grade)
   Os estados internos do jogo (IDLE, SUSPICIOUS, INVESTIGATE, SEARCH, ALERT, CHASE, STUNNED)
   continuam existindo; 'PATROL' é o estado interno novo. EXP.mind() traduz tudo em 4 nomes.
   =================================================================================== */
(function () {
  'use strict';
  const EXP = window.EXP;
  EXP.glass = { list: [], map: new Map() };       // tiles de vidro vivos (preenchido por exp-world.js, quebrado em exp-fx.js)
  const NAV = { cs: 20, cols: 0, rows: 0, ok: null, par: null, seen: null, q: null, stamp: 0, built: false, solids: [] };
  EXP.NAV = NAV;
  const DI = [1, -1, 0, 0, 1, 1, -1, -1], DJ = [0, 0, 1, -1, 1, -1, 1, -1];

  function circleHits(list, x, y, r) {
    for (let i = 0; i < list.length; i++) {
      const w = list[i], cx = Math.max(w[0], Math.min(x, w[0] + w[2])), cy = Math.max(w[1], Math.min(y, w[1] + w[3]));
      if ((x - cx) * (x - cx) + (y - cy) * (y - cy) < r * r) return true;
    }
    return false;
  }
  // grade de navegação: células de 20 px, caminháveis quando livres de parede/móvel/vidro (portas contam como passagem)
  EXP.navBuild = function () {
    const cs = NAV.cs, cols = Math.ceil(WW / cs), rows = Math.ceil(WH / cs), n = cols * rows;
    if (!NAV.ok || NAV.ok.length !== n) { NAV.ok = new Uint8Array(n); NAV.par = new Int32Array(n); NAV.seen = new Int32Array(n); NAV.q = new Int32Array(n); NAV.stamp = 0; }
    NAV.cols = cols; NAV.rows = rows;
    const boxes = new Set(doors.map(d => d.box)); NAV.solids = sol.filter(s => !boxes.has(s));
    for (let j = 0; j < rows; j++) for (let i = 0; i < cols; i++) NAV.ok[j * cols + i] = circleHits(NAV.solids, i * cs + cs / 2, j * cs + cs / 2, 9.5) ? 0 : 1;
    NAV.built = true;
  };
  function cellOf(x, y) { return Math.max(0, Math.min(NAV.rows - 1, (y / NAV.cs) | 0)) * NAV.cols + Math.max(0, Math.min(NAV.cols - 1, (x / NAV.cs) | 0)); }
  function nearestOk(idx) {
    if (NAV.ok[idx]) return idx;
    const cols = NAV.cols, ci = idx % cols, cj = (idx / cols) | 0;
    for (let d = 1; d <= 5; d++) for (let dj = -d; dj <= d; dj++) for (let di = -d; di <= d; di++) {
      if (Math.max(Math.abs(di), Math.abs(dj)) !== d) continue;
      const i = ci + di, j = cj + dj; if (i < 0 || j < 0 || i >= cols || j >= NAV.rows) continue;
      if (NAV.ok[j * cols + i]) return j * cols + i;
    }
    return -1;
  }
  EXP.navPath = function (sx, sy, gx, gy) {
    if (!NAV.built) return null;
    const s = nearestOk(cellOf(sx, sy)), g = nearestOk(cellOf(gx, gy)); if (s < 0 || g < 0) return null;
    const stamp = ++NAV.stamp, cols = NAV.cols, rows = NAV.rows, seen = NAV.seen, par = NAV.par, q = NAV.q, ok = NAV.ok;
    let h = 0, t = 0, found = s === g; q[t++] = s; seen[s] = stamp; par[s] = -1;
    while (h < t && !found) {
      const c = q[h++], ci = c % cols, cj = (c / cols) | 0;
      for (let k = 0; k < 8; k++) {
        const di = DI[k], dj = DJ[k], i = ci + di, j = cj + dj;
        if (i < 0 || j < 0 || i >= cols || j >= rows) continue;
        const n = j * cols + i; if (seen[n] === stamp || !ok[n]) continue;
        if (di && dj && (!ok[cj * cols + i] || !ok[j * cols + ci])) continue;      // sem cortar quinas
        seen[n] = stamp; par[n] = c; q[t++] = n; if (n === g) { found = true; break; }
      }
    }
    if (!found) return null;
    const path = []; for (let c = g; c !== -1; c = par[c]) path.push({ x: (c % cols) * NAV.cs + NAV.cs / 2, y: ((c / cols) | 0) * NAV.cs + NAV.cs / 2 });
    path.reverse(); return path;
  };
  function clearRay(x1, y1, x2, y2) {            // raio livre de sólidos (portas contam como livres: os inimigos as abrem)
    const d = hyp(x2 - x1, y2 - y1), n = Math.max(1, Math.ceil(d / 10));
    for (let i = 1; i < n; i++) if (circleHits(NAV.solids, x1 + (x2 - x1) * i / n, y1 + (y2 - y1) * i / n, 9)) return false;
    return true;
  }
  // devolve o ponto intermediário a perseguir (puxa o caminho até o nó mais distante visível)
  function navTarget(e, gx, gy, dt) {
    e.pathT = (e.pathT || 0) - dt; const gk = ((gx / 16) | 0) * 4096 + ((gy / 16) | 0);
    if (!e.path || e.pathT <= 0 || e.pathK !== gk) { e.path = EXP.navPath(e.x, e.y, gx, gy); e.pi = 0; e.pathT = .9 + Math.random() * .4; e.pathK = gk; e.pk = 0; e.smT = 0; }
    const p = e.path; if (!p || !p.length) return null;
    while (e.pi < p.length - 1 && hyp(p[e.pi].x - e.x, p[e.pi].y - e.y) < 26) e.pi++;
    e.smT -= dt; if (e.smT <= 0 || e.pk < e.pi) {
      e.smT = .15; let k = e.pi; for (let j = Math.min(p.length - 1, e.pi + 7); j > e.pi; j--) if (clearRay(e.x, e.y, p[j].x, p[j].y)) { k = j; break; } e.pk = k;
    }
    const out = e.navTmp || (e.navTmp = { x: 0, y: 0 });
    if (e.pk >= p.length - 1) { out.x = gx; out.y = gy; } else { out.x = p[e.pk].x; out.y = p[e.pk].y; }
    return out;
  }
  EXP.navTarget = navTarget;

  EXP.mind = function (e) {
    if (e.ko > 0 || e.stun > 0) return 'down';
    const s = e.state;
    if (s === 'PATROL') return 'patrol';
    if (s === 'CHASE' || s === 'ALERT') return 'chase';
    if (s === 'INVESTIGATE' || s === 'SEARCH' || s === 'SUSPICIOUS') return 'investigate';
    return 'idle';
  };

  // abre a porta que está na frente do inimigo (o jogo só deixava o jogador abrir portas)
  function enemyOpenDoor(e) {
    for (let i = 0; i < doors.length; i++) {
      const d = doors[i]; if (d.open || d.swing) continue;
      const cx = d.x + d.w / 2, cy = d.y + d.h / 2; if (Math.abs(cx - e.x) > 32 || Math.abs(cy - e.y) > 32) continue;
      let ax = cx - e.x, ay = cy - e.y; const L = hyp(ax, ay) || 1; ax /= L; ay /= L;
      d.swing = true; d.fast = false; d.target = d.vert ? -(ax >= 0 ? 1 : -1) * Math.PI / 2 : (ay >= 0 ? 1 : -1) * Math.PI / 2; return;
    }
  }
  function patrol(e, dt) {
    const w = e.route[e.wp || 0];
    if (e.wait > 0) { e.wait -= dt; return; }
    const t = navTarget(e, w.x, w.y, dt) || w;
    e.a = Math.atan2(t.y - e.y, t.x - e.x); move(e, Math.cos(e.a) * 52 * dt, Math.sin(e.a) * 52 * dt);
    if (hyp(w.x - e.x, w.y - e.y) < 20) { e.wp = ((e.wp || 0) + 1) % e.route.length; e.wait = .6; e.path = null; }
  }
  // chamado uma vez por quadro (por EXP.worldTick), antes do laço de IA do jogo
  EXP.aiExtTick = function (dt) {
    if (!NAV.built) return;
    for (let i = 0; i < enemies.length; i++) {
      const e = enemies[i];
      if (e.ko > 0 || e.stun > 0) { e.mind = 'down'; continue; }
      const s = e.state;
      if (doors.length && !historia && s !== 'IDLE' && s !== 'SUSPICIOUS') enemyOpenDoor(e);
      if (e.route && e.route.length && (s === 'IDLE' || s === 'PATROL')) { if (s === 'IDLE') e.state = 'PATROL'; e.goal = null; patrol(e, dt); }
      else if (s === 'PATROL') e.state = 'IDLE';
      if (s === 'INVESTIGATE' || s === 'SEARCH') {
        if (e.lkp && e.lkp !== e.navPt) e.goal = { x: e.lkp.x, y: e.lkp.y };          // alvo novo (ruído, última posição vista)
        e.invT = (e.invT || 0) + dt;
        if (e.invT > 14) { e.goal = null; e.lkp = null; e.heard = null; e.invT = 0; e.state = 'IDLE'; continue; }
        if (e.goal) {
          const n = navTarget(e, e.goal.x, e.goal.y, dt);
          if (n) { const np = e.navPt || (e.navPt = { x: 0, y: 0 }); np.x = n.x; np.y = n.y; e.lkp = np; }
        }
      } else if (s !== 'SUSPICIOUS') { e.goal = null; e.invT = 0; }
      e.mind = EXP.mind(e);
    }
  };
  // tiro do jogador: 450 px de raio, sem depender de paredes (máscaras silenciosas reduzem o raio)
  EXP.gunshotAlert = function (x, y) {
    const R = 450 * ((typeof S !== 'undefined' && S.quiet) || 1);
    for (let i = 0; i < enemies.length; i++) {
      const e = enemies[i];
      if (e.ko > 0 || e.stun > 0 || e.state === 'CHASE' || e.state === 'ALERT') continue;
      if (hyp(e.x - x, e.y - y) > R) continue;
      e.heard = { x, y }; e.lkp = { x, y }; e.goal = { x, y }; e.invT = 0; e.path = null;
      setEnemyState(e, 'INVESTIGATE', 4);
    }
  };
  const _emit = emitNoise;
  emitNoise = function (x, y, r, kind) { if (kind === 'gunshot') EXP.gunshotAlert(x, y); _emit(x, y, r, kind); };
})();
