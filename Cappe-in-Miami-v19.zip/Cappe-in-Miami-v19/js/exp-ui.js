/* Cappe in Miami - Expansão | INTERFACE
   Seleção de modos, modo personalizado, perfil/coleção/conquistas/recordes, resumo por sala,
   tela de resultado, volume e gerenciamento de dados de salvamento. */
(function () {
  'use strict';
  const EXP = window.EXP, MODES = EXP.MODES, stage = document.querySelector('.stage');
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const mk = (id, html) => { const s = document.createElement('section'); s.id = id; s.className = 'overlay exp oculto'; s.innerHTML = html; stage.insertBefore(s, document.querySelector('.scan')); return s; };
  const screens = [];
  const open = el => { hideAll(); menu.classList.add('oculto'); el.classList.remove('oculto'); st = 'expui'; };
  const back = () => { hideAll(); toMenu(); };
  function hideAll() { screens.forEach(s => s.classList.add('oculto')); }

  // ---------- menu principal ----------
  const lvlTag = $('lvlTag');   // menu agora montado em index.html
  function refreshTag() { const s = EXP.save(); lvlTag.textContent = 'Nível ' + s.level + ' · ' + s.sp + ' ponto(s) de habilidade · ' + Object.keys(s.ach).length + '/' + EXP.ACH.length + ' conquistas'; }
  refreshTag();
  $('jogar').onclick = () => { EXP.pending = null; showMasks(); };
  const _toMenu = toMenu; toMenu = function () { _toMenu(); refreshTag(); };

  // ---------- MODOS ----------
  const sModos = mk('expModos', '<h2>Modos de Jogo</h2><div class="modos" id="modoCards"></div><div class="detalhe" id="modoDet"></div><div class="linha"><button id="modoGo" type="button">Jogar</button><button id="modoBack" type="button" class="sec">Voltar</button></div>');
  screens.push(sModos);
  let curMode = 'horda', curMap = 'rand';
  const list = Object.values(MODES).filter(m => !m.hidden);
  const cards = $('modoCards');
  list.forEach(m => { const b = document.createElement('button'); b.type = 'button'; b.className = 'card'; b.dataset.id = m.id; b.style.setProperty('--c', m.color); b.innerHTML = '<b>' + m.nome + '</b>' + esc(m.desc); b.onclick = () => selMode(m.id); cards.appendChild(b); });
  function selMode(id) {
    curMode = id; const m = MODES[id], rec = EXP.save().records[id] || {};
    [...cards.children].forEach(c => c.classList.toggle('on', c.dataset.id === id));
    let recTxt = rec.best ? 'Recorde: ' + rec.best + ' pts' + (rec.wave ? ' · onda ' + rec.wave : '') + (rec.time ? ' · ' + rec.time + ' s' : '') + (rec.rooms ? ' · ' + rec.rooms + ' salas' : '') : 'Sem recorde ainda';
    let extra = '';
    if (m.map) extra = '<label>Arena: <select id="arenaSel"><option value="rand">Aleatória</option>' + EXP.ARENAS.map(a => '<option value="' + a + '"' + (a === curMap ? ' selected' : '') + '>' + (MAPAS.find(x => x.id === a) || { nome: a }).nome + '</option>').join('') + '</select></label>';
    if (id === 'diario') { const d = EXP.dailyInfo(), done = EXP.save().daily[d.date]; extra = '<p>Hoje (' + d.date + '): máscara <b>' + MASKS[d.mask].nome + '</b>, arma inicial <b>' + WP[d.weapon].nome + '</b>, modificador <b>' + EXP.MODS[d.mod].nome + '</b>.' + (done ? ' <span class="rec">Melhor de hoje: ' + done.score + '</span>' : '') + '</p>'; }
    $('modoDet').innerHTML = '<b style="color:' + m.color + '">' + m.nome.toUpperCase() + '</b> — ' + esc(m.desc) + '<ul>' + m.rules.map(r => '<li>' + esc(r) + '</li>').join('') + '</ul><div>Recompensa: ' + esc(m.reward) + '</div><div class="rec">' + recTxt + '</div>' + extra;
    const a = $('arenaSel'); if (a) a.onchange = () => { curMap = a.value; };
  }
  $('modosBtn').onclick = () => { open(sModos); selMode(curMode); };
  $('modoBack').onclick = back;
  $('modoGo').onclick = () => { if (curMode === 'custom') { openCustom(); return; } EXP.startMode(curMode, { map: curMap }); };

  // ---------- PERSONALIZADO ----------
  const sCust = mk('expCust', '<h2>Partida Personalizada</h2><div class="form" id="custForm"></div><p class="aviso">Partidas personalizadas dão 50% do XP e não contam para os recordes oficiais.</p><div class="linha"><button id="custGo" type="button">Começar</button><button id="custBack" type="button" class="sec">Voltar</button></div>');
  screens.push(sCust);
  function openCustom() {
    const maps = [['seq', 'Sequência'], ['proc', 'Apartamento aleatório'], ...MAPAS.filter(m => m.id !== 'boate-b').map(m => [m.id, m.nome])];
    const unlockedMasks = MASKS.map((m, i) => [i, m.nome]).filter(([i]) => !EXP.maskLocked(i));
    const guns = [['pistola', 'Pistola'], ...Object.keys(WP).filter(k => k !== 'punho' && k !== 'pistola' && EXP.weaponUnlocked(k)).map(k => [k, WP[k].nome])];
    const sel = (id, opts, d) => '<select id="' + id + '">' + opts.map(([v, t]) => '<option value="' + v + '"' + (v == d ? ' selected' : '') + '>' + t + '</option>').join('') + '</select>';
    $('custForm').innerHTML = '<label>Mapa ' + sel('c-map', maps, 'seq') + '</label><label>Máscara ' + sel('c-mask', unlockedMasks, 0) + '</label><label>Arma inicial ' + sel('c-wp', guns, 'pistola') + '</label>' +
      '<label>Dificuldade ' + sel('c-dif', [['facil', 'Fácil'], ['medio', 'Médio'], ['dificil', 'Difícil'], ['hardcore', 'Hardcore']], 'medio') + '</label><label>Quantidade de inimigos ' + sel('c-en', [[.5, 'Metade'], [1, 'Normal'], [1.5, '+50%'], [2, 'Dobro']], 1) + '</label>' +
      '<label>Velocidade dos inimigos ' + sel('c-foe', [[.8, 'Lenta'], [1, 'Normal'], [1.25, 'Rápida'], [1.5, 'Muito rápida']], 1) + '</label><label>Vida (coletes extra) ' + sel('c-life', [[0, '0'], [1, '+1'], [2, '+2'], [3, '+3']], 0) + '</label><label>Número de salas ' + sel('c-rooms', [[3, '3'], [5, '5'], [8, '8'], [12, '12']], 5) + '</label>' +
      '<div class="mods">' + Object.entries(EXP.MODS).map(([k, m]) => '<label title="' + esc(m.desc) + '"><input type="checkbox" data-mod="' + k + '"> ' + m.nome + '</label>').join('') + '</div>';
    open(sCust);
  }
  $('custBack').onclick = () => open(sModos);
  $('custGo').onclick = () => {
    const v = id => $(id).value, mods = [...document.querySelectorAll('#custForm [data-mod]')].filter(c => c.checked).map(c => c.dataset.mod);
    EXP.startMode('custom', { map: v('c-map'), mask: +v('c-mask'), weapon: v('c-wp'), dif: v('c-dif'), enemies: +v('c-en'), foe: +v('c-foe'), life: +v('c-life'), rooms: +v('c-rooms'), mods });
  };

  // ---------- PERFIL & COLEÇÃO ----------
  const sPerfil = mk('expPerfil', '<h2>Perfil &amp; Coleção</h2><div class="tabs" id="tabs"></div><div class="painel" id="painel"></div><div class="linha"><button id="perfBack" type="button" class="sec">Voltar</button></div>');
  screens.push(sPerfil);
  const TABS = [['perfil', 'Progresso'], ['mascaras', 'Máscaras'], ['armas', 'Armas'], ['chefes', 'Chefes'], ['conq', 'Conquistas'], ['rank', 'Recordes'], ['dados', 'Dados']];
  let tab = 'perfil';
  const tabs = $('tabs'); TABS.forEach(([id, t]) => { const b = document.createElement('button'); b.type = 'button'; b.dataset.id = id; b.textContent = t; b.onclick = () => showTab(id); tabs.appendChild(b); });
  const fmtT = s => Math.floor(s / 3600) + 'h ' + Math.floor(s % 3600 / 60) + 'min';
  function showTab(id) {
    tab = id; [...tabs.children].forEach(b => b.classList.toggle('on', b.dataset.id === id));
    const sv = EXP.save(), p = $('painel'); let h = '';
    if (id === 'perfil') {
      const need = EXP.xpNeed(sv.level), s = sv.stats, acc = s.shots ? Math.round(s.hits / s.shots * 100) + '%' : '—';
      h = '<b>Nível ' + sv.level + '</b> — XP ' + sv.xp + ' / ' + need + (sv.level >= EXP.MAXLV ? ' (máx.)' : '') + '<div class="xpbar"><i style="width:' + Math.min(100, sv.xp / need * 100) + '%"></i></div>' +
        '<p><b style="color:var(--amarelo)">Pontos de habilidade: ' + sv.sp + '</b></p>' + EXP.PERKS.map(p => { const l = EXP.perk(p.id); return '<div class="perk"><span style="min-width:8em"><b>' + p.nome + '</b></span><span class="pips">' + '■'.repeat(l) + '□'.repeat(p.max - l) + '</span><button type="button" data-perk="' + p.id + '"' + (sv.sp < 1 || l >= p.max ? ' disabled' : '') + '>+</button><span>' + p.desc + '</span></div>'; }).join('') +
        '<h4 style="color:var(--ciano);margin:.6rem 0 .2rem">ESTATÍSTICAS</h4><div class="stats">' + [['Abates', s.kills], ['Mortes', s.deaths], ['Salas', s.rooms], ['Partidas', s.runs], ['Precisão geral', acc], ['Maior combo', s.maxCombo + 'x'], ['Melhor pontuação', s.bestScore], ['Notas S / SS', s.sRanks + ' / ' + s.ssRanks], ['Chefes', s.bossKills], ['Finalizações', s.finishers], ['Barris explodidos', s.barrels], ['Câmeras destruídas', s.cameras], ['Salas sem detecção', s.flawless], ['Tempo de jogo', fmtT(s.playSec)], ['Corpo a corpo', s.melee]].map(([a, b]) => '<span>' + a + ': <b>' + b + '</b></span>').join('') + '</div>';
    } else if (id === 'mascaras') {
      const got = MASKS.filter((m, i) => !EXP.maskLocked(i)).length;
      h = '<p>' + got + ' / ' + MASKS.length + ' máscaras desbloqueadas</p><div class="col">' + MASKS.map((m, i) => { const lk = EXP.maskLocked(i), r = EXP.RAR[m.rar]; return '<div class="item' + (lk ? ' lk' : '') + '" style="border-color:' + r.c + '"><img src="' + (m.img.src || 'assets/' + m.id + '.png') + '" alt=""><b>' + (lk ? '???' : m.nome) + '</b><small style="color:' + r.c + '">' + r.nome + '</small><small>' + (lk ? esc(EXP.unlockInfo(m.unl).txt) : esc(m.desc)) + '</small><small style="opacity:.7">' + (lk ? '' : EXP.maskTags(m).join(' · ')) + '</small></div>'; }).join('') + '</div>';
    } else if (id === 'armas') {
      h = '<div class="col">' + Object.keys(WP).filter(k => k !== 'punho').map(k => { const w = WP[k], lk = !EXP.weaponUnlocked(k), r = EXP.RAR[w.rar], used = sv.weaponsUsed[k] || 0;
        return '<div class="item' + (lk ? ' lk' : '') + '" style="border-color:' + r.c + '"><b>' + (lk ? '???' : w.nome) + '</b><small>' + w.cat + ' · <span style="color:' + r.c + '">' + r.nome + '</span></small><small>' + (lk ? 'Nível ' + w.lv : (w.melee ? 'Corpo a corpo · alcance ' + w.range : 'Cadência ' + (1 / w.cd).toFixed(1) + '/s · ' + (EXP.magOf(k) ? 'pente ' + EXP.magOf(k)[0] : 'sem pente') + (w.pel > 1 ? ' · ' + w.pel + ' projéteis' : ''))) + '</small><small style="opacity:.7">Usada ' + used + 'x</small></div>'; }).join('') + '</div>';
    } else if (id === 'chefes') {
      h = EXP.bosses.map(b => { const n = sv.bosses[b.id] || 0; return '<div class="item" style="border-color:' + b.col + ';margin-bottom:.4rem"><b style="color:' + b.col + '">' + b.nome + (n ? ' ✔ ×' + n : '') + '</b><small>Aparece na onda ' + b.wave + ' do Modo Horda · ' + b.phases.length + ' fases</small><small>' + (n ? esc(b.bio) : 'Derrote para revelar a história.') + '</small></div>'; }).join('') + '<p class="aviso">Chefes extras chegam em futuras atualizações (veja o CHANGELOG).</p>';
    } else if (id === 'conq') {
      h = EXP.ACH.map(a => { const ok = sv.ach[a.id]; return '<div class="ach' + (ok ? ' ok' : '') + '"><span><b>' + a.nome + '</b> — ' + a.desc + '</span><span>' + (ok ? '✔' : '—') + '</span></div>'; }).join('');
    } else if (id === 'rank') {
      const ids = Object.keys(MODES).filter(k => k !== 'historia');
      h = ids.map(k => { const L = sv.ranking[k] || []; return '<h4 style="color:var(--ciano);margin:.3rem 0">' + MODES[k].nome.toUpperCase() + '</h4>' + (L.length ? '<table class="rank-t"><tr><th>#</th><th>Pontos</th><th>Máscara</th><th>Resultado</th><th>Data</th></tr>' + L.slice(0, 5).map((e, i) => '<tr><td>' + (i + 1) + '</td><td>' + e.score + '</td><td>' + esc(e.mask) + '</td><td>' + esc(e.info) + (e.win ? ' ✔' : '') + '</td><td>' + e.date + '</td></tr>').join('') + '</table>' : '<p style="opacity:.6;margin:.1rem 0">sem registros</p>'); }).join('');
    } else if (id === 'dados') {
      h = '<p>O progresso é salvo automaticamente neste navegador, com cópia de segurança. Exporte um arquivo para guardar ou mover o seu save.</p><div class="linha"><button type="button" id="dExp">Exportar save</button><label class="sec" style="cursor:pointer;padding:.45rem 1rem;background:var(--amarelo);color:var(--noite);font:700 .95rem Orbitron">Importar save<input type="file" id="dImp" accept=".json,application/json" hidden></label><button type="button" id="dRes" class="sec">Restaurar backup</button></div><p id="dMsg" class="aviso"></p><p style="opacity:.6;font-size:.8rem">Última gravação: ' + (sv.saved ? new Date(sv.saved).toLocaleString() : '—') + '</p>';
    }
    p.innerHTML = h;
    p.querySelectorAll('[data-perk]').forEach(b => b.onclick = () => { if (EXP.buyPerk(b.dataset.perk)) { showTab('perfil'); refreshTag(); } });
    if (id === 'dados') {
      $('dExp').onclick = () => EXP.exportSave();
      $('dImp').onchange = e => { const f = e.target.files[0]; if (!f) return; const rd = new FileReader(); rd.onload = () => { const m = EXP.importSave(String(rd.result)); $('dMsg').textContent = m || 'Save importado com sucesso!'; refreshTag(); }; rd.readAsText(f); };
      $('dRes').onclick = () => { try { const b = JSON.parse(localStorage.getItem('hm_save_v2_bak')); if (b) { localStorage.setItem('hm_save_v2', JSON.stringify(b)); EXP.reload(); EXP.recheck(); $('dMsg').textContent = 'Backup restaurado.'; refreshTag(); } else $('dMsg').textContent = 'Nenhum backup disponível.'; } catch (e) { $('dMsg').textContent = 'Backup inválido.'; } };
    }
  }
  $('perfilBtn').onclick = () => { open(sPerfil); showTab(tab); };
  $('perfBack').onclick = back;

  // ---------- RESUMO POR SALA ----------
  const sSum = mk('expSum', '<p class="tag" id="sumT"></p><div class="nota" id="sumN"></div><div class="duas"><div><h4>DESEMPENHO</h4><div id="sumS"></div></div><div><h4>BÔNUS</h4><div id="sumB"></div></div></div><p id="sumX" class="novo"></p><button id="sumGo" type="button">Continuar</button><p class="dica">Enter continua</p>');
  screens.push(sSum); let sumCb = null;
  EXP.ui = {
    hideAll,
    summary(r, cb) {
      sumCb = cb; $('sumT').textContent = r.title; $('sumN').textContent = r.rank; $('sumN').className = 'nota ' + r.rank;
      $('sumS').innerHTML = r.stats.map(([a, b]) => '<p>' + a + '<b>' + b + '</b></p>').join('') + '<p>Pontos<b>' + r.score + '</b></p>';
      $('sumB').innerHTML = r.bonus.length ? r.bonus.map(([a, b]) => '<p>' + a + '<b>' + b + '</b></p>').join('') : '<p style="opacity:.6">sem bônus</p>';
      const un = EXP.takeNewUnlocks(); $('sumX').textContent = '+' + r.xp + ' XP · Nível ' + EXP.save().level + un.map(u => ' · NOVO: ' + u.label).join('');
      sSum.classList.remove('oculto'); $('sumGo').focus();
    },
    result(r) {
      EXP.takeNewUnlocks; const e = $('expRes'); $('resT').textContent = r.title; $('resT').style.color = r.win ? 'var(--ciano)' : 'var(--rosa)'; $('resSub').textContent = r.sub;
      $('resN').textContent = r.rank; $('resN').className = 'nota ' + r.rank; $('resR').textContent = r.rankText === '—' ? '' : 'Notas das salas: ' + r.rankText;
      $('resL').innerHTML = r.lines.map(([a, b]) => '<p>' + a + '<b>' + b + '</b></p>').join('');
      $('resX').innerHTML = '<p>XP ganho<b>+' + (r.xp || 0) + '</b></p><p>Nível<b>' + r.level + '</b></p>' + (r.record ? '<p class="novo">NOVO RECORDE!</p>' : '') + (r.pos >= 0 ? '<p class="novo">Ranking local: #' + (r.pos + 1) + '</p>' : '') + (r.unl || []).map(u => '<p class="novo">DESBLOQUEADO: ' + esc(u.label) + '</p>').join('');
      $('expRes').classList.remove('oculto'); $('resAgain').focus(); if (r.record) playSfx('record');
    },
  };
  $('sumGo').onclick = () => { sSum.classList.add('oculto'); const cb = sumCb; sumCb = null; if (cb) cb(); };
  const sRes = mk('expRes', '<h2 id="resT"></h2><p class="tag" id="resSub"></p><div class="nota" id="resN"></div><p id="resR" class="dica"></p><div class="duas"><div><h4>RESUMO</h4><div id="resL"></div></div><div><h4>PROGRESSO</h4><div id="resX"></div></div></div><div class="linha"><button id="resAgain" type="button">Jogar de novo</button><button id="resMask" type="button" class="sec">Trocar máscara</button><button id="resMenu" type="button" class="sec">Menu</button></div>');
  screens.push(sRes);
  $('resAgain').onclick = () => { sRes.classList.add('oculto'); newGame(); };
  $('resMask').onclick = () => { sRes.classList.add('oculto'); showMasks(); };
  $('resMenu').onclick = () => { sRes.classList.add('oculto'); toMenu(); };
  addEventListener('keydown', e => { if (e.key === 'Enter' && st === 'summary') { $('sumGo').click(); e.preventDefault(); } if (e.key === 'Escape' && st === 'expui') { back(); } });

  // ---------- OPÇÕES: áudio e dados ----------
  // ÁUDIO & DADOS: campos já estão em index.html (#opcoes)
  const syncVol = () => { const s = EXP.save().settings; $('o-musVol').value = s.musVol; $('o-sfxVol').value = s.sfxVol; $('o-events').checked = s.events !== false; };
  $('o-musVol').oninput = e => EXP.setVol('musVol', +e.target.value); $('o-sfxVol').oninput = e => { EXP.setVol('sfxVol', +e.target.value); EXP.sfx('pistol'); };
  $('o-events').onchange = e => { EXP.save().settings.events = e.target.checked; EXP.touch(); };
  const _ob = $('optBtn').onclick; $('optBtn').onclick = () => { _ob(); syncVol(); };

  // ---------- PERSONAGENS (na tela de máscaras) ----------
  const charRow = document.createElement('div'); charRow.id = 'charRow'; charRow.className = 'menu-row';
  charRow.innerHTML = '<div class="tabs" id="charTabs"></div><p class="dica" id="charInfo" style="width:100%;margin:.1rem 0"></p>';
  grade.before(charRow);
  const ctabs = $('charTabs');
  EXP.CHARS.forEach(c => { const b = document.createElement('button'); b.type = 'button'; b.dataset.id = c.id; b.textContent = c.nome + ' (' + MASKS.find(m => m.id === c.mask).nome + ')'; b.onclick = () => { EXP.setChar(c.id); mark(); refreshChar(); }; ctabs.appendChild(b); });
  function refreshChar() { const cur = EXP.curChar(); [...ctabs.children].forEach(b => b.classList.toggle('on', b.dataset.id === cur.id)); $('charInfo').innerHTML = '<b style="color:var(--amarelo)">' + cur.nome + '</b> — ' + esc(cur.desc) + ' <span style="opacity:.7">[+ ' + esc(cur.pros) + ' · − ' + esc(cur.cons) + ']</span>'; }
  const _showMasks = showMasks; showMasks = function () { _showMasks(); refreshChar(); };
  refreshChar();

  // ---------- grade de máscaras ----------
  EXP.cols = 10; EXP.rebuildMaskGrid(); EXP.recheck();
})();
/* ============ NITIDEZ, TAMANHO DA TELA E MENU DE PAUSA COM BOTÕES (anexar ao final de js/exp-ui.js) ============
   ARQUIVO: js/exp-ui.js (anexar ao final). Não altera index.html.
   1) Canvas com resolução real (proporcional à tela × DPI): texto e sprites ficam nítidos.
   2) Opção "Tamanho da tela" no bloco VÍDEO de Opções (salva em EXP.save().settings.stage).
   3) Pausa com botões clicáveis para História e Modos: Continuar, Recomeçar e Menu principal. */
(function () {
  'use strict';
  const EXP = window.EXP;
  const cv = document.getElementById('c');
  const stage = document.querySelector('.stage');
  const $ = id => document.getElementById(id);

  // ---------- 1) nitidez: resolução interna acompanha o tamanho exibido ----------
  let hiK = 1;
  function applyResolution() {
    const r = cv.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    const k = Math.min(2, Math.max(1, (r.width * dpr) / W));
    const nw = Math.round(W * k), nh = Math.round(H * k);
    if (cv.width !== nw || cv.height !== nh) { cv.width = nw; cv.height = nh; }
    cv.style.imageRendering = 'auto';
    hiK = k;
  }
  const _draw = draw;
  draw = function () { ctx.setTransform(hiK, 0, 0, hiK, 0, 0); _draw(); };

  // ---------- 2) tamanho da tela ----------
  const SIZES = {
    p: { w: 640, nome: 'Pequena (640 px)' },
    m: { w: 800, nome: 'Média (800 px)' },
    g: { w: 1024, nome: 'Grande (1024 px)' },
    x: { w: 1280, nome: 'Máxima (1280 px)' },
    f: { w: null, nome: 'Tela cheia (ajusta à janela)' },
  };
  function applyStage() {
    const key = (EXP.save().settings.stage) || 'x';
    const sz = SIZES[key] || SIZES.x;
    const cap = sz.w ? sz.w + 'px' : null;
    stage.style.width = cap ? 'min(100vw, calc(100vh * 1.6), ' + cap + ')' : 'min(100vw, calc(100vh * 1.6))';
    applyResolution();
  }
  // Tamanho da tela: <select id="o-stage"> já existe em index.html (VÍDEO)
  (function bindSizeOption() {
    const sel = $('o-stage');
    sel.value = EXP.save().settings.stage || 'x';
    sel.onchange = e => { EXP.save().settings.stage = e.target.value; EXP.touch(); applyStage(); };
  })();
  window.addEventListener('resize', applyStage);
  applyStage();

  // ---------- 3) menu de pausa com botões ----------
  const BTN = [
    { id: 'cont', label: 'ESC · CONTINUAR', dy: 26, col: '#ffffff' },
    { id: 'rest', label: 'R · RECOMEÇAR FASE', dy: 82, col: '#19f0e6' },
    { id: 'menu', label: 'M · MENU PRINCIPAL', dy: 138, col: '#ffd23f' },
  ];
  const BOX = { w: 420, h: 46 };
  function boxOf(b) { return { x: W / 2 - BOX.w / 2, y: H / 2 + b.dy - BOX.h / 2 + 4, w: BOX.w, h: BOX.h }; }

  function goMenu() {
    musStop(.3); toMenu();
    if (EXP.ui && EXP.ui.hideAll) EXP.ui.hideAll();
  }
  function act(id) {
    if (id === 'cont') togglePause();
    else if (id === 'rest') newGame();
    else if (id === 'menu') goMenu();
  }

  cv.addEventListener('click', e => {
    if (st !== 'paused') return;
    const r = cv.getBoundingClientRect();
    const x = (e.clientX - r.left) * W / r.width, y = (e.clientY - r.top) * H / r.height;
    for (const b of BTN) {
      const bx = boxOf(b);
      if (x >= bx.x && x <= bx.x + bx.w && y >= bx.y && y <= bx.y + bx.h) { act(b.id); return; }
    }
  });
  addEventListener('keydown', e => {
    if (st === 'paused' && e.key.toLowerCase() === 'm') { goMenu(); e.preventDefault(); }
  });

  const _drawHUD = EXP.drawHUD;
  EXP.drawHUD = function (g) {
    _drawHUD(g);
    if (st !== 'paused') return;
    // escurece de novo para apagar o texto de pausa original, depois desenha os botões
    g.save();
    g.fillStyle = 'rgba(5,0,18,.78)'; g.fillRect(0, 0, W, H);
    g.textAlign = 'center';
    g.fillStyle = '#ff2e93'; g.font = '64px Impact, sans-serif'; g.fillText('PAUSADO', W / 2, H / 2 - 40);
    const hover = (typeof mouse !== 'undefined' && mouse.x !== undefined) ? mouse : null;
    for (const b of BTN) {
      const bx = boxOf(b);
      const over = hover && hover.x >= bx.x && hover.x <= bx.x + bx.w && hover.y >= bx.y && hover.y <= bx.y + bx.h;
      g.fillStyle = over ? 'rgba(255,46,147,.35)' : 'rgba(20,0,40,.85)';
      g.fillRect(bx.x, bx.y, bx.w, bx.h);
      g.strokeStyle = b.col; g.lineWidth = over ? 3 : 2; g.strokeRect(bx.x, bx.y, bx.w, bx.h);
      g.fillStyle = b.col; g.font = 'bold 22px Impact, sans-serif'; g.textBaseline = 'middle';
      g.fillText(b.label, W / 2, bx.y + bx.h / 2 + 1);
    }
    g.restore();
  };
})();
/* ============ VOLTAR AO MENU EM TODAS AS TELAS + MODO ROLETA DE MÁSCARAS (anexar ao final de js/exp-ui.js) ============
   ARQUIVO: js/exp-ui.js (anexar ao final). Não altera index.html.
   1) Botão "‹ Menu principal" em toda tela de menu que não tinha volta, e tecla Esc para voltar.
   2) Modo "Roleta de Máscaras": a máscara é sorteada a cada sala nova e a cada nova tentativa. */
(function () {
  'use strict';
  const EXP = window.EXP;
  const $ = id => document.getElementById(id);

  // ---------- 1) voltar ao menu ----------
  const MENU_SCREENS = ['opcoes', 'dif', 'historia', 'mascaras', 'expModos', 'expCust', 'expPerfil', 'fim'];

  function backToMenu() {
    document.querySelectorAll('section.overlay').forEach(s => { if (s.id !== 'menu') s.classList.add('oculto'); });
    toMenu();
    if (EXP.ui && EXP.ui.hideAll) EXP.ui.hideAll();
    const menu = $('menu');
    if (menu) menu.classList.remove('oculto');
    if (typeof musStop === 'function') musStop(.3);
  }
  EXP.backToMenu = backToMenu;

  function injectBackButtons() {
    document.querySelectorAll('section.overlay').forEach(s => {
      if (s.id === 'menu' || s.querySelector('.btn-volta-menu')) return;
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'btn-volta-menu';
      b.textContent = '‹ Menu principal';
      b.style.cssText = 'position:absolute;top:10px;left:10px;z-index:50;padding:.35rem .8rem;font:700 .8rem Orbitron,sans-serif;letter-spacing:.06em;background:rgba(10,0,25,.85);color:#19f0e6;border:2px solid #19f0e6;cursor:pointer;';
      b.onclick = backToMenu;
      s.insertBefore(b, s.firstChild);
    });
  }
  injectBackButtons();

  addEventListener('keydown', e => {
    if (e.key !== 'Escape') return;
    const open = MENU_SCREENS.find(id => $(id) && !$(id).classList.contains('oculto'));
    if (open) { backToMenu(); e.preventDefault(); }
  });

  // ---------- 2) modo Roleta de Máscaras ----------
  EXP.MODES.roleta = {
    id: 'roleta', nome: 'Roleta de Máscaras', color: '#ff6bd5',
    desc: 'Você não escolhe a máscara: o jogo sorteia uma nova a cada sala e a cada tentativa.',
    rules: ['A máscara muda a cada sala nova e a cada nova tentativa.', 'Adapte sua estratégia na hora: velocidade, força ou furtividade.', 'Sem limite de salas: quanto mais, melhor.'],
    reward: 'XP por sala · recorde de salas.',
  };

  function rerollMask() {
    sel = Math.floor(Math.random() * MASKS.length);
    S = Object.assign({}, BASE, MASKS[sel].fx);
    EXP.applyS();
    popup(P.x, P.y - 50, 'MÁSCARA: ' + MASKS[sel].nome.toUpperCase(), '#ff6bd5');
    EXP.sfx && EXP.sfx('wave');
  }

  const _startLevel = startLevel;
  startLevel = function () {
    _startLevel();
    if (EXP.run && EXP.run.id === 'roleta') rerollMask();
  };
})();
/* ============ EXPERIÊNCIA DO JOGADOR: CONFIRMAÇÃO AO SAIR, DICA DE CONTROLES (anexar ao final de js/exp-ui.js) ============
   ARQUIVO: js/exp-ui.js (anexar ao final). Não altera index.html.
   1) Ao sair da partida para o menu (no meio de uma fase), pede confirmação para não perder o progresso.
   2) Dica "ESC · MENU  ·  R · RECOMEÇAR" no canto superior esquerdo durante a partida. */
(function () {
  'use strict';
  const EXP = window.EXP;

  // ---------- 1) confirmação antes de abandonar uma partida em andamento ----------
  const _toMenu = toMenu;
  toMenu = function () {
    const emPartida = st === 'play' || st === 'paused';
    if (emPartida && !window.confirm('Sair da partida para o menu?\nO progresso desta fase será perdido.')) return;
    _toMenu();
  };

  // ---------- 2) dica de controles na partida ----------
  const _drawHUD = EXP.drawHUD;
  EXP.drawHUD = function (g) {
    _drawHUD(g);
    if (st !== 'play') return;
    g.save();
    g.font = 'bold 14px Impact, sans-serif';
    g.textAlign = 'left';
    g.fillStyle = 'rgba(25,240,230,.85)';
    g.fillText('ESC · MENU   R · RECOMEÇAR', 34, 136);
    g.restore();
  };
})();
/* ============ IDIOMAS: PORTUGUÊS, ENGLISH, ESPAÑOL (anexar ao final de js/exp-ui.js) ============
   ARQUIVO: js/exp-ui.js (anexar ao final). Não altera index.html.
   - Seletor de idioma em Opções (bloco IDIOMA), salvo em EXP.save().settings.lang.
   - Textos do HTML (menus, opções, botões, dificuldade, pausa) são traduzidos no DOM,
     inclusive os que surgem depois (MutationObserver).
   - Textos do canvas (HUD, pausa, mensagens da partida) são traduzidos na função tx.
   - As chaves são os textos originais em português; o português é o idioma padrão. */
(function () {
  'use strict';
  const EXP = window.EXP;
  const $ = id => document.getElementById(id);

  const NAMES = { pt: 'Português', en: 'English', es: 'Español' };

  // dicionário exato: chave = texto original em português
  const DICT = {
    en: {
      'Jogar': 'Play', 'Modo História': 'Story Mode', 'Opções': 'Options', 'ou aperte Enter': 'or press Enter',
      'Seja bem-vindo!': 'Welcome!', 'Feito por Victor Cappellesso e Davi Gehart': 'Made by Victor Cappellesso and Davi Gehart',
      'Um tiro mata você. Um tiro mata eles. Limpe a sala e ache a saída.': 'One shot kills you. One shot kills them. Clear the room and find the exit.',
      'W A S D ou setas: mover': 'W A S D or arrows: move', 'Espaço : soco / finalizar nocauteado': 'Space: punch / finish knocked-out enemy',
      'Predefinição gráfica': 'Graphics preset', 'Ultra': 'Ultra', 'Alto': 'High', 'Médio': 'Medium', 'Baixo': 'Low',
      'Desempenho máximo': 'Max performance', 'Personalizado': 'Custom', 'Qualidade do sangue': 'Blood quality',
      'Ultra (permanente, denso)': 'Ultra (permanent, dense)', 'Alta (permanente)': 'High (permanent)',
      'Média (some em 3 s)': 'Medium (fades in 3 s)', 'Baixa': 'Low', 'Desativado': 'Off', 'Vermelho do sangue': 'Blood red',
      'Brilho': 'Brightness', 'Limite de FPS': 'FPS limit', 'Desbloqueado': 'Unlocked',
      'Sensibilidade da câmera': 'Camera sensitivity', 'Zoom da câmera': 'Camera zoom', 'Padrão (1x)': 'Default (1x)',
      'Afastado (0.75x)': 'Far (0.75x)', 'Próximo (1.25x)': 'Close (1.25x)', 'Janela de combo': 'Combo window',
      'Zona morta da câmera': 'Camera dead zone', 'Amortecimento do tremor': 'Shake damping', 'Rápido': 'Fast', 'Suave': 'Smooth',
      'Teclas de movimento': 'Movement keys', 'WASD + setas': 'WASD + arrows', 'Somente setas': 'Arrows only',
      'Pegar/arremessar arma': 'Pick up/throw weapon', 'Salvo automaticamente no navegador': 'Saved automatically in the browser',
      'Voltar': 'Back', 'VÍDEO': 'VIDEO', 'JOGABILIDADE': 'GAMEPLAY', 'IDIOMA': 'LANGUAGE', 'Idioma': 'Language',
      'Tamanho da tela': 'Screen size', 'Pequena (640 px)': 'Small (640 px)', 'Média (800 px)': 'Medium (800 px)',
      'Grande (1024 px)': 'Large (1024 px)', 'Máxima (1280 px)': 'Max (1280 px)', 'Tela cheia (ajusta à janela)': 'Full screen (fits window)',
      'Dificuldade da História': 'Story Difficulty', 'Fácil': 'Easy', 'Difícil': 'Hard', '‹ Menu principal': '‹ Main menu',
      'Você morreu': 'You died', 'PAUSADO': 'PAUSED', 'ESC · CONTINUAR': 'ESC · RESUME', 'R · RECOMEÇAR FASE': 'R · RESTART LEVEL',
      'M · MENU PRINCIPAL': 'M · MAIN MENU', 'ESC · MENU   R · RECOMEÇAR': 'ESC · MENU   R · RESTART',
      'NOCAUTE · ESPAÇO': 'KNOCKED OUT · SPACE', 'ATORDOADO': 'STUNNED', 'PULO [SHIFT]': 'JUMP [SHIFT]',
      'E pegar/trocar  ·  Q largar  ·  BOTÃO DIR. arremessar  ·  ESPAÇO soco/finalizar  ·  ESC pausar':
        'E pick up/swap  ·  Q drop  ·  RIGHT CLICK throw  ·  SPACE punch/finish  ·  ESC pause',
      'Feito por Victor Cappellesso e Davi Gehart ': 'Made by Victor Cappellesso and Davi Gehart ',
      'Clássico': 'Classic', 'História': 'Story', 'Campanha: 3 Fases': 'Campaign: 3 Levels', 'Horda': 'Horde',
      'Sobrevivência': 'Survival', 'Arcade': 'Arcade', 'Contrarrelógio': 'Time Attack', 'Assassino': 'Assassin',
      'Limpeza': 'Cleanup', 'Invasão': 'Invasion', 'Desafio Diário': 'Daily Challenge', 'Roleta de Máscaras': 'Mask Roulette',
      'O relógio nunca para. Cada abate rende segundos.': 'The clock never stops. Each kill adds seconds.',
      'Você não escolhe a máscara: o jogo sorteia uma nova a cada sala e a cada nova tentativa.': 'You do not choose the mask: the game draws a new one every room and every new attempt.',
    },
    es: {
      'Jogar': 'Jugar', 'Modo História': 'Modo Historia', 'Opções': 'Opciones', 'ou aperte Enter': 'o pulsa Enter',
      'Seja bem-vindo!': '¡Bienvenido!', 'Feito por Victor Cappellesso e Davi Gehart': 'Hecho por Victor Cappellesso y Davi Gehart',
      'Um tiro mata você. Um tiro mata eles. Limpe a sala e ache a saída.': 'Un disparo te mata. Un disparo los mata. Limpia la sala y encuentra la salida.',
      'W A S D ou setas: mover': 'W A S D o flechas: mover', 'Espaço : soco / finalizar nocauteado': 'Espacio: golpe / rematar noqueado',
      'Predefinição gráfica': 'Preajuste gráfico', 'Ultra': 'Ultra', 'Alto': 'Alto', 'Médio': 'Medio', 'Baixo': 'Bajo',
      'Desempenho máximo': 'Máximo rendimiento', 'Personalizado': 'Personalizado', 'Qualidade do sangue': 'Calidad de la sangre',
      'Ultra (permanente, denso)': 'Ultra (permanente, densa)', 'Alta (permanente)': 'Alta (permanente)',
      'Média (some em 3 s)': 'Media (desaparece en 3 s)', 'Baixa': 'Baja', 'Desativado': 'Desactivado', 'Vermelho do sangue': 'Rojo de la sangre',
      'Brilho': 'Brillo', 'Limite de FPS': 'Límite de FPS', 'Desbloqueado': 'Desbloqueado',
      'Sensibilidade da câmera': 'Sensibilidad de la cámara', 'Zoom da câmera': 'Zoom de la cámara', 'Padrão (1x)': 'Normal (1x)',
      'Afastado (0.75x)': 'Alejado (0.75x)', 'Próximo (1.25x)': 'Cercano (1.25x)', 'Janela de combo': 'Ventana de combo',
      'Zona morta da câmera': 'Zona muerta de la cámara', 'Amortecimento do tremor': 'Amortiguación del temblor', 'Rápido': 'Rápido', 'Suave': 'Suave',
      'Teclas de movimento': 'Teclas de movimiento', 'WASD + setas': 'WASD + flechas', 'Somente setas': 'Solo flechas',
      'Pegar/arremessar arma': 'Recoger/lanzar arma', 'Salvo automaticamente no navegador': 'Guardado automáticamente en el navegador',
      'Voltar': 'Volver', 'VÍDEO': 'VIDEO', 'JOGABILIDADE': 'JUEGO', 'IDIOMA': 'IDIOMA', 'Idioma': 'Idioma',
      'Tamanho da tela': 'Tamaño de pantalla', 'Pequena (640 px)': 'Pequeña (640 px)', 'Média (800 px)': 'Mediana (800 px)',
      'Grande (1024 px)': 'Grande (1024 px)', 'Máxima (1280 px)': 'Máxima (1280 px)', 'Tela cheia (ajusta à janela)': 'Pantalla completa (se ajusta)',
      'Dificuldade da História': 'Dificultad de la historia', 'Fácil': 'Fácil', 'Difícil': 'Difícil', '‹ Menu principal': '‹ Menú principal',
      'Você morreu': 'Has muerto', 'PAUSADO': 'PAUSA', 'ESC · CONTINUAR': 'ESC · CONTINUAR', 'R · RECOMEÇAR FASE': 'R · REINICIAR FASE',
      'M · MENU PRINCIPAL': 'M · MENÚ PRINCIPAL', 'ESC · MENU   R · RECOMEÇAR': 'ESC · MENÚ   R · REINICIAR',
      'NOCAUTE · ESPAÇO': 'NOQUEADO · ESPACIO', 'ATORDOADO': 'ATURDIDO', 'PULO [SHIFT]': 'SALTO [SHIFT]',
      'E pegar/trocar  ·  Q largar  ·  BOTÃO DIR. arremessar  ·  ESPAÇO soco/finalizar  ·  ESC pausar':
        'E recoger/cambiar  ·  Q soltar  ·  CLIC DER. lanzar  ·  ESPACIO golpe/rematar  ·  ESC pausa',
      'Feito por Victor Cappellesso e Davi Gehart ': 'Hecho por Victor Cappellesso y Davi Gehart ',
      'Clássico': 'Clásico', 'História': 'Historia', 'Campanha: 3 Fases': 'Campaña: 3 Fases', 'Horda': 'Horda',
      'Sobrevivência': 'Supervivencia', 'Arcade': 'Arcade', 'Contrarrelógio': 'Contrarreloj', 'Assassino': 'Asesino',
      'Limpeza': 'Limpieza', 'Invasão': 'Invasión', 'Desafio Diário': 'Desafío diario', 'Roleta de Máscaras': 'Ruleta de Máscaras',
      'O relógio nunca para. Cada abate rende segundos.': 'El reloj nunca se detiene. Cada baja da segundos.',
      'Você não escolhe a máscara: o jogo sorteia uma nova a cada sala e a cada nova tentativa.': 'No eliges la máscara: el juego sortea una nueva en cada sala y en cada intento.',
    },
  };

  // prefixos (textos dinâmicos do canvas e do HUD): chave = início em português
  const PREFIX = {
    en: { 'PONTOS ': 'SCORE ', 'SALA LIMPA!  RANK ': 'ROOM CLEARED!  RANK ', 'SALA ': 'ROOM ', 'ARMA ': 'WEAPON ',
          'ABATES ': 'KILLS ', 'RECORDE ': 'RECORD ', 'AMEAÇA x': 'THREAT x', 'TEMPO ': 'TIME ', 'ONDA ': 'WAVE ',
          'ONDA ': 'WAVE ', 'FICHA -1': 'LIFE -1', 'COLETE ': 'ARMOR ', 'MILAGRE ': 'MIRACLE ' },
    es: { 'PONTOS ': 'PUNTOS ', 'SALA LIMPA!  RANK ': '¡SALA LIMPIA!  RANGO ', 'SALA ': 'SALA ', 'ARMA ': 'ARMA ',
          'ABATES ': 'BAJAS ', 'RECORDE ': 'RÉCORD ', 'AMEAÇA x': 'AMENAZA x', 'TEMPO ': 'TIEMPO ', 'ONDA ': 'OLEADA ',
          'FICHA -1': 'FICHA -1', 'COLETE ': 'CHALECO ', 'MILAGRE ': 'MILAGRO ' },
  };

  let LANG = 'pt';

  // traduz um texto preservando espaços em volta da chave
  const TRC = new Map(); let trLang = '';
  function tr(s) {   // [otimização] resultado guardado por texto: o canvas chama isto dezenas de vezes por quadro
    if (LANG === 'pt' || typeof s !== 'string') return s;
    if (trLang !== LANG) { TRC.clear(); trLang = LANG; }
    let r = TRC.get(s); if (r !== undefined) return r;
    r = trSlow(s); if (TRC.size > 3000) TRC.clear(); TRC.set(s, r); return r;
  }
  function trSlow(s) {
    if (!s.trim()) return s;
    const t = s.trim(), d = DICT[LANG];
    if (d[t] !== undefined) return s.replace(t, () => d[t]);
    const pre = PREFIX[LANG] || {};
    const keys = Object.keys(pre).sort((a, b) => b.length - a.length);
    for (const k of keys) if (s.startsWith(k)) return pre[k] + s.slice(k.length);
    return s;
  }

  // ---------- textos do canvas ----------
  const _tx = tx;
  tx = function (s, x, y, c, font, al) { return _tx(tr(s), x, y, c, font, al); };

  // ---------- textos do DOM (inclusive os criados depois) ----------
  const seen = new WeakMap();   // nó de texto -> { orig, shown }
  function translateNode(n) {
    let i = seen.get(n);
    if (!i) { i = { orig: n.nodeValue, shown: null }; seen.set(n, i); }
    else if (i.shown !== null && n.nodeValue !== i.shown) i.orig = n.nodeValue;   // o app reescreveu o texto
    const out = tr(i.orig);
    if (n.nodeValue !== out) n.nodeValue = out;
    i.shown = out;
  }
  function walk(root) {
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    for (let n = w.nextNode(); n; n = w.nextNode()) {
      const p = n.parentNode;
      if (!p || /^(SCRIPT|STYLE|TEXTAREA)$/.test(p.nodeName)) continue;
      translateNode(n);
    }
  }
  const obs = new MutationObserver(muts => {
    for (const m of muts) {
      if (m.type === 'characterData') { if (m.target.nodeType === 3) translateNode(m.target); continue; }
      for (const node of m.addedNodes) {
        if (node.nodeType === 3) translateNode(node);
        else if (node.nodeType === 1) walk(node);
      }
    }
  });

  // ---------- seletor de idioma em Opções ----------
  (function addLangOption() {
    const sel = $('o-lang');
    if (!sel) return;
    for (const k of Object.keys(NAMES)) {
      const op = document.createElement('option'); op.value = k; op.textContent = NAMES[k]; sel.appendChild(op);
    }
    sel.onchange = e => setLang(e.target.value);
  })();

  function setLang(l) {
    if (!NAMES[l]) l = 'pt';
    LANG = l;
    EXP.save().settings.lang = l; EXP.touch();
    document.documentElement.lang = l === 'pt' ? 'pt-BR' : l;
    const sel = $('o-lang'); if (sel) sel.value = l;
    walk(document.body);
  }
  EXP.setLang = setLang;

  // idioma inicial: o salvo, ou o do navegador se for um dos suportados, senão português
  const nav = (navigator.language || 'pt').slice(0, 2).toLowerCase();
  const initial = EXP.save().settings.lang || (NAMES[nav] ? nav : 'pt');
  LANG = 'pt';
  setLang(initial);
  obs.observe(document.body, { childList: true, subtree: true, characterData: true });
})();
/* ============ FASES: NOMES, ORDEM DOS CAPÍTULOS E PROTEÇÃO CONTRA SPAWN NA PAREDE (anexar ao final de js/exp-ui.js) ============
   ARQUIVO: js/exp-ui.js (anexar ao final). Não altera index.html.
   1) Capítulos da história em ordem sequencial (antes estavam 6, 7, 8, 13, 16, 19, 9, 10, 11, 14...).
   2) Nomes de capítulos e de fases mais claros (no lugar de "HospitalEntrance", "Hospital abandonado" etc.).
   3) Nenhum inimigo, arma ou jogador nasce dentro de parede: se nascer, é empurrado para o ponto livre
      mais próximo; se não houver ponto livre, a entidade é removida. Vale para spawns iniciais e para
      ondas e reforços que surgem depois. */
(function () {
  'use strict';
  const EXP = window.EXP;

  // ---------- 1 e 2) capítulos e nomes ----------
  const STORY_TITLES = [
    'Prelúdio · Metrô de Brickell',
    'Capítulo 1 · Overdose',
    'Capítulo 2 · Decadência',
    'Capítulo 3 · Tensão',
    'Capítulo 4 · Golpe limpo',
    'Capítulo 5 · Vizinhos',
    'Capítulo 6 · Pressione',
    'Capítulo 7 · Delegacia',
    'Capítulo 8 · Fliperama',
    'Capítulo 9 · Resolução',
    'Capítulo 10 · Plantão',
    'Capítulo 11 · Ponto cego',
    'Capítulo 12 · Trem noturno',
    'Capítulo 13 · Vingança',
    'Expansão 1 · Hospital · entrada',
    'Expansão 2 · Hospital · andar superior',
    'Expansão 3 · Suíte do hotel',
    'Expansão 4 · Mansão · salão principal',
    'Expansão 5 · Delegacia · térreo',
    'Expansão 6 · Delegacia · 3º andar',
    'Expansão 7 · Clube · pista',
    'Expansão 8 · Clube · cobertura',
    'Expansão 9 · Unidade SWAT · térreo',
    'Expansão 10 · Estação de trem',
    'Expansão 11 · Fliperama',
    'Expansão 12 · Restaurante',
  ];
  STORY.forEach((c, i) => { if (STORY_TITLES[i] && c.t !== undefined) c.t = STORY_TITLES[i]; });

  const MAP_NAMES = {
    apto: 'Apartamento da Brickell', academia: 'Academia Splash', estudio: 'Estúdio Sunset', cassino: 'Cassino Bayside',
    fliperama: 'Fliperama Neon', central: 'Sede Central', mansao: 'Mansão Biscayne', metro: 'Estação Brickell',
    hotel: 'Hotel Blue', phonehom: 'Central Telefônica', boate: 'Boate Russa', delegacia: 'Delegacia Downtown',
    garagem: 'Garagem Subterrânea', loja: 'Loja 24h', hospital: 'Hospital Abandonado', 'boate-b': 'Boate Noturna',
    estacao: 'Estação de Trem', oficina: 'Oficina Mecânica',
  };
  MAPAS.forEach(m => { if (MAP_NAMES[m.id]) m.nome = MAP_NAMES[m.id]; });

  const NEON_NAMES = {
    rmHospitalEntrance: 'Hospital · Entrada', rmHospitalTopFloor: 'Hospital · Andar superior',
    rmHotelSuite: 'Hotel · Suíte', rmMansionMainHall: 'Mansão · Salão principal',
    rmPoliceHQFloor1: 'Delegacia · Térreo', rmPoliceHQFloor3: 'Delegacia · 3º andar',
    rmBossClubFloor1: 'Clube · Pista', rmBossClubFloor3: 'Clube · Cobertura',
    rmSwatDownstairs: 'Unidade SWAT · Térreo', rmTrainstationEntrance: 'Estação de trem · Entrada',
    rmEurogamer: 'Fliperama', rmNoodleShop: 'Restaurante',
  };
  const _bnf = buildNeonFloor;
  buildNeonFloor = function (m) { _bnf(m); if (NEON_NAMES[m.name]) mapName = NEON_NAMES[m.name]; };

  // ---------- 3) nada nasce dentro de parede ----------
  function freeNear(x, y, r) {
    if (!hitWall(x, y, r)) return [x, y];
    for (let d = 8; d <= 240; d += 8) for (let k = 0; k < 24; k++) {
      const a = k / 24 * Math.PI * 2, nx = x + Math.cos(a) * d, ny = y + Math.sin(a) * d;
      if (nx < 0 || ny < 0 || nx > WW || ny > WH) continue;
      if (!hitWall(nx, ny, r)) return [nx, ny];
    }
    return null;
  }
  const checkedE = new WeakSet(), checkedP = new WeakSet();
  function guardSpawns() {
    if (P) { const sp = freeNear(P.x, P.y, P.r); if (sp) { P.x = sp[0]; P.y = sp[1]; } }
    for (let i = enemies.length - 1; i >= 0; i--) {
      const e = enemies[i];
      if (checkedE.has(e)) continue;
      checkedE.add(e);
      const p = freeNear(e.x, e.y, e.r + 4);
      if (p) { e.x = p[0]; e.y = p[1]; } else enemies.splice(i, 1);
    }
    for (let i = pickups.length - 1; i >= 0; i--) {
      const q = pickups[i];
      if (checkedP.has(q)) continue;
      checkedP.add(q);
      const p = freeNear(q.x, q.y, 10);
      if (p) { q.x = p[0]; q.y = p[1]; } else pickups.splice(i, 1);
    }
  }
  const _worldTick = EXP.worldTick;
  EXP.worldTick = function (dt) { _worldTick(dt); if (st === 'play' && P) guardSpawns(); };
})();
/* ============ QUALIDADE DOS MAPAS: OBJETOS NÍTIDOS (anexar ao final de js/exp-ui.js) ============
   ARQUIVO: js/exp-ui.js (anexar ao final). Não altera index.html.
   Os sprites dos mapas são pixel art pequena (mediana de 32 px). Ao serem colados no chão do mapa,
   a suavização do canvas deixava as bordas borradas. Aqui os objetos são desenhados sem suavização,
   preservando a borda de cada pixel; o chão e os fundos continuam suavizados. */
(function () {
  'use strict';
  const _neonDrawProp = neonDrawProp;
  neonDrawProp = function (g, sp, x, y, rot) {
    const antes = g.imageSmoothingEnabled;
    g.imageSmoothingEnabled = false;
    _neonDrawProp(g, sp, x, y, rot);
    g.imageSmoothingEnabled = antes;
  };
})();
